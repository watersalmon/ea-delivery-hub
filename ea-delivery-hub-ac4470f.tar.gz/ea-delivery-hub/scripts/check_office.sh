#!/usr/bin/env sh
# Abre cada plantilla con LibreOffice headless (como lo haría una suite ofimática real):
# - XLSX: recalcula y exporta todas las hojas a CSV (para comprobar el resultado de las fórmulas) y a PDF.
# - PPTX: exporta a PDF.
# Después rasteriza la primera página de cada PDF a PNG para revisión visual.
# Uso (contenedor office): sh scripts/check_office.sh exports/<carpeta>
set -eu
SRC="${1:-exports}"
OUT="exports/_check"
rm -rf "$OUT" && mkdir -p "$OUT/csv" "$OUT/pdf" "$OUT/png"
for f in $(find "$SRC" -type f \( -name '*.xlsx' -o -name '*.pptx' -o -name '*.docx' \) -not -path "*/_check/*"); do
  base="$(basename "$f")"
  case "$f" in
    *.xlsx)
      soffice --headless --calc --convert-to 'csv:Text - txt - csv (StarCalc):44,34,76,1,,0,false,true,false,false,false,-1' \
        --outdir "$OUT/csv" "$f" >/dev/null 2>&1 || echo "FAIL csv $base"
      ;;
  esac
  # Carpeta por extensión: el XLSX y el PPTX de T12 comparten nombre base
  ext="${base##*.}"
  mkdir -p "$OUT/pdf/$ext"
  soffice --headless --convert-to pdf --outdir "$OUT/pdf/$ext" "$f" >/dev/null 2>&1 || echo "FAIL pdf $base"
  pdf="$OUT/pdf/$ext/${base%.*}.pdf"
  if [ -f "$pdf" ]; then
    pdftoppm -png -r 70 -f 1 -l 4 "$pdf" "$OUT/png/${base%.*}-$ext" || true
    echo "OK $base"
  else
    echo "FAIL $base"
  fi
done
