#!/usr/bin/env bash
# Copia de seguridad del volumen de datos (BD SQLite, diagramas subidos y ajustes de branding)
# en backups/ea_data_AAAAMMDD_HHMMSS.tar.gz. Para la app unos segundos para que la copia sea consistente.
set -euo pipefail
cd "$(dirname "$0")/.."
COMPOSE="docker compose -f docker-compose.yml -f docker-compose.prod.yml"
CID="$($COMPOSE ps -aq app)"
[ -n "$CID" ] || { echo "La app no está instalada (no hay contenedor). Lanza antes scripts/install.sh." >&2; exit 1; }
mkdir -p backups
FILE="backups/ea_data_$(date +%Y%m%d_%H%M%S).tar.gz"
RUNNING="$($COMPOSE ps -q --status running app || true)"
if [ -n "$RUNNING" ]; then
  $COMPOSE stop app >/dev/null 2>&1
  trap '$COMPOSE start app >/dev/null 2>&1' EXIT  # la app vuelve a arrancar aunque la copia falle
fi
docker cp "$CID:/data" - | gzip > "$FILE"
echo "Copia creada: $FILE"
