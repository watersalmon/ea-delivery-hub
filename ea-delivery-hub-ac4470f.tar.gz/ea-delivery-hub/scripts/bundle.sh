#!/usr/bin/env bash
# Prepara el paquete de instalación para otra máquina en dist/:
#   ea-delivery-hub-<versión>.tar.gz         código de la versión confirmada en git (HEAD)
#   ea-delivery-hub-image-<versión>.tar.gz   (con --image) imagen de producción, para instalar sin internet
# El material de docs/reference/ no está en git y por tanto no viaja en el paquete.
set -euo pipefail
cd "$(dirname "$0")/.."
WITH_IMAGE=0
[ "${1:-}" = "--image" ] && WITH_IMAGE=1
if [ -n "$(git status --porcelain)" ]; then
  echo "Aviso: hay cambios sin confirmar; el paquete solo incluye lo que está en el último commit." >&2
fi
VERSION="$(git describe --tags --always)"
mkdir -p dist
SRC="dist/ea-delivery-hub-${VERSION}.tar.gz"
git archive --format=tar.gz --prefix=ea-delivery-hub/ -o "$SRC" HEAD
echo "Código:  $SRC"
if [ "$WITH_IMAGE" = "1" ]; then
  COMPOSE="docker compose -f docker-compose.yml -f docker-compose.prod.yml"
  $COMPOSE build app
  IMG="dist/ea-delivery-hub-image-${VERSION}.tar.gz"
  docker save ea-delivery-hub:prod | gzip > "$IMG"
  echo "Imagen:  $IMG"
fi
echo "Instrucciones: docs/INSTALL.md (va dentro del paquete)"
