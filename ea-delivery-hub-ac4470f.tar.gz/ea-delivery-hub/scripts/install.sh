#!/usr/bin/env bash
# EA Delivery Hub — instalación en Docker dentro de WSL2 (imagen de producción).
#
#   scripts/install.sh                  construye la imagen y arranca la app
#   scripts/install.sh --seed           además carga los 3 programas demo
#   scripts/install.sh --image FICHERO  instala sin internet, desde la imagen de `make bundle-image`
#   scripts/install.sh --port 8090      publica en otro puerto (127.0.0.1)
#
# Es idempotente: volver a lanzarlo actualiza la app y conserva los datos (volumen ea_data).
set -euo pipefail

cd "$(dirname "$0")/.."

SEED=0
IMAGE=""
PORT=""
while [ $# -gt 0 ]; do
  case "$1" in
    --seed) SEED=1 ;;
    --image) IMAGE="${2:?--image necesita un fichero}"; shift ;;
    --port) PORT="${2:?--port necesita un número}"; shift ;;
    -h|--help) sed -n '2,9p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Opción desconocida: $1" >&2; exit 2 ;;
  esac
  shift
done

info() { printf '\033[1;34m==>\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m OK\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m !!\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31mERR\033[0m %s\n' "$*" >&2; exit 1; }

COMPOSE="docker compose -f docker-compose.yml -f docker-compose.prod.yml"

# ---------- 1. Entorno ----------
info "Comprobando el entorno"
if [ "$(uname -s)" = "Linux" ] && grep -qi microsoft /proc/version 2>/dev/null; then
  ok "WSL2 ($(. /etc/os-release 2>/dev/null && echo "${PRETTY_NAME:-Linux}"))"
else
  warn "No parece una distro WSL2. Se sigue, pero la guía asume Ubuntu en WSL2."
fi
case "$PWD" in
  /mnt/*) warn "La app está en $PWD (disco de Windows). Funciona, pero es más lenta; se recomienda ~/ea-delivery-hub." ;;
esac
command -v docker >/dev/null 2>&1 || die "No encuentro 'docker'. Instala Docker Desktop con la integración WSL activada (docs/INSTALL.md, paso 2)."
docker info >/dev/null 2>&1 || die "Docker no responde. Abre Docker Desktop (o 'sudo service docker start' con Docker Engine) y comprueba que tu usuario puede usarlo."
docker compose version >/dev/null 2>&1 || die "Falta 'docker compose' (plugin v2)."
ok "$(docker --version)"
ok "$(docker compose version)"

# ---------- 2. Configuración ----------
if [ ! -f .env ]; then
  cp .env.example .env
  ok "Creado .env a partir de .env.example"
else
  ok "Se conserva el .env existente"
fi
sed -i 's/\r$//' .env  # por si se editó desde Windows
if [ -n "$PORT" ]; then
  if grep -q '^EA_PORT=' .env; then sed -i "s/^EA_PORT=.*/EA_PORT=$PORT/" .env; else echo "EA_PORT=$PORT" >> .env; fi
fi
EA_PORT="$(grep -E '^EA_PORT=' .env | tail -1 | cut -d= -f2)"
EA_PORT="${EA_PORT:-8080}"
export EA_PORT

# ---------- 3. Imagen y arranque ----------
if [ -n "$IMAGE" ]; then
  [ -f "$IMAGE" ] || die "No existe $IMAGE"
  info "Cargando la imagen desde $IMAGE"
  gunzip -c "$IMAGE" | docker load
  info "Arrancando la app"
  $COMPOSE up -d --no-build app
else
  info "Construyendo la imagen de producción (la primera vez tarda unos minutos)"
  $COMPOSE build app
  info "Arrancando la app"
  $COMPOSE up -d app
fi

# ---------- 4. Healthcheck ----------
info "Esperando a que la app esté sana"
CID="$($COMPOSE ps -q app)"
STATUS=""
for _ in $(seq 1 60); do
  STATUS="$(docker inspect -f '{{.State.Health.Status}}' "$CID" 2>/dev/null || echo starting)"
  [ "$STATUS" = "healthy" ] && break
  sleep 2
done
if [ "$STATUS" != "healthy" ]; then
  $COMPOSE logs --tail 40 app
  die "La app no ha arrancado (estado: $STATUS). Arriba están los últimos logs."
fi
ok "Contenedor sano"

# ---------- 5. Datos demo ----------
if [ "$SEED" = "1" ]; then
  info "Cargando los programas demo"
  $COMPOSE exec -T app python -m app.services.seed
  ok "Programas demo cargados"
fi

# ---------- 6. Verificación ----------
if command -v curl >/dev/null 2>&1; then
  curl -fsS "http://127.0.0.1:${EA_PORT}/health" >/dev/null && ok "/health responde en el puerto ${EA_PORT}"
fi
echo
ok "EA Delivery Hub instalado: abre http://localhost:${EA_PORT} en el navegador de Windows"
echo "    Parar:        docker compose -f docker-compose.yml -f docker-compose.prod.yml down"
echo "    Copia datos:  scripts/backup.sh"
