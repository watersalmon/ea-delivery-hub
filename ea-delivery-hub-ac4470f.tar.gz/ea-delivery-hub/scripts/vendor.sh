#!/usr/bin/env sh
# Descarga (una sola vez, en desarrollo) las librerías front vendorizadas.
# En tiempo de ejecución la app no carga nada de CDN: todo se sirve desde app/static/vendor/.
# Uso: sh scripts/vendor.sh   (versiones fijadas abajo; actualizar también VERSIONS.md)
set -eu

HTMX=2.0.4
ALPINE=3.14.8
CHARTJS=4.4.7
LUCIDE=0.468.0
INTER=5.1.1

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
V="$ROOT/app/static/vendor"
CDN="https://cdn.jsdelivr.net/npm"
mkdir -p "$V/htmx" "$V/alpine" "$V/chartjs" "$V/lucide" "$V/fonts/inter"

curl -fsSL "$CDN/htmx.org@$HTMX/dist/htmx.min.js" -o "$V/htmx/htmx.min.js"
curl -fsSL "$CDN/alpinejs@$ALPINE/dist/cdn.min.js" -o "$V/alpine/alpine.min.js"
curl -fsSL "$CDN/chart.js@$CHARTJS/dist/chart.umd.js" -o "$V/chartjs/chart.umd.min.js"

for w in 400 500 600 700; do
  curl -fsSL "$CDN/@fontsource/inter@$INTER/files/inter-latin-$w-normal.woff2" \
    -o "$V/fonts/inter/inter-latin-$w-normal.woff2"
done

# Sprite SVG con solo los iconos Lucide que usa la app (lista en icons.txt).
SPRITE="$V/lucide/sprite.svg"
printf '<svg xmlns="http://www.w3.org/2000/svg" style="display:none">\n' > "$SPRITE"
while read -r icon; do
  [ -z "$icon" ] && continue
  svg="$(curl -fsSL "$CDN/lucide-static@$LUCIDE/icons/$icon.svg")"
  inner="$(printf '%s' "$svg" | tr '\n' ' ' | sed -e 's/.*<svg[^>]*>//' -e 's#</svg>.*##')"
  printf '<symbol id="i-%s" viewBox="0 0 24 24">%s</symbol>\n' "$icon" "$inner" >> "$SPRITE"
done < "$V/lucide/icons.txt"
printf '</svg>\n' >> "$SPRITE"

echo "Vendor OK en $V"
