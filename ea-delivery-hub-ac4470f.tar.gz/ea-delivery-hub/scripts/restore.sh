#!/usr/bin/env bash
# Restaura una copia de scripts/backup.sh. SUSTITUYE todos los datos actuales de la app.
#   scripts/restore.sh backups/ea_data_20261017_101500.tar.gz
set -euo pipefail
cd "$(dirname "$0")/.."
FILE="${1:?Uso: scripts/restore.sh backups/ea_data_....tar.gz}"
[ -f "$FILE" ] || { echo "No existe $FILE" >&2; exit 1; }
read -r -p "Se sustituirán TODOS los datos actuales por $FILE. ¿Continuar? [s/N] " ans
case "$ans" in s|S|si|SI|sí) ;; *) echo "Cancelado."; exit 0 ;; esac
COMPOSE="docker compose -f docker-compose.yml -f docker-compose.prod.yml"
$COMPOSE stop app >/dev/null 2>&1 || true
trap '$COMPOSE up -d app >/dev/null 2>&1' EXIT
# La copia contiene la carpeta data/: se vacía /data y se extrae su contenido
gunzip -c "$FILE" | $COMPOSE run --rm --no-deps -T --entrypoint sh app \
  -c 'find /data -mindepth 1 -delete && tar xf - -C /data --strip-components=1'
echo "Restaurado $FILE. La app vuelve a arrancar."
