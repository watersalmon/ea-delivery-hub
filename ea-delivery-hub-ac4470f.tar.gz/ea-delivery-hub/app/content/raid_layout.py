"""Columnas del RAID Log por pestaña (captura 1 + guía §8). Compartidas por la pantalla y el export T04."""

from __future__ import annotations

from dataclasses import dataclass

from app.models.enums import RAIDType


@dataclass(frozen=True)
class Col:
    field: str
    label: str
    cls: str = ""
    edit: bool = True
    vertical: bool = False
    extra: bool = False  # columnas plegables (causa/evento/consecuencia/trigger/foro)
    screen_only: bool = False  # se edita en pantalla pero no es columna del T04


COMMON_HEAD = [
    Col("code", "ID", "w-14 text-center", edit=False),
    Col("date_added", "Date Added", "w-20 text-center"),
]

# Pestaña Risks: exactamente las columnas de la captura + las plegables de la guía §8
RISK_COLUMNS = [
    Col("code", "ID", "w-14 text-center", edit=False),
    Col("organization", "Organization", "w-24 text-center"),
    Col("date_added", "Date Added", "w-20 text-center"),
    Col("reported_by", "Reported By", "w-24 text-center"),
    Col("title", "Risk Title", "min-w-[12rem]"),
    Col("workstream_id", "Workstream", "w-28"),
    Col("owner", "Risk Mitigation Owner", "w-28 text-center"),
    Col("probability", "Probability", "w-8 text-center", vertical=True),
    Col("impact", "Impact", "w-8 text-center", vertical=True),
    Col("score", "Risk Score", "w-12 text-center", edit=False, vertical=True),
    Col("due_date", "Due Date", "w-20 text-center"),
    Col("monitor_status", "Monitor Status", "w-24 text-center"),
    Col("contingency_plan", "Contingency Plan", "min-w-[12rem]"),
    Col("updates", "Risk Mitigation & Updates", "min-w-[16rem]", edit=False),
    Col("cause", "Cause", "min-w-[10rem]", extra=True),
    Col("event", "Event", "min-w-[10rem]", extra=True),
    Col("consequence", "Consequence", "min-w-[10rem]", extra=True),
    Col("escalation_trigger", "Escalation Trigger", "min-w-[10rem]", extra=True),
    Col("escalation_forum", "Escalation Forum", "w-28", extra=True),
    Col("trigger_met", "Trigger Met", "w-16 text-center", extra=True, screen_only=True),
]

TAB_COLUMNS: dict[str, list[Col]] = {
    RAIDType.ACTION: [
        *COMMON_HEAD,
        Col("title", "Action", "min-w-[14rem]"),
        Col("workstream_id", "Workstream", "w-28"),
        Col("owner", "Owner", "w-28"),
        Col("due_date", "Due Date", "w-20 text-center"),
        Col("monitor_status", "Status", "w-24 text-center"),
        Col("description", "Notes & Updates", "min-w-[14rem]"),
    ],
    RAIDType.ISSUE: [
        *COMMON_HEAD,
        Col("title", "Issue", "min-w-[14rem]"),
        Col("workstream_id", "Workstream", "w-28"),
        Col("owner", "Owner", "w-28"),
        Col("severity", "Severity", "w-20 text-center"),
        Col("source", "Source Risk", "w-20 text-center", edit=False),
        Col("due_date", "Due Date", "w-20 text-center"),
        Col("monitor_status", "Status", "w-24 text-center"),
        Col("resolution", "Resolution", "min-w-[14rem]"),
    ],
    RAIDType.DECISION: [
        *COMMON_HEAD,
        Col("title", "Decision", "min-w-[14rem]"),
        Col("owner", "Owner", "w-28"),
        Col("monitor_status", "Status", "w-24 text-center"),
        Col("description", "Notes / ADR", "min-w-[12rem]"),
    ],
    RAIDType.ESCALATION: [
        *COMMON_HEAD,
        Col("title", "Escalation", "min-w-[14rem]"),
        Col("source", "Source Risk", "w-20 text-center", edit=False),
        Col("escalation_forum", "Forum", "w-32"),
        Col("owner", "Owner", "w-28"),
        Col("due_date", "Due Date", "w-20 text-center"),
        Col("monitor_status", "Status", "w-24 text-center"),
    ],
    RAIDType.CHANGE: [
        *COMMON_HEAD,
        Col("title", "Change", "min-w-[14rem]"),
        Col("scope_impact", "Scope Impact", "min-w-[10rem]"),
        Col("cost_impact", "Cost Impact", "w-24"),
        Col("schedule_impact", "Schedule Impact", "w-24"),
        Col("change_control_decision", "Change Control", "w-24 text-center"),
        Col("owner", "Owner", "w-28"),
        Col("monitor_status", "Status", "w-24 text-center"),
    ],
    RAIDType.COMM: [
        *COMMON_HEAD,
        Col("title", "Communication", "min-w-[14rem]"),
        Col("owner", "Owner", "w-28"),
        Col("due_date", "Due Date", "w-20 text-center"),
        Col("monitor_status", "Status", "w-24 text-center"),
        Col("description", "Audience & Notes", "min-w-[14rem]"),
    ],
    RAIDType.LESSON: [
        Col("code", "ID", "w-14 text-center", edit=False),
        Col("title", "Lesson", "min-w-[12rem]"),
        Col("context", "Context", "min-w-[12rem]"),
        Col("decision_taken", "Decision", "min-w-[12rem]"),
        Col("result", "Result", "min-w-[10rem]"),
        Col("recommendation", "Recommendation", "min-w-[12rem]"),
        Col("owner", "Owner", "w-28"),
    ],
}
TAB_COLUMNS[RAIDType.RISK] = RISK_COLUMNS


def columns_for(raid_type: str, export: bool = False) -> list[Col]:
    cols = TAB_COLUMNS[raid_type]
    return [c for c in cols if not c.screen_only] if export else cols
