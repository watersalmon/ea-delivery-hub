"""Contenido de la guía práctica del EA usado por pantallas y plantillas (en inglés, PDR-004).

Es una redacción propia en inglés de las secciones de la guía; la fuente de verdad sigue siendo
docs/reference/Guia_Practica_Enterprise_Architect_Dell.docx.
"""

from __future__ import annotations

from dataclasses import dataclass

# §3 · Primeros 10 días: tramo, acciones del EA y evidencia de salida
TEN_DAYS: list[tuple[str, str, list[str], str]] = [
    (
        "before",
        "Before kick-off",
        [
            "Review SOW, proposal, LOE, assumptions, HLD, risks and presales handover.",
            "Identify gaps and contradictions.",
        ],
        "List of questions; initial artifact map; transition risks.",
    ),
    (
        "d1_2",
        "Days 1-2",
        [
            "Align outcomes, scope, constraints, stakeholders, roles and Definition of Done.",
        ],
        "Project Architecture Brief of 1-2 pages.",
    ),
    (
        "d3_5",
        "Days 3-5",
        [
            "Map workstreams, interfaces, dependencies, environments, data, security and open decisions.",
        ],
        "Context diagram; dependency map; decision backlog.",
    ),
    (
        "d6_7",
        "Days 6-7",
        [
            "Agree governance, Design Authority, forums, escalation criteria and repository.",
        ],
        "Architecture Governance Charter and calendar.",
    ),
    (
        "d8_10",
        "Days 8-10",
        [
            "Baseline requirements, roadmap, RAID and deliverables plan.",
            "Validate with the PM and the customer.",
        ],
        "Baseline v1 approved and actions with owner and date.",
    ),
]

# §3.1 · Preguntas que hay que poder responder el día 10
TEN_DAY_QUESTIONS = [
    "Which business outcomes justify the project and how will they be measured?",
    "What is explicitly in and out of scope?",
    "Which assumptions support the design and which must be validated first?",
    "Who has the authority to accept the architecture and changes?",
    "Which decisions are irreversible, costly or urgent?",
    "Which external dependencies can block the critical path?",
    "Who will operate the solution and what do they need to be ready?",
    "How will we prove that the requirements have been met?",
]

# §5.1 · Foros recomendados: foro, frecuencia, propósito, salida
FORUMS = [
    (
        "Workstream design sync",
        "Weekly",
        "Review progress, interfaces, blockers and upcoming designs.",
        "Actions, risks and decisions.",
    ),
    (
        "Architecture Design Authority",
        "Weekly or bi-weekly",
        "Approve significant decisions and manage exceptions.",
        "ADR approved / rejected / deferred.",
    ),
    (
        "EA-PM alignment",
        "Weekly",
        "Synchronise architecture, plan, dependencies, budget and changes.",
        "RAID and plan updated.",
    ),
    (
        "Customer architecture review",
        "Bi-weekly",
        "Keep alignment with the customer's architecture and stakeholders.",
        "Acceptances and escalations.",
    ),
    (
        "SteerCo",
        "Monthly / per gate",
        "Raise impacts on outcomes, scope, cost, schedule or risk.",
        "Executive decisions.",
    ),
]

# §5.2 · Design Authority mínimo viable
DA_INPUT = "Decision paper / ADR, alternatives, recommendation, impacts, risks and evidence."
DA_PARTICIPANTS = [
    "Enterprise Architect",
    "Tech / Domain Leads",
    "Customer",
    "SMEs as needed",
    "PM (informed)",
]
DA_CRITERIA: list[tuple[str, str]] = [
    ("alignment", "Alignment"),
    ("security", "Security"),
    ("operability", "Operability"),
    ("cost", "Cost"),
    ("schedule", "Schedule"),
    ("reversibility", "Reversibility"),
    ("compliance", "Compliance"),
]
DA_OUTPUT = "Decision, conditions, owner, date, affected artifacts and communication."
DA_SLA = "Critical-path decisions must never stay without an owner and a date."

# §13.3 · Agenda de la Design Authority (minutos por bloque)
DA_AGENDA: list[tuple[int, str]] = [
    (5, "Quorum, previous actions and priority changes."),
    (10, "Risks and dependencies needing attention."),
    (30, "Decisions, one by one, with recommendation and trade-offs."),
    (10, "Impacts on artifacts, plan, tests and communications."),
    (5, "Recap of decisions, owners and dates."),
]

# §7.3 · Cuándo elevar una decisión: nivel, ejemplo, foro
ESCALATION_LEVELS = [
    (
        "Workstream",
        "Configurable, reversible choice with no cross-cutting impact.",
        "Tech Lead / design sync",
    ),
    ("Architecture", "Impacts several domains, NFRs, a standard or the roadmap.", "Design Authority"),
    ("Program", "Affects scope, cost, schedule, resources or acceptance.", "PM / Change Control"),
    ("Executive", "Changes an outcome, material exposure or a contractual commitment.", "SteerCo / sponsor"),
]

# §7.1 / §7.2 · Preguntas de revisión
HLD_QUESTIONS = [
    "Does the design explicitly link to outcomes and requirements?",
    "Does it show boundaries, actors, systems, data, integrations and trust boundaries?",
    "Does it cover normal, failure, recovery, growth and maintenance scenarios?",
    "Are NFRs measurable: availability, performance, RTO/RPO, security, capacity?",
    "Have operations, observability, patching, backup, support and skills been considered?",
    "Are dependencies, assumptions and pending decisions visible?",
    "Is the design implementable within scope, schedule, budget and LOE?",
]
LLD_QUESTIONS = [
    "Does it implement the approved HLD without introducing hidden architecture?",
    "Does it include configuration, addressing, naming, versions, rules, interfaces and sequences?",
    "Do critical parameters have a source, an owner and a validation criterion?",
    "Does it include deployment, rollback, tests, troubleshooting and evidence?",
    "Do security and secrets follow the approved model?",
    "Are deviations recorded through ADR / change control?",
]
REVIEW_ANSWERS = ["Yes", "No", "Partial", "N/A"]


# §13.1 · Architecture Brief de una página
@dataclass(frozen=True)
class BriefSection:
    key: str
    title: str
    hint: str


BRIEF_SECTIONS = [
    BriefSection(
        "outcomes", "Business outcomes and metrics", "Why the program exists and how success is measured."
    ),
    BriefSection("scope_in", "Scope in", "What is explicitly included."),
    BriefSection("scope_out", "Scope out", "What is explicitly excluded."),
    BriefSection(
        "context", "Context and high-level diagram", "Landscape, actors and the high-level picture."
    ),
    BriefSection("principles", "Principles and constraints", "Architecture principles and hard constraints."),
    BriefSection("workstreams", "Workstreams and dependencies", "Who builds what and what each one needs."),
    BriefSection(
        "risks_assumptions", "Top risks and assumptions", "The few risks and assumptions that matter most."
    ),
    BriefSection(
        "open_decisions", "Open decisions and dates", "Decisions still to take, with owner and date."
    ),
    BriefSection(
        "governance",
        "Governance, stakeholders and next steps",
        "Forums, decision makers and what happens next.",
    ),
]
# Criterio "se entiende en 10 minutos": ~2 páginas A4 a 11 pt
BRIEF_MAX_WORDS = 900

# Anexo A · Definition of Done del EA (se usa en la Fase 5)
EA_DOD = [
    "The architecture is aligned with accepted outcomes and requirements.",
    "Material decisions are documented and approved.",
    "Deviations and exceptions are visible and controlled.",
    "Risks and dependencies have a response, an owner and a date.",
    "The solution meets measurable security, resilience, performance and operations criteria.",
    "As-built documentation and traceability are up to date.",
    "Customer and operations accept ownership and handover.",
    "Lessons learned and the future roadmap are captured.",
]
