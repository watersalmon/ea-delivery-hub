"""Definición de cada artefacto: bloque Purpose / Process / Additional Information (CLAUDE.md §4.2.1).

El mismo texto encabeza la pantalla y la diapositiva PPTX exportada (Fase 3).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ArtifactDefinition:
    title: str
    purpose: str
    process: list[str]
    additional: list[str]


ARTIFACTS: dict[str, ArtifactDefinition] = {
    "raid": ArtifactDefinition(
        title="Risks, Actions, Issues & Dependencies (RAID)",
        purpose=(
            "Single log to plan and record program risks, actions, issues, decisions, escalations, "
            "changes, communications and lessons learned."
        ),
        process=[
            "Updated continuously and used to prepare the weekly status meeting.",
            "Reviewed with the PM every week and with the customer every two weeks.",
        ],
        additional=[
            "Every risk states cause, event, consequence, owner, date and escalation trigger.",
            "Critical risks never stay without an owner.",
        ],
    ),
    "goals": ArtifactDefinition(
        title="Solution Dependency Map",
        purpose=(
            "Aligns solution objectives with the customer's goals and expected business outcomes, "
            "and maps the RTM requirements to them to prove a successful outcome."
        ),
        process=[
            "Check RTM requirements and changes against the organisational goals.",
            "Track completion of each objective against its acceptance criteria.",
        ],
        additional=[
            "Goals and objectives start from what was agreed during presales.",
            "Also published as the Solution Dependency tab of the RTM.",
        ],
    ),
    "rtm": ArtifactDefinition(
        title="Requirements Traceability Matrix (RTM)",
        purpose=(
            "Proves coverage: every requirement traces to an outcome or objective, a design element, "
            "the decisions behind it and the evidence that it works."
        ),
        process=[
            "Requirements are baselined at G1 and changed only through Change Control or an ADR.",
            "Evidence is attached before G5 acceptance.",
        ],
        additional=[
            "Quality criterion: no orphan requirements.",
            "Non-functional requirements must be measurable.",
        ],
    ),
    "raci": ArtifactDefinition(
        title="RACI Matrix",
        purpose="Clarifies ownership across EA, PM, Tech Leads and customer to avoid gaps and overlaps.",
        process=[
            "Agreed during the first 10 days and reviewed at every gate.",
            "Validated live: exactly one Accountable and at least one Responsible per activity.",
        ],
        additional=[
            "Use it to clarify ownership, not to step back from the work.",
            "Qualified roles (technical, domain, coordination) count as Responsible.",
        ],
    ),
    "stakeholders": ArtifactDefinition(
        title="Stakeholder Map & Comms Plan",
        purpose="Makes sure the right people decide and are informed, with the right message and cadence.",
        process=[
            "Map influence and interest; agree message, channel, cadence and owner for each stakeholder.",
            "Review after every SteerCo and whenever the organisation changes.",
        ],
        additional=["Quality criterion: decision makers and detractors are identified."],
    ),
    "dependencies": ArtifactDefinition(
        title="Dependency Register",
        purpose="Tracks what each workstream needs from other workstreams, third parties and the customer.",
        process=[
            "Every external dependency needs a verifiable commitment (PO, signed plan, written date).",
            "Critical-path dependencies are reviewed in every EA-PM alignment.",
        ],
        additional=["An external dependency without a commitment is an escalation signal."],
    ),
}
