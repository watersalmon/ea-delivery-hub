---
title: Checklists, 30-60-90 and common mistakes
order: 3
---
# Am I really in charge of the architecture?

- [ ] I can explain the project and the architecture in five minutes.
- [ ] I know the five most important decisions and risks.
- [ ] Every workstream understands its interfaces and dependencies.
- [ ] The documents reflect the real decisions, not an old snapshot.
- [ ] Exceptions have approval and a review date.
- [ ] The PM and I share the same view of impact and priority.
- [ ] The customer knows what to decide and when.
- [ ] Operations is involved before the end.

The same list lives on the [program dashboard](/dashboard), where you can tick it week by week.

# 30-60-90 day development plan

| Period | Focus | Expected result |
|---|---|---|
| Days 0-30 | Observe, learn the templates, join workshops and reviews; master the minimum artifacts | Can prepare the Architecture Brief, RAID, RACI, RTM and Design Authority agenda |
| Days 31-60 | Lead a cross-cutting workstream or a moderate-risk engagement with coaching | Facilitates decisions, reviews HLD/LLD and keeps traceability |
| Days 61-90 | Lead end-to-end governance, customer reviews and gate closures | Works autonomously and asks for support selectively |

# Common mistakes and how to avoid them

| Mistake | Consequence | Recommended response |
|---|---|---|
| Joining late | Decisions already crystallised | Agree early engagement and gates |
| Confusing the document with the architecture | Correct on paper, incoherent in delivery | Continuous governance and evidence |
| Trying to design everything | Bottleneck and loss of ownership | Delegate detail; govern interfaces and decisions |
| Not involving operations | A solution that is hard to run | Operational readiness from discovery |
| Accepting vague requirements | Ambiguous tests and acceptance | Make them measurable and traceable |
| A RAID without action | False sense of control | Owner, date, trigger and forum |
| Not updating the baseline | Teams working on different versions | Single repository and change control |
| Escalating without options | Slow decisions | Bring a recommendation, alternatives and impact |

# EA Definition of Done

- [ ] The architecture is aligned with the accepted outcomes and requirements.
- [ ] Material decisions are documented and approved.
- [ ] Deviations and exceptions are visible and controlled.
- [ ] Risks and dependencies have a response, an owner and a date.
- [ ] The solution meets measurable security, resilience, performance and operations criteria.
- [ ] As-built documentation and traceability are up to date.
- [ ] The customer and operations accept ownership and handover.
- [ ] Lessons learned and the future roadmap are captured.
