---
title: Cadence, governance and escalation
order: 2
---
# Recommended forums

| Forum | Frequency | Purpose | Output |
|---|---|---|---|
| Workstream design sync | Weekly | Progress, interfaces, blockers and upcoming designs | Actions, risks and decisions |
| Architecture Design Authority | Weekly or bi-weekly | Approve significant decisions and manage exceptions | ADR approved / rejected / deferred |
| EA-PM alignment | Weekly | Architecture, plan, dependencies, budget and changes | RAID and plan updated |
| Customer architecture review | Bi-weekly | Alignment with the customer's architecture and stakeholders | Acceptances and escalations |
| SteerCo | Monthly / per gate | Impacts on outcomes, scope, cost, schedule or risk | Executive decisions |

# Minimum viable Design Authority

- **Input:** decision paper or ADR, alternatives, recommendation, impacts, risks and evidence.
- **Participants:** EA, Tech/Domain Leads, customer and the SMEs needed; PM informed.
- **Criteria:** alignment, security, operability, cost, schedule, reversibility and compliance.
- **Output:** decision, conditions, owner, date, affected artifacts and communication.
- **SLA:** critical-path decisions never stay without an owner and a date.

Agenda: 5 min quorum and previous actions · 10 min risks and dependencies · 30 min decisions one by one · 10 min impacts · 5 min recap.

# When to escalate a decision

| Level | Example | Forum |
|---|---|---|
| Workstream | Configurable, reversible choice with no cross-cutting impact | Tech Lead / design sync |
| Architecture | Impacts several domains, NFRs, a standard or the roadmap | Design Authority |
| Program | Affects scope, cost, schedule, resources or acceptance | PM / Change Control |
| Executive | Changes an outcome, material exposure or a contractual commitment | SteerCo / sponsor |

# Signals to escalate

- A critical-path decision without owner or date.
- A deviation from the HLD that affects NFRs, security or operability.
- An external dependency without a verifiable commitment.
- A contractual assumption that turns out false.
- A design that needs capacity, licences or skills not included.
- A conflict between workstreams that the technical forum cannot solve.
- A risk above the agreed appetite or threatening an outcome.

A useful RAID entry states cause, event, impact, likelihood, response, owner and date: *"Due to [cause], there is a risk of [event], which could lead to [impact]. Response: [action]. Owner: [role]. Date: [day]. Escalation trigger: [condition]."*
