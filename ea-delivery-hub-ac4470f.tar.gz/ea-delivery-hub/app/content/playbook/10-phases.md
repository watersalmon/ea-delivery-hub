---
title: Lifecycle by phase
order: 1
---
Use TOGAF 10 ADM as a thinking discipline, not as a rigid sequence: keep Requirements Management at the centre and adapt depth, artifacts and governance to the size, risk and duration of the engagement.

# Phase 0 · Qualify / Presales

**Key question:** is the solution deliverable?

- **Do:** validate outcomes, scope, dependencies, risks, LOE, transition and the initial artifacts.
- **Ask:** which assumptions are we betting on? What has the customer not told us yet?
- **Produce:** risk list, testable assumptions, presales handover.
- **Under control when:** risks are visible, assumptions are testable and the handover is defined (G0).

# Phase 1 · Discover

**Key question:** do we understand the real context?

- **Do:** workshops, landscape, stakeholders, requirements, constraints, capabilities and readiness.
- **Ask:** the eight questions of the [first 10 days](/onboarding).
- **Produce:** [Architecture Brief](/brief), [stakeholder map](/stakeholders?tab=map), [RTM](/rtm) with measurable NFRs.
- **Under control when:** context and requirements are baselined (G1).

# Phase 2 · Define target

**Key question:** is the target architecture coherent?

- **Do:** principles, options, trade-offs, NFRs, security, operations and integration.
- **Ask:** which decisions are irreversible, costly or urgent?
- **Produce:** HLD, [ADRs](/adr) with real alternatives, updated RTM.
- **Under control when:** the HLD and key decisions are accepted (G2).

# Phase 3 · Plan transition

**Key question:** is there a viable path?

- **Do:** roadmap, work packages, dependencies, environments, migration and cutover.
- **Ask:** which external dependency can block the critical path, and who has committed to it?
- **Produce:** [roadmap](/gates#roadmap) with transition states, dependency register.
- **Under control when:** the incremental plan is agreed (G3).

# Phase 4 · Govern delivery

**Key question:** is what was approved being implemented?

- **Do:** design reviews, decision log, RAID, changes, assurance and metrics.
- **Ask:** does delivery deviate from the baseline without approval?
- **Produce:** [HLD/LLD reviews](/architecture), [Design Authority](/design-authority) minutes, [weekly health check](/dashboard).
- **Under control when:** there is conformance or the deviations are approved (G4).

# Phase 5 · Validate / Transition

**Key question:** does it work and can it be operated?

- **Do:** evidence, acceptance, runbooks, observability, support and handover.
- **Ask:** has operations accepted ownership?
- **Produce:** test evidence in the RTM, [Operational Readiness Review](/orr).
- **Under control when:** acceptance and operational readiness are signed (G5).

# Phase 6 · Close / Evolve

**Key question:** what was achieved and what is next?

- **Do:** outcomes achieved, lessons learned, technical debt, future roadmap and closure of decisions.
- **Produce:** [as-built and handover](/handover), [lessons learned](/lessons).
- **Under control when:** the final architecture is documented and the backlog transferred (G6).
