---
title: The Enterprise Architect's role
order: 0
---
# Mission

Keep an unbroken line between business objectives, requirements, architecture, decisions, delivery and results. The EA gives a cross-cutting view, technical governance and a single point of integration between the customer, Dell Technologies, partners, the PMO and the workstreams.

> Golden rule: the EA does not have to design every component. The EA makes sure all components form a coherent, traceable, governable solution aligned with the customer's outcomes.

# What you are, and what you are not

| You are | You are not |
|---|---|
| Responsible for end-to-end coherence | The detailed designer of every technology |
| Custodian of principles, decisions and traceability | A substitute for the PM or the Tech Lead |
| Facilitator of decisions and conflict resolution | The only person who can decide |
| Translator between business, architecture and delivery | An observer who only reviews documents |
| Trusted advisor who anticipates impacts and next steps | An auditor who appears at the end |

# Essential responsibilities

- Align the architecture with the customer's outcomes and constraints.
- Set up the governance model and the [Design Authority](/design-authority).
- Coordinate dependencies across domains, third parties and customer teams.
- Keep architecture, decisions, requirements and risks in sync.
- Raise risks and decisions in the right forum, with options and implications.
- Ensure clean transitions from presales to delivery and from delivery to operations.
- Identify roadmap extensions without turning architecture into a sales activity.

# The EA mantra

**Outcome before product. Decision before document. Evidence before opinion. Governance before improvisation. Operability before closure.**
