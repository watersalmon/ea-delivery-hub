"""Entorno de Alembic: usa DATABASE_URL y el metadata de SQLModel (render_as_batch para SQLite)."""

from __future__ import annotations

from alembic import context
from sqlmodel import SQLModel

import app.models  # noqa: F401  registra las tablas
from app.db import get_engine

target_metadata = SQLModel.metadata


def run_migrations_offline() -> None:
    context.configure(
        url=str(get_engine().url),
        target_metadata=target_metadata,
        literal_binds=True,
        render_as_batch=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    with get_engine().connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata, render_as_batch=True)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
