"""Navegación de la sidebar, agrupada según el ciclo de vida de la guía (CLAUDE.md §4.3).

Los badges se calculan en tiempo de petición (`badge` es la clave de un contador del motor de
reglas); nunca son texto fijo. Mientras una pantalla no existe, `phase` indica en qué fase llega.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class NavItem:
    slug: str
    label: str
    icon: str
    phase: int
    badge: str | None = None
    feature: str | None = None  # p. ej. "copilot": solo aparece si la feature está activa

    @property
    def url(self) -> str:
        return "/" if self.slug == "portfolio" else f"/{self.slug}"


@dataclass(frozen=True)
class NavGroup:
    label: str
    items: tuple[NavItem, ...]


NAVIGATION: tuple[NavGroup, ...] = (
    NavGroup(
        "Main",
        (
            NavItem("portfolio", "Home", "house", 2),
            NavItem("dashboard", "Program dashboard", "layout-dashboard", 2),
            NavItem("onboarding", "First 10 days", "rocket", 4),
        ),
    ),
    NavGroup(
        "Define",
        (
            NavItem("brief", "Architecture Brief", "file-text", 4),
            NavItem("goals", "Goals & Solution Dependency Map", "target", 2),
            NavItem("rtm", "Requirements & RTM", "list-checks", 2, badge="rtm_orphans"),
            NavItem("architecture", "Architecture (HLD/LLD)", "network", 4),
        ),
    ),
    NavGroup(
        "Govern",
        (
            NavItem("gates", "Gates & Roadmap", "milestone", 4, badge="active_gate"),
            NavItem("adr", "Decisions (ADR)", "gavel", 4, badge="adr_pending"),
            NavItem("design-authority", "Design Authority", "landmark", 4),
            NavItem("raid", "RAID & Dependencies", "triangle-alert", 2, badge="critical_risks_no_owner"),
            NavItem("stakeholders", "Stakeholders, RACI & Comms", "users", 2, badge="raci_errors"),
        ),
    ),
    NavGroup(
        "Deliver & Close",
        (
            NavItem("orr", "Operational Readiness", "shield-check", 5),
            NavItem("handover", "As-built & Handover", "package-check", 5),
            NavItem("lessons", "Lessons Learned", "lightbulb", 5),
        ),
    ),
    NavGroup(
        "Enablement",
        (
            NavItem("templates", "Template Library", "library", 5),
            NavItem("playbook", "EA Playbook", "book-open", 5),
            NavItem("copilot", "EA Copilot", "bot", 6, feature="copilot"),
            NavItem("admin", "Administration", "settings", 5),
        ),
    ),
)


def visible_navigation(features: set[str]) -> list[NavGroup]:
    return [
        NavGroup(g.label, tuple(i for i in g.items if i.feature is None or i.feature in features))
        for g in NAVIGATION
    ]


def find_item(slug: str) -> NavItem | None:
    for group in NAVIGATION:
        for item in group.items:
            if item.slug == slug:
                return item
    return None


def group_of(slug: str) -> str | None:
    for group in NAVIGATION:
        if any(i.slug == slug for i in group.items):
            return group.label
    return None
