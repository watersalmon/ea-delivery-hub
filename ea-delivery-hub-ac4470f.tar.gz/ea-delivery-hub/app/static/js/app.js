// Comportamiento global mínimo: Ctrl+K, filtro y ordenación de tablas tipo hoja de cálculo.

document.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
    const input = document.getElementById("global-search");
    if (input) {
      e.preventDefault();
      input.focus();
      input.select();
    }
  }
  if (e.key === "Escape") {
    const results = document.getElementById("search-results");
    if (results) results.innerHTML = "";
  }
});

function cellIndex(th) {
  return Array.from(th.parentElement.children).indexOf(th);
}

function cellText(row, idx) {
  const cell = row.children[idx];
  if (!cell) return "";
  return (cell.dataset.sortValue ?? cell.textContent).trim();
}

function applyFilters(table) {
  const inputs = table.querySelectorAll("[data-filter-input]");
  const filters = Array.from(inputs)
    .map((i) => [Number(i.dataset.filterInput), i.value.trim().toLowerCase()])
    .filter(([, v]) => v);
  table.querySelectorAll("tbody tr").forEach((row) => {
    const ok = filters.every(([idx, v]) => cellText(row, idx).toLowerCase().includes(v));
    row.hidden = !ok;
  });
}

document.addEventListener("click", (e) => {
  const filterBtn = e.target.closest(".filter-btn");
  if (filterBtn) {
    const table = filterBtn.closest("table");
    const row = table.querySelector(".filter-row");
    if (row) {
      row.classList.remove("hidden");
      const idx = cellIndex(filterBtn.closest("th"));
      const input = row.querySelector(`[data-filter-input="${idx}"]`);
      if (input) input.focus();
    }
    return;
  }
  const sortBtn = e.target.closest(".sort-btn");
  if (sortBtn) {
    const th = sortBtn.closest("th");
    const table = th.closest("table");
    sortTable(table, th, th.dataset.dir !== "asc");
  }
});

function sortTable(table, th, asc) {
  const idx = cellIndex(th);
  table.querySelectorAll("thead th").forEach((h) => {
    delete h.dataset.dir;
    h.removeAttribute("aria-sort");
  });
  th.dataset.dir = asc ? "asc" : "desc";
  th.setAttribute("aria-sort", asc ? "ascending" : "descending");
  const tbody = table.querySelector("tbody");
  const rows = Array.from(tbody.querySelectorAll("tr"));
  rows.sort((a, b) => {
    const x = cellText(a, idx);
    const y = cellText(b, idx);
    const nx = Number(x);
    const ny = Number(y);
    const cmp = x !== "" && y !== "" && !isNaN(nx) && !isNaN(ny) ? nx - ny : x.localeCompare(y);
    return asc ? cmp : -cmp;
  });
  rows.forEach((r) => tbody.appendChild(r));
}

document.addEventListener("input", (e) => {
  if (e.target.matches("[data-filter-input]")) applyFilters(e.target.closest("table"));
});

// ---- Refresco suave: tras guardar, vuelve a pedir la página y sustituye solo <main>, conservando el estado de la vista.
function captureViewState(main) {
  return {
    scroll: [window.scrollX, window.scrollY],
    tables: Array.from(main.querySelectorAll("table")).map((t) => {
      const sorted = t.querySelector("thead th[data-dir]");
      const row = t.querySelector(".filter-row");
      return {
        filters: Array.from(t.querySelectorAll("[data-filter-input]")).map((i) => [i.dataset.filterInput, i.value]),
        filterRowOpen: !!row && !row.classList.contains("hidden"),
        sort: sorted ? [sorted.dataset.col, sorted.dataset.dir === "asc"] : null,
      };
    }),
    alpine: Array.from(main.querySelectorAll("[x-data]")).map((el) => {
      const data = el._x_dataStack ? el._x_dataStack[0] : null;
      const out = {};
      if (data) for (const k of Object.keys(data)) if (["boolean", "number", "string"].includes(typeof data[k])) out[k] = data[k];
      return out;
    }),
  };
}

function restoreViewState(main, st) {
  Array.from(main.querySelectorAll("table")).forEach((t, n) => {
    const s = st.tables[n];
    if (!s) return;
    const row = t.querySelector(".filter-row");
    if (row && s.filterRowOpen) row.classList.remove("hidden");
    s.filters.forEach(([idx, v]) => {
      const input = t.querySelector(`[data-filter-input="${idx}"]`);
      if (input) input.value = v;
    });
    if (s.filters.some(([, v]) => v)) applyFilters(t);
    if (s.sort) {
      const th = t.querySelector(`thead th[data-col="${s.sort[0]}"]`);
      if (th && th.querySelector(".sort-btn")) sortTable(t, th, s.sort[1]);
    }
  });
  // Alpine inicializa los x-data nuevos de forma asíncrona: se reintenta hasta que existan sus datos
  const els = Array.from(main.querySelectorAll("[x-data]"));
  let tries = 0;
  const apply = () => {
    if (!window.Alpine) return;
    if (els.some((el) => !el._x_dataStack) && tries++ < 20) return setTimeout(apply, 30);
    els.forEach((el, n) => st.alpine[n] && el._x_dataStack && Object.assign(el._x_dataStack[0], st.alpine[n]));
  };
  apply();
  window.scrollTo(st.scroll[0], st.scroll[1]);
}

let softRefreshing = null;
window.eaSoftRefresh = function () {
  if (softRefreshing) return softRefreshing;
  const main = document.getElementById("main");
  if (!main) return Promise.resolve();
  softRefreshing = fetch(location.href, { credentials: "same-origin" })
    .then((r) => (r.ok ? r.text() : Promise.reject(new Error(r.status))))
    .then((html) => {
      const doc = new DOMParser().parseFromString(html, "text/html");
      const fresh = doc.getElementById("main");
      if (!fresh) return;
      const state = captureViewState(main);
      main.style.minHeight = main.offsetHeight + "px"; // evita que la página se acorte y pierda el scroll
      main.innerHTML = fresh.innerHTML;
      if (window.htmx) htmx.process(main);
      restoreViewState(main, state);
      const aside = document.querySelector("aside[aria-label='Main navigation']");
      const freshAside = doc.querySelector("aside[aria-label='Main navigation']");
      if (aside && freshAside) aside.innerHTML = freshAside.innerHTML;
      setTimeout(() => (main.style.minHeight = ""), 50);
    })
    .catch(() => window.location.reload()) // último recurso si la petición falla
    .finally(() => (softRefreshing = null));
  return softRefreshing;
};

document.body.addEventListener("ea:saved", () => window.eaSoftRefresh());
document.body.addEventListener("htmx:afterRequest", (e) => {
  const elt = e.detail.elt;
  if (e.detail.successful && elt && elt.hasAttribute && elt.hasAttribute("data-soft-refresh")) window.eaSoftRefresh();
});

// ---- Modal de enlaces: el contenido llega por htmx en #link-dialog-body; se abre al cargar y se cierra al guardar.
document.body.addEventListener("htmx:afterSwap", (e) => {
  const dlg = document.getElementById("link-dialog");
  if (dlg && e.detail.target && e.detail.target.id === "link-dialog-body" && !dlg.open) dlg.showModal();
});
document.body.addEventListener("ea:saved", () => {
  const dlg = document.getElementById("link-dialog");
  if (dlg && dlg.open) dlg.close();
});
document.getElementById("link-dialog")?.addEventListener("close", () => {
  document.getElementById("link-dialog-body").innerHTML = "";
});
