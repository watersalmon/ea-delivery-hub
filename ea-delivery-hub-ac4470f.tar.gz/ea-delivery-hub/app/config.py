"""Configuración de la app a partir de variables de entorno y branding.yaml."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

BASE_DIR = Path(__file__).resolve().parent.parent
APP_DIR = BASE_DIR / "app"
VERSION = "0.1.0"


def _env_bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    database_url: str = field(default_factory=lambda: os.getenv("DATABASE_URL", "sqlite:///./data/ea.db"))
    exports_dir: Path = field(
        default_factory=lambda: Path(os.getenv("EXPORTS_DIR", str(BASE_DIR / "exports")))
    )
    current_user: str = field(default_factory=lambda: os.getenv("EA_USER", "ea.demo"))
    copilot_enabled: bool = field(default_factory=lambda: _env_bool("COPILOT_ENABLED"))
    branding_file: Path = field(
        default_factory=lambda: Path(os.getenv("BRANDING_FILE", str(BASE_DIR / "branding.yaml")))
    )


@lru_cache
def get_settings() -> Settings:
    return Settings()


def data_dir() -> Path:
    """Directorio de datos persistentes: el volumen /data en Docker, ./data en local."""
    url = get_settings().database_url
    base = Path("/data") if url.startswith("sqlite:////data") else BASE_DIR / "data"
    base.mkdir(parents=True, exist_ok=True)
    return base


# Textos de marca que se pueden cambiar desde Administración (se guardan en el volumen de datos)
BRANDING_OVERRIDABLE = ("classification", "methodology_banner", "export_language")


def branding_override_path() -> Path:
    return data_dir() / "branding.override.yaml"


@lru_cache
def get_branding() -> dict[str, Any]:
    """Textos y colores de marca: branding.yaml + ajustes guardados desde Administración."""
    path = get_settings().branding_file
    data: dict[str, Any] = {}
    if path.exists():
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    override = branding_override_path()
    if override.exists():
        extra = yaml.safe_load(override.read_text(encoding="utf-8")) or {}
        data.update({k: v for k, v in extra.items() if k in BRANDING_OVERRIDABLE})
    data.setdefault("app_name", "EA Delivery Hub")
    data.setdefault("app_subtitle", "Architecture & Delivery Governance")
    data.setdefault("classification", "Internal Use - Confidential")
    data.setdefault("methodology_banner", "")
    logo = data.get("logo")
    data["logo_exists"] = bool(logo) and (BASE_DIR / str(logo)).exists()
    return data
