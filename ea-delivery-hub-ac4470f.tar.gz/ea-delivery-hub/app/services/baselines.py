"""Snapshot del programa y diff entre baselines (conciliación baseline vs implantado, CLAUDE.md §7.14)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from sqlmodel import Session, select

from app.models import ArchitectureElement, RAIDItem, Requirement, WorkPackage

SECTIONS = (
    ("requirements", "Requirements"),
    ("architecture", "Architecture"),
    ("raid", "RAID"),
    ("roadmap", "Roadmap"),
)
# Campos sin significado de negocio en la comparación
_IGNORE = {"id", "program_id", "created_at", "created_by", "updated_at", "updated_by"}


def snapshot_payload(session: Session, program_id: int) -> dict[str, list[dict[str, Any]]]:
    def rows(model: Any) -> list[dict[str, Any]]:
        return [
            r.model_dump(mode="json")
            for r in session.exec(select(model).where(model.program_id == program_id)).all()
        ]

    return {
        "requirements": rows(Requirement),
        "architecture": rows(ArchitectureElement),
        "raid": rows(RAIDItem),
        "roadmap": rows(WorkPackage),
    }


@dataclass
class Change:
    code: str
    label: str
    fields: list[tuple[str, Any, Any]] = field(default_factory=list)


@dataclass
class SectionDiff:
    key: str
    title: str
    added: list[Change] = field(default_factory=list)
    removed: list[Change] = field(default_factory=list)
    changed: list[Change] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.added) + len(self.removed) + len(self.changed)


def _label(row: dict[str, Any]) -> str:
    return str(row.get("statement") or row.get("name") or row.get("title") or "")


def diff_payloads(old: dict[str, Any], new: dict[str, Any]) -> list[SectionDiff]:
    """Compara por código (REQ-001, AE-002, RK-003, WP-004…): altas, bajas y cambios campo a campo."""
    out = []
    for key, title in SECTIONS:
        a = {r["code"]: r for r in old.get(key, []) if r.get("code")}
        b = {r["code"]: r for r in new.get(key, []) if r.get("code")}
        sec = SectionDiff(key, title)
        for code in sorted(b.keys() - a.keys()):
            sec.added.append(Change(code, _label(b[code])))
        for code in sorted(a.keys() - b.keys()):
            sec.removed.append(Change(code, _label(a[code])))
        for code in sorted(a.keys() & b.keys()):
            fields = [
                (f, a[code].get(f), b[code].get(f))
                for f in sorted(set(a[code]) | set(b[code]))
                if f not in _IGNORE and a[code].get(f) != b[code].get(f)
            ]
            if fields:
                sec.changed.append(Change(code, _label(b[code]), fields))
        out.append(sec)
    return out
