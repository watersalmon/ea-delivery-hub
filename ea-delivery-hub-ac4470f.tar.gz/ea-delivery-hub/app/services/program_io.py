"""Export / import JSON completo de un programa (CLAUDE.md §7.18).

Formato: {"format": "ea-delivery-hub/program", "version": 1, "program": {...}, "tables": {...}}.
Al importar se crea un programa nuevo: todos los ids se reasignan y se reescriben las claves foráneas, las
referencias polimórficas de TraceLink y las claves de hash de las baselines (BASE-01).
"""

from __future__ import annotations

import json
from datetime import date, datetime
from typing import Any

from sqlalchemy import inspect as sa_inspect
from sqlmodel import Session, SQLModel, col, select

from app.models import PROGRAM_TABLES, Baseline, Program, TraceLink, utcnow

FORMAT = "ea-delivery-hub/program"
VERSION = 1
_META = {"created_at", "created_by", "updated_at", "updated_by"}
# Tipos de TraceLink -> tabla
TRACE_TABLES = {
    "outcome": "outcome",
    "objective": "objective",
    "requirement": "requirement",
    "arch_element": "architectureelement",
    "adr": "adr",
    "test_evidence": "testevidence",
    "gate": "gate",
    "raid": "raiditem",
    "meeting": "meeting",
}
# Orden de inserción: padres antes que hijos (inverso del orden de borrado)
INSERT_ORDER: tuple[type[SQLModel], ...] = tuple(reversed(PROGRAM_TABLES))


class ImportError_(ValueError):
    """El fichero no es un export válido de EA Delivery Hub."""


def _table(model: type[SQLModel]) -> str:
    return str(model.__tablename__)


def _fks(model: type[SQLModel]) -> dict[str, str]:
    """Columna -> tabla referenciada (excluye program_id, que se trata aparte)."""
    out = {}
    for column in sa_inspect(model).columns:  # type: ignore[union-attr]
        for fk in column.foreign_keys:
            if column.key != "program_id":
                out[column.key] = fk.column.table.name
    return out


def _dump(obj: SQLModel) -> dict[str, Any]:
    return {k: v for k, v in obj.model_dump(mode="json").items() if k not in _META}


def export_program(session: Session, program_id: int) -> dict[str, Any]:
    program = session.get(Program, program_id)
    if program is None:
        raise LookupError(f"Program {program_id} not found")
    tables = {}
    for model in INSERT_ORDER:
        m: Any = model
        rows = session.exec(select(m).where(m.program_id == program_id).order_by(col(m.id))).all()
        tables[_table(model)] = [_dump(r) for r in rows]
    return {
        "format": FORMAT,
        "version": VERSION,
        "exported_at": utcnow().isoformat(),
        "program": _dump(program),
        "tables": tables,
    }


def _coerce(model: type[SQLModel], data: dict[str, Any]) -> dict[str, Any]:
    """Convierte las fechas ISO del JSON a date/datetime según la anotación del campo."""
    out = dict(data)
    for key, field in model.model_fields.items():
        v = out.get(key)
        if not isinstance(v, str):
            continue
        ann = str(field.annotation)
        if "datetime" in ann:
            out[key] = datetime.fromisoformat(v)
        elif "date" in ann:
            out[key] = date.fromisoformat(v)
    return out


def _unique_code(session: Session, code: str) -> str:
    existing = set(session.exec(select(Program.code)).all())
    if code not in existing:
        return code
    n = 2
    while f"{code}-{n}" in existing:
        n += 1
    return f"{code}-{n}"


def import_program(session: Session, payload: dict[str, Any], *, name: str | None = None) -> Program:
    if not isinstance(payload, dict) or payload.get("format") != FORMAT or "program" not in payload:
        raise ImportError_("This file is not an EA Delivery Hub program export.")
    if payload.get("version") != VERSION:
        raise ImportError_(f"Unsupported export version {payload.get('version')}.")
    tables: dict[str, list[dict[str, Any]]] = payload.get("tables") or {}
    pdata = {k: v for k, v in payload["program"].items() if k != "id"}
    pdata["code"] = _unique_code(session, str(pdata.get("code") or "IMPORTED"))
    pdata["is_demo"] = False
    if name:
        pdata["name"] = name
    program = Program(**_coerce(Program, pdata))
    session.add(program)
    session.flush()
    assert program.id is not None

    idmap: dict[str, dict[int, int]] = {}
    pending_self: list[tuple[SQLModel, str, str, int]] = []  # (obj, columna, tabla, id antiguo)
    for model in INSERT_ORDER:
        tname = _table(model)
        fks = _fks(model)
        idmap.setdefault(tname, {})
        for row in tables.get(tname, []):
            data = dict(row)
            old_id = data.pop("id", None)
            data["program_id"] = program.id
            for column, target in fks.items():
                ref = data.get(column)
                if ref is None:
                    continue
                if target == tname:  # autorreferencia: se resuelve en una segunda pasada
                    data[column] = None
                    continue
                mapped = idmap.get(target, {}).get(int(ref))
                data[column] = mapped
            obj = model(**_coerce(model, data))
            session.add(obj)
            session.flush()
            if old_id is not None:
                idmap[tname][int(old_id)] = obj.id  # type: ignore[attr-defined]
            for column, target in fks.items():
                if target == tname and row.get(column) is not None:
                    pending_self.append((obj, column, tname, int(row[column])))
    for obj, column, tname, old in pending_self:
        setattr(obj, column, idmap[tname].get(old))
        session.add(obj)

    # Referencias polimórficas de la RTM y claves de hash de las baselines
    for link in session.exec(select(TraceLink).where(TraceLink.program_id == program.id)).all():
        link.src_id = idmap.get(TRACE_TABLES.get(link.src_type, ""), {}).get(link.src_id, 0)
        link.dst_id = idmap.get(TRACE_TABLES.get(link.dst_type, ""), {}).get(link.dst_id, 0)
        session.add(link)
    for baseline in session.exec(select(Baseline).where(Baseline.program_id == program.id)).all():
        hashes = json.loads(baseline.element_hashes or "{}")
        remapped = {}
        for key, value in hashes.items():
            etype, _, raw = key.partition(":")
            new_id = idmap.get(TRACE_TABLES.get(etype, ""), {}).get(int(raw)) if raw.isdigit() else None
            if new_id is not None:
                remapped[f"{etype}:{new_id}"] = value
        baseline.element_hashes = json.dumps(remapped, sort_keys=True)
        session.add(baseline)
    session.flush()
    return program


def comparable(payload: dict[str, Any]) -> dict[str, Any]:
    """Vista del export sin ids, metadatos ni código: sirve para comprobar el round-trip."""

    def strip(row: dict[str, Any]) -> dict[str, Any]:
        return {
            k: v for k, v in row.items() if not (k == "id" or k.endswith("_id") or k in {"src_id", "dst_id"})
        }

    prog = {k: v for k, v in payload["program"].items() if k not in {"id", "code", "is_demo"}}
    tables = {
        t: sorted((json.dumps(strip(r), sort_keys=True) for r in rows if t != "baseline"), key=str)
        for t, rows in payload["tables"].items()
    }
    tables["baseline"] = sorted(
        json.dumps({k: v for k, v in r.items() if k in {"version", "sha256", "approved_by"}}, sort_keys=True)
        for r in payload["tables"].get("baseline", [])
    )
    links = payload["tables"].get("tracelink", [])
    tables["tracelink_types"] = sorted(f"{lk['src_type']}->{lk['dst_type']}" for lk in links)
    return {"program": prog, "tables": tables}
