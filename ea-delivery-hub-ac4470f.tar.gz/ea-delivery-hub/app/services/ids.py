"""IDs legibles con prefijo, correlativos por programa y prefijo (PDR-003 #6)."""

from __future__ import annotations

from sqlmodel import Session, select

from app.models import IdSequence

# Ancho y forma del ID por prefijo: Goal-001 / Obj-001 como la captura 2; resto PREFIJO-001
_LABELS = {"GOAL": "Goal", "OBJ": "Obj"}


def next_code(session: Session, program_id: int, prefix: str, width: int = 3) -> str:
    key = prefix.upper()
    seq = session.exec(
        select(IdSequence).where(IdSequence.program_id == program_id, IdSequence.prefix == key)
    ).first()
    if seq is None:
        seq = IdSequence(program_id=program_id, prefix=key, last=0)
    seq.last += 1
    session.add(seq)
    return f"{_LABELS.get(key, key)}-{seq.last:0{width}d}"
