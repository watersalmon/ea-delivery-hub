"""Borrado de registros con comprobación de dependencias (PDR-011).

Para cada registro se calcula un plan con tres listas:
- ``cascade``: detalle propio que se borra con él (updates, opciones, criterios, celdas de la RACI…).
- ``detach``: relaciones que se quitan (enlaces de la RTM y referencias opcionales de otros registros).
- ``blockers``: registros que dependen de él y que hay que resolver antes; mientras haya alguno no se borra.

El plan se vuelve a calcular al confirmar, así que lo que se ejecuta es siempre lo que se ha mostrado
con los datos de ese momento. El AuditLog registra cada baja y cada cambio de referencia.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import and_, or_
from sqlmodel import Session, SQLModel, col, select

from app.config import data_dir
from app.models import (
    ADR,
    PROGRAM_TABLES,
    ADROption,
    ADRStatusChange,
    ArchitectureDiagram,
    ArchitectureElement,
    Baseline,
    Dependency,
    DesignReview,
    Gate,
    GateCriterion,
    Goal,
    HandoverItem,
    Meeting,
    MeetingDecision,
    Objective,
    ORRCheck,
    Outcome,
    Program,
    RACIActivity,
    RACIAssignment,
    RACIRole,
    RAIDItem,
    RAIDUpdate,
    Requirement,
    ReviewItem,
    Stakeholder,
    TestEvidence,
    TraceLink,
    WorkPackage,
    Workstream,
)
from app.services.governance import TAB_BY_TYPE


@dataclass
class Entry:
    text: str
    url: str = ""


@dataclass
class Plan:
    label: str
    noun: str
    back: str
    cascade: list[Entry] = field(default_factory=list)
    detach: list[Entry] = field(default_factory=list)
    blockers: list[Entry] = field(default_factory=list)
    ops: list[Callable[[], None]] = field(default_factory=list)  # se ejecutan antes de borrar el registro

    @property
    def allowed(self) -> bool:
        return not self.blockers


# ------------------------------------------------------------------ etiquetas y enlaces

TRACE_MODELS: dict[str, type[SQLModel]] = {
    "outcome": Outcome,
    "objective": Objective,
    "requirement": Requirement,
    "arch_element": ArchitectureElement,
    "adr": ADR,
    "test_evidence": TestEvidence,
    "gate": Gate,
    "raid": RAIDItem,
    "meeting": Meeting,
}


def _code(obj: Any) -> str:
    if obj is None:
        return "?"
    if isinstance(obj, Meeting):
        return f"{obj.forum} {obj.meeting_date:%d %b %Y}"
    return str(getattr(obj, "code", None) or getattr(obj, "name", None) or getattr(obj, "title", "?"))


def _url(obj: Any) -> str:
    if isinstance(obj, RAIDItem):
        return f"/raid?tab={TAB_BY_TYPE.get(obj.type, 'risks')}#{obj.code}"
    if isinstance(obj, Requirement | ArchitectureElement):
        return f"/rtm#{obj.code}" if isinstance(obj, Requirement) else f"/architecture#{obj.code}"
    if isinstance(obj, ADR):
        return f"/adr/{obj.code}"
    if isinstance(obj, Objective | Goal | Outcome):
        return f"/goals#{obj.code}"
    if isinstance(obj, WorkPackage):
        return f"/gates#{obj.code}"
    if isinstance(obj, Gate):
        return f"/gates#{obj.code}"
    if isinstance(obj, Meeting):
        return f"/design-authority/{obj.id}"
    if isinstance(obj, DesignReview):
        return f"/architecture/review/{obj.id}"
    return ""


def _trace_links(session: Session, kind: str, obj_id: int) -> list[TraceLink]:
    return list(
        session.exec(
            select(TraceLink).where(
                or_(
                    and_(col(TraceLink.src_type) == kind, col(TraceLink.src_id) == obj_id),
                    and_(col(TraceLink.dst_type) == kind, col(TraceLink.dst_id) == obj_id),
                )
            )
        ).all()
    )


def _deleter(session: Session, row: Any) -> Callable[[], None]:
    def op() -> None:
        session.delete(row)

    return op


def _remove_file(stored_as: str) -> Callable[[], None]:
    def op() -> None:
        (data_dir() / "uploads" / stored_as).unlink(missing_ok=True)

    return op


def _detach_links(plan: Plan, session: Session, kind: str, obj: Any) -> None:
    for link in _trace_links(session, kind, obj.id):
        other_type, other_id = (
            (link.dst_type, link.dst_id)
            if link.src_type == kind and link.src_id == obj.id
            else (link.src_type, link.src_id)
        )
        model = TRACE_MODELS.get(other_type)
        other = session.get(model, other_id) if model else None
        plan.detach.append(Entry(f"Link {_code(obj)} ↔ {_code(other)}", _url(other)))
        plan.ops.append(_deleter(session, link))


def _clear_refs(plan: Plan, session: Session, model: type[Any], column: str, obj: Any, what: str) -> None:
    """Referencias opcionales (FK nullable) de otros registros: se ponen a vacío."""
    rows = session.exec(select(model).where(getattr(model, column) == obj.id)).all()
    for row in rows:
        plan.detach.append(Entry(f"{_code(row)} loses its {what}", _url(row)))

        def op(row: Any = row) -> None:
            setattr(row, column, None)
            session.add(row)

        plan.ops.append(op)


def _cascade(plan: Plan, session: Session, model: type[Any], column: str, obj: Any, describe: str) -> None:
    rows = session.exec(select(model).where(getattr(model, column) == obj.id)).all()
    if rows:
        plan.cascade.append(Entry(f"{len(rows)} {describe}"))
        plan.ops.extend(_deleter(session, row) for row in rows)


def _block(plan: Plan, rows: list[Any], text: Callable[[Any], str]) -> None:
    plan.blockers.extend(Entry(text(r), _url(r)) for r in rows)


# ------------------------------------------------------------------ planes por tipo de registro


def _plan_raid(session: Session, item: RAIDItem, plan: Plan) -> None:
    _cascade(plan, session, RAIDUpdate, "raid_item_id", item, "dated update(s)")
    _clear_refs(plan, session, RAIDItem, "source_risk_id", item, "source risk")
    _clear_refs(plan, session, ReviewItem, "raid_item_id", item, "link to this RAID item")
    _detach_links(plan, session, "raid", item)


def _plan_goal(session: Session, goal: Goal, plan: Plan) -> None:
    objs = session.exec(select(Objective).where(Objective.goal_id == goal.id)).all()
    _block(plan, list(objs), lambda o: f"{o.code} belongs to this goal: delete it first")


def _plan_traced(kind: str) -> Callable[[Session, Any, Plan], None]:
    def plan_fn(session: Session, obj: Any, plan: Plan) -> None:
        _detach_links(plan, session, kind, obj)

    return plan_fn


def _plan_adr(session: Session, adr: ADR, plan: Plan) -> None:
    decisions = session.exec(select(MeetingDecision).where(MeetingDecision.adr_id == adr.id)).all()
    for d in decisions:
        meeting = session.get(Meeting, d.meeting_id)
        plan.blockers.append(
            Entry(f"On the agenda of {_code(meeting)}: remove it from the session first", _url(meeting))
        )
    gates = session.exec(select(Gate).where(Gate.waiver_adr_id == adr.id)).all()
    _block(plan, list(gates), lambda g: f"Waiver for gate {g.code}: remove the waiver first")
    _cascade(plan, session, ADROption, "adr_id", adr, "option(s)")
    _cascade(plan, session, ADRStatusChange, "adr_id", adr, "status change(s) in its history")
    _clear_refs(plan, session, ADR, "supersedes_id", adr, "'supersedes' reference")
    _clear_refs(plan, session, ReviewItem, "adr_id", adr, "link to this ADR")
    _detach_links(plan, session, "adr", adr)


def _plan_workstream(session: Session, ws: Workstream, plan: Plan) -> None:
    for model in (RAIDItem, Requirement, ArchitectureElement, WorkPackage, DesignReview):
        _clear_refs(plan, session, model, "workstream_id", ws, "workstream")


def _plan_workpackage(session: Session, wp: WorkPackage, plan: Plan) -> None:
    others = session.exec(
        select(WorkPackage).where(WorkPackage.program_id == wp.program_id, WorkPackage.id != wp.id)
    ).all()
    for other in others:
        deps = [d.strip() for d in other.depends_on.split(",") if d.strip()]
        if wp.code in deps:
            plan.detach.append(Entry(f"{other.code} no longer depends on {wp.code}", _url(other)))

            def op(other: WorkPackage = other, deps: list[str] = deps) -> None:
                other.depends_on = ", ".join(d for d in deps if d != wp.code)
                session.add(other)

            plan.ops.append(op)


def _plan_design_review(session: Session, review: DesignReview, plan: Plan) -> None:
    _cascade(plan, session, ReviewItem, "review_id", review, "checklist answer(s)")


def _plan_diagram(session: Session, diagram: ArchitectureDiagram, plan: Plan) -> None:
    plan.cascade.append(Entry(f"Uploaded file {diagram.filename}"))
    plan.ops.append(_remove_file(diagram.stored_as))


def _plan_meeting(session: Session, meeting: Meeting, plan: Plan) -> None:
    if meeting.status == "Closed":
        plan.blockers.append(
            Entry("The session is closed: its minutes are the record of the decisions taken")
        )
        return
    _cascade(
        plan, session, MeetingDecision, "meeting_id", meeting, "ADR(s) on its agenda (the ADRs are kept)"
    )
    _detach_links(plan, session, "meeting", meeting)


def _plan_meeting_decision(session: Session, decision: MeetingDecision, plan: Plan) -> None:
    meeting = session.get(Meeting, decision.meeting_id)
    if meeting is not None and meeting.status == "Closed":
        plan.blockers.append(Entry("The session is closed: its minutes cannot change", _url(meeting)))


def _plan_raci(column: str) -> Callable[[Session, Any, Plan], None]:
    def plan_fn(session: Session, obj: Any, plan: Plan) -> None:
        _cascade(plan, session, RACIAssignment, column, obj, "RACI cell(s)")

    return plan_fn


def _plan_program(session: Session, program: Program, plan: Plan) -> None:
    total = 0
    for model in PROGRAM_TABLES:
        rows = session.exec(select(model).where(model.program_id == program.id)).all()
        if rows:
            total += len(rows)
            plan.ops.extend(_deleter(session, row) for row in rows)
    plan.cascade.append(Entry(f"All its records ({total}): RAID, requirements, ADRs, gates, baselines…"))
    diagrams = session.exec(
        select(ArchitectureDiagram).where(ArchitectureDiagram.program_id == program.id)
    ).all()
    for d in diagrams:
        plan.ops.append(_remove_file(d.stored_as))


def _nothing(_session: Session, _obj: Any, _plan: Plan) -> None:
    return None


@dataclass(frozen=True)
class Kind:
    model: type[Any]
    noun: str
    back: Callable[[Any], str]
    plan: Callable[[Session, Any, Plan], None] = _nothing


DELETABLE: dict[str, Kind] = {
    "raid": Kind(RAIDItem, "RAID item", _url, _plan_raid),
    "dependency": Kind(Dependency, "dependency", lambda o: "/raid/dependencies"),
    "stakeholder": Kind(Stakeholder, "stakeholder", lambda o: "/stakeholders"),
    "raci_activity": Kind(
        RACIActivity, "RACI activity", lambda o: "/stakeholders?tab=raci", _plan_raci("activity_id")
    ),
    "raci_role": Kind(RACIRole, "RACI role", lambda o: "/stakeholders?tab=raci", _plan_raci("role_id")),
    "goal": Kind(Goal, "goal", lambda o: "/goals", _plan_goal),
    "objective": Kind(Objective, "objective", lambda o: "/goals", _plan_traced("objective")),
    "outcome": Kind(Outcome, "outcome", lambda o: "/goals", _plan_traced("outcome")),
    "requirement": Kind(Requirement, "requirement", lambda o: "/rtm", _plan_traced("requirement")),
    "arch_element": Kind(
        ArchitectureElement, "architecture element", lambda o: "/architecture", _plan_traced("arch_element")
    ),
    "test_evidence": Kind(TestEvidence, "test / evidence", lambda o: "/rtm", _plan_traced("test_evidence")),
    "adr": Kind(ADR, "ADR", lambda o: "/adr", _plan_adr),
    "adr_option": Kind(ADROption, "option", lambda o: "/adr"),
    "workstream": Kind(Workstream, "workstream", lambda o: "/admin#workstreams", _plan_workstream),
    "workpackage": Kind(WorkPackage, "work package", lambda o: "/gates#roadmap", _plan_workpackage),
    "gate_criterion": Kind(GateCriterion, "gate criterion", lambda o: "/gates"),
    "design_review": Kind(DesignReview, "design review", lambda o: "/architecture", _plan_design_review),
    "diagram": Kind(ArchitectureDiagram, "diagram", lambda o: "/architecture#diagrams", _plan_diagram),
    "meeting": Kind(Meeting, "Design Authority session", lambda o: "/design-authority", _plan_meeting),
    "meeting_decision": Kind(
        MeetingDecision, "agenda item", lambda o: f"/design-authority/{o.meeting_id}", _plan_meeting_decision
    ),
    "orr": Kind(ORRCheck, "readiness check", lambda o: "/orr"),
    "handover": Kind(HandoverItem, "handover item", lambda o: "/handover#items"),
    "program": Kind(Program, "program", lambda o: "/admin", _plan_program),
}


def label_for(obj: Any) -> str:
    if isinstance(obj, Baseline):
        return f"Baseline v{obj.version}"
    if isinstance(obj, Meeting):
        return _code(obj)
    if isinstance(obj, Program):
        return f"{obj.code} · {obj.name}"
    code = getattr(obj, "code", None)
    text = (
        getattr(obj, "title", None)
        or getattr(obj, "name", None)
        or getattr(obj, "statement", None)
        or getattr(obj, "objective", None)
        or getattr(obj, "description", None)
        or getattr(obj, "criterion", None)
        or ""
    )
    text = str(text)
    text = text if len(text) <= 90 else text[:87] + "…"
    return f"{code} · {text}" if code else text


def build_plan(session: Session, kind: str, obj: Any) -> Plan:
    spec = DELETABLE[kind]
    back = spec.back(obj)
    if isinstance(obj, ADROption):
        adr = session.get(ADR, obj.adr_id)
        back = _url(adr) or back
    plan = Plan(label=label_for(obj), noun=spec.noun, back=back)
    spec.plan(session, obj, plan)
    return plan


def execute(session: Session, kind: str, obj: Any) -> Plan:
    """Vuelve a calcular el plan y, si no hay bloqueos, quita relaciones, borra el detalle y el registro."""
    plan = build_plan(session, kind, obj)
    if not plan.allowed:
        return plan
    for op in plan.ops:
        op()
    session.flush()
    session.delete(obj)
    session.commit()
    return plan
