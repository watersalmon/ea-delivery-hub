"""Renderizador Markdown mínimo y seguro para el Playbook (sin dependencias nuevas, CLAUDE.md §11).

Soporta títulos, párrafos, listas (-, *, 1.), casillas (- [ ]), negrita, cursiva, código en línea,
enlaces relativos o http(s), citas (>) y tablas (| a | b |). El texto se escapa antes de dar formato.
"""

from __future__ import annotations

import re
from html import escape

from markupsafe import Markup

_LINK = re.compile(r"\[([^\]]+)\]\(((?:https?://|/|#)[^)\s]*)\)")


def _inline(text: str) -> str:
    out = escape(text, quote=False)
    out = re.sub(r"`([^`]+)`", r"<code>\1</code>", out)
    out = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", out)
    out = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", out)
    return _LINK.sub(
        lambda m: f'<a href="{escape(m.group(2))}" class="text-dell-blue hover:underline">{m.group(1)}</a>',
        out,
    )


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def render(md: str) -> Markup:
    html: list[str] = []
    lines = md.replace("\r\n", "\n").split("\n")
    i = 0
    para: list[str] = []

    def flush() -> None:
        if para:
            html.append(f"<p>{_inline(' '.join(para))}</p>")
            para.clear()

    while i < len(lines):
        line = lines[i].rstrip()
        stripped = line.strip()
        if not stripped:
            flush()
            i += 1
            continue
        m = re.match(r"^(#{1,3})\s+(.*)$", stripped)
        if m:
            flush()
            level = len(m.group(1)) + 1  # el H1 lo pone la página
            html.append(f'<h{level} id="{_slug(m.group(2))}">{_inline(m.group(2))}</h{level}>')
            i += 1
            continue
        if stripped.startswith("|"):
            flush()
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{3,}:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            if rows:
                head = "".join(f"<th>{_inline(c)}</th>" for c in rows[0])
                body = "".join(
                    "<tr>" + "".join(f"<td>{_inline(c)}</td>" for c in r) + "</tr>" for r in rows[1:]
                )
                html.append(
                    f'<table class="sheet"><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>'
                )
            continue
        if re.match(r"^([-*]|\d+\.)\s+", stripped):
            flush()
            ordered = bool(re.match(r"^\d+\.", stripped))
            items = []
            while i < len(lines) and re.match(r"^\s*([-*]|\d+\.)\s+", lines[i]):
                item = re.sub(r"^\s*([-*]|\d+\.)\s+", "", lines[i].rstrip())
                box = re.match(r"^\[( |x)\]\s+(.*)$", item)
                if box:
                    mark = "☑" if box.group(1) == "x" else "☐"
                    check = f'<span aria-hidden="true">{mark}</span>'
                    items.append(f'<li class="list-none">{check} {_inline(box.group(2))}</li>')
                else:
                    items.append(f"<li>{_inline(item)}</li>")
                i += 1
            tag = "ol" if ordered else "ul"
            html.append(f"<{tag}>{''.join(items)}</{tag}>")
            continue
        if stripped.startswith(">"):
            flush()
            quote = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                quote.append(lines[i].strip()[1:].strip())
                i += 1
            html.append(f"<blockquote>{_inline(' '.join(quote))}</blockquote>")
            continue
        para.append(stripped)
        i += 1
    flush()
    return Markup("\n".join(html))
