"""Seed idempotente de demostración (CLAUDE.md §9). `python -m app.services.seed`

Borra y recrea solo los programas con is_demo=True. Todo es ficticio: organizaciones, personas y proyectos.
Las fechas son relativas a hoy para que las reglas temporales (vencidos, SLA) se disparen siempre.
El conjunto de programas demo dispara las 16 reglas de §6 (verificado en tests/integration/test_seed.py).
"""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, date, datetime, timedelta
from typing import Any

from sqlmodel import Session, SQLModel, delete, select

from app.audit import audit_enabled
from app.content.guide import DA_AGENDA
from app.db import get_engine, init_db
from app.models import (
    ADR,
    PROGRAM_TABLES,
    ADROption,
    ADRStatusChange,
    ArchitectureBrief,
    ArchitectureElement,
    Baseline,
    Dependency,
    DesignReview,
    Gate,
    GateCriterion,
    Goal,
    HandoverItem,
    Meeting,
    MeetingDecision,
    Objective,
    ORRCheck,
    Outcome,
    Program,
    ProgramSettings,
    RACIActivity,
    RACIAssignment,
    RACIRole,
    RAIDItem,
    RAIDUpdate,
    Requirement,
    ReviewItem,
    Stakeholder,
    TestEvidence,
    TraceLink,
    WorkPackage,
    Workstream,
    current_user,
)
from app.models.enums import PHASE_NAMES, RAID_PREFIX, RAIDType
from app.rules.context import content_hash
from app.services.ids import next_code

# --------------------------------------------------------------------------- catálogos comunes

# Guía §4: pregunta clave y gate de salida por fase (G<n> = salida de la fase n)
GATES = [
    ("Is the solution deliverable?", "Visible risks; testable assumptions; defined handover."),
    ("Do we understand the real context?", "Context and requirements baselined."),
    ("Is the target architecture coherent?", "HLD and key decisions accepted."),
    ("Is there a viable path?", "Incremental plan agreed."),
    ("Is what was approved being implemented?", "Conformance or approved deviations."),
    ("Does it work and can it be operated?", "Acceptance and operational readiness."),
    ("What was achieved and what is next?", "Final architecture and backlog transferred."),
]

RACI_ROLES = ["EA", "PM / Delivery Lead", "Tech / Domain Lead", "Customer"]

# PDR-001: RACI de la guía §9 con un solo Accountable por actividad (TOGAF 10)
RACI_GUIDE: list[tuple[str, list[tuple[str, str]]]] = [
    ("Outcomes and end-to-end architecture", [("A/R", ""), ("C", ""), ("C", ""), ("C", "")]),
    ("Plan, cost, resources and reporting", [("C", ""), ("A/R", ""), ("C", ""), ("C", "")]),
    ("Detailed domain design", [("A/C", ""), ("I", ""), ("R", ""), ("C", "")]),
    ("Architecture governance", [("A/R", ""), ("C", ""), ("C", ""), ("C", "")]),
    ("Program RAID", [("R", "technical"), ("A/R", ""), ("R", "domain"), ("C", "")]),
    ("Acceptance and priorities", [("C", ""), ("R", "coordination"), ("C", ""), ("A", "")]),
    ("Contractual changes", [("C", ""), ("A/R", ""), ("C", ""), ("C", "")]),
]

ORR_DIMENSIONS = [
    ("Monitoring", "Platform and service alerts routed to the customer NOC"),
    ("Backup", "Backup policies tested with a restore drill"),
    ("Support", "Support model, L1-L3 and escalation matrix agreed"),
    ("Access", "Privileged access managed through the customer PAM"),
    ("Capacity", "Capacity baseline and growth thresholds defined"),
    ("Runbooks", "Runbooks reviewed and accepted by operations"),
    ("Skills", "Operations team trained and shadowing completed"),
    ("DR / RTO-RPO", "DR test executed against agreed RTO/RPO"),
]


class Builder:
    """Ayudante para crear entidades de un programa con IDs correlativos."""

    def __init__(self, session: Session, program: Program, today: date) -> None:
        self.s = session
        self.p = program
        self.today = today
        assert program.id is not None
        self.pid: int = program.id

    def add(self, obj: SQLModel) -> Any:
        self.s.add(obj)
        self.s.flush()
        return obj

    def code(self, prefix: str) -> str:
        return next_code(self.s, self.pid, prefix)

    def d(self, days: int) -> date:
        return self.today + timedelta(days=days)

    def link(self, src: Any, dst: Any, when: datetime | None = None) -> None:
        kw: dict[str, Any] = {}
        if when is not None:
            kw["created_at"] = when
        self.add(
            TraceLink(
                program_id=self.pid,
                src_type=_trace_type(src),
                src_id=src.id,
                dst_type=_trace_type(dst),
                dst_id=dst.id,
                **kw,
            )
        )

    def settings(self, **kw: Any) -> None:
        self.add(ProgramSettings(program_id=self.pid, **kw))

    def gates(self, passed_through: int) -> list[Gate]:
        gates = []
        for n, (question, exit_criteria) in enumerate(GATES):
            if n < passed_through:
                status, passed_at = "Passed", self.d(-30 * (passed_through - n))
            elif n == passed_through:
                status, passed_at = "In Progress", None
            else:
                status, passed_at = "Not Started", None
            gate = self.add(
                Gate(
                    program_id=self.pid,
                    code=f"G{n}",
                    phase=n,
                    name=f"G{n} · {PHASE_NAMES[n]}",
                    key_question=question,
                    exit_criteria=exit_criteria,
                    status=status,
                    approver=self.p.sponsor,
                    passed_at=passed_at,
                )
            )
            for crit in exit_criteria.rstrip(".").split("; "):
                self.add(
                    GateCriterion(
                        program_id=self.pid,
                        gate_id=gate.id,
                        criterion=crit[0].upper() + crit[1:],
                        evidence_required="Signed-off artifact in the repository",
                        status="Met" if status == "Passed" else "Open",
                        approver=self.p.sponsor,
                    )
                )
            gates.append(gate)
        return gates

    def raci(self, extra: list[tuple[str, list[tuple[str, str]]]] | None = None) -> None:
        roles = [self.add(RACIRole(program_id=self.pid, name=n, order=i)) for i, n in enumerate(RACI_ROLES)]
        for order, (name, values) in enumerate(RACI_GUIDE + (extra or [])):
            act = self.add(RACIActivity(program_id=self.pid, name=name, order=order))
            for role, (value, qualifier) in zip(roles, values, strict=True):
                self.add(
                    RACIAssignment(
                        program_id=self.pid,
                        activity_id=act.id,
                        role_id=role.id,
                        value=value,
                        qualifier=qualifier,
                    )
                )

    def raid(self, type_: RAIDType, **kw: Any) -> RAIDItem:
        kw.setdefault("organization", "Dell")
        kw.setdefault("date_added", self.d(-40))
        kw.setdefault("monitor_status", "Open")
        return self.add(RAIDItem(program_id=self.pid, type=type_, code=self.code(RAID_PREFIX[type_]), **kw))

    def req(self, kind: str = "FR", **kw: Any) -> Requirement:
        return self.add(
            Requirement(
                program_id=self.pid, kind=kind, code=self.code("NFR" if kind == "NFR" else "REQ"), **kw
            )
        )

    def baseline(self, version: int, approved_by: str, approved_at: datetime) -> Baseline:
        from app.services.baselines import snapshot_payload

        payload = snapshot_payload(self.s, self.pid)
        reqs = self.s.exec(select(Requirement).where(Requirement.program_id == self.pid)).all()
        aes = self.s.exec(select(ArchitectureElement).where(ArchitectureElement.program_id == self.pid)).all()
        raw = json.dumps(payload, sort_keys=True)
        hashes = {f"requirement:{r.id}": content_hash(r) for r in reqs}
        hashes.update({f"arch_element:{a.id}": content_hash(a) for a in aes})
        return self.add(
            Baseline(
                program_id=self.pid,
                version=version,
                approved_by=approved_by,
                approved_at=approved_at,
                sha256=hashlib.sha256(raw.encode()).hexdigest(),
                payload=raw,
                element_hashes=json.dumps(hashes, sort_keys=True),
            )
        )


def _trace_type(obj: Any) -> str:
    mapping: dict[type[Any], str] = {
        Outcome: "outcome",
        Objective: "objective",
        Requirement: "requirement",
        ArchitectureElement: "arch_element",
        ADR: "adr",
        TestEvidence: "test_evidence",
        Gate: "gate",
        RAIDItem: "raid",
        Meeting: "meeting",
    }
    return mapping[type(obj)]


def _dt(d: date) -> datetime:
    return datetime(d.year, d.month, d.day, 9, 0, tzinfo=UTC)


# --------------------------------------------------------------------------- programa 1 (principal)


def seed_sovereign_cloud(session: Session, today: date) -> Program:
    p = Program(
        code="SPC-AASD",
        name="Sovereign Private Cloud",
        client="Agencia Atlántica de Servicios Digitales (fictitious)",
        sponsor="Elena Varga (CIO)",
        pm="Tomás Ribeiro",
        ea="Inés Calderón",
        phase=4,
        applicable_frameworks="National security scheme (configurable); internal data residency policy",
        operations_owner="",  # OPS-01: operaciones sin owner en fase de delivery
        operations_engaged=False,
        start_date=today - timedelta(days=150),
        is_demo=True,
    )
    session.add(p)
    session.flush()
    b = Builder(session, p, today)
    b.settings()

    ws = {
        name: b.add(Workstream(program_id=b.pid, name=name, lead=lead, scope=scope))
        for name, lead, scope in [
            ("Compute & Storage", "Marta Quiroga", "VxRail/PowerFlex clusters, block and file storage"),
            ("Data Protection & Cyber Recovery", "Daniel Okafor", "Backup, immutable vault, cyber recovery"),
            ("Networking", "Lucía Ferrán", "DC fabric, WAN, segmentation"),
            ("Security & Sovereignty", "Pablo Ibarra", "Identity, key management, data residency"),
            ("Operations & Capacity Planning", "Sara Lindqvist", "Monitoring, capacity, runbooks"),
            ("Migration", "Hugo Almeida", "Workload migration waves and cutover"),
        ]
    }

    for name, org, role, inf, intr, stance, dm, channel, cadence, msg in [
        ("Elena Varga", "Customer", "CIO / Sponsor", 5, 5, "Sponsor", True, "SteerCo", "Monthly",
         "Sovereign cloud on time with predictable cost"),
        ("Jorge Salvat", "Customer", "CISO", 5, 4, "Neutral", True, "Customer architecture review", "Bi-weekly",
         "Residency and key custody under customer control"),
        ("Nuria Pons", "Customer", "Head of Infrastructure Operations", 4, 3, "Detractor", False,
         "1:1 + ops working group", "Weekly", "Operations will own a platform they can run with today's team"),
        ("Raúl Mendieta", "Customer", "Procurement Manager", 3, 2, "Neutral", True, "Email", "On demand",
         "Purchase orders gate hardware delivery dates"),
        ("Tomás Ribeiro", "Dell", "Project Manager", 4, 5, "Sponsor", False, "EA-PM alignment", "Weekly",
         "Plan, RAID and changes stay in sync"),
        ("Inés Calderón", "Dell", "Enterprise Architect", 4, 5, "Sponsor", False, "Design Authority", "Weekly",
         "Decisions before documents"),
        ("Carla Domènech", "Partner", "Telco account manager", 2, 3, "Neutral", False, "Email", "Weekly",
         "WAN circuits are on the critical path"),
    ]:  # fmt: skip
        b.add(
            Stakeholder(
                program_id=b.pid, name=name, organization=org, role=role, influence=inf, interest=intr,
                stance=stance, is_decision_maker=dm, channel=channel, cadence=cadence, key_message=msg,
                comms_owner="Inés Calderón" if org != "Dell" else "Tomás Ribeiro",
            )
        )  # fmt: skip

    # Goals & Objectives (inspirados en la captura 2, con nombres ficticios)
    objectives: dict[str, Objective] = {}
    goals = [
        ("Build sovereign private cloud capabilities with a predictable consumption model", [
            ("iaas", "Implement Infrastructure-as-a-Service to host virtual and physical compute",
             "Go-live for IaaS service", "In Progress"),
            ("staas", "Implement Storage-as-a-Service for block storage of critical workloads",
             "Go-live for STaaS service", "In Progress"),
            ("faas", "Implement File-as-a-Service for file shares and home drives",
             "Go-live for FaaS service", "Not Started"),
            ("baas", "Implement Backup-as-a-Service to host backup and recovery",
             "Go-live for BaaS service", "In Progress"),
            ("craas", "Implement Cyber-Recovery-as-a-Service to protect production backups",
             "Go-live for CRaaS service", "At Risk"),
            ("vdiaas", "Implement VDI-as-a-Service for end-user compute",
             "Go-live for VDIaaS service", "Not Started"),
        ]),
        ("Maximise value and minimise cost", [
            ("capacity", "Develop a capacity planning program with visibility of growth patterns",
             "Capacity planning team and processes in place", "In Progress"),
            ("consumption", "Implement a predictable as-a-service consumption pricing model",
             "Completion of MVP (all services live)", "Not Started"),
            ("retire", "Enable legacy IT retirement with balanced IT spend",
             "Completion of migration waves 1-3", "Not Started"),
        ]),
        ("Guarantee data sovereignty and cyber resilience", [
            ("residency", "Keep all customer data and keys within national borders",
             "Residency controls verified by the CISO", "In Progress"),
        ]),
    ]  # fmt: skip
    for goal_title, objs in goals:
        goal = b.add(Goal(program_id=b.pid, code=b.code("GOAL"), title=goal_title))
        for key, text, criteria, status in objs:
            objectives[key] = b.add(
                Objective(
                    program_id=b.pid, goal_id=goal.id, code=b.code("OBJ"), objective=text,
                    acceptance_criteria=criteria, completion_status=status, approver="Elena Varga",
                )
            )  # fmt: skip

    for desc, metric, base, target, days in [
        ("Faster provisioning of infrastructure", "Lead time to provision a VM", "15 days", "< 1 day", 120),
        ("Predictable infrastructure spend", "Variance vs. consumption forecast", "±30%", "±5%", 270),
        ("Recover from a cyber event", "Time to restore critical services from the vault", "Unknown", "< 24 h",
         180),
    ]:  # fmt: skip
        b.add(
            Outcome(program_id=b.pid, code=b.code("OUT"), description=desc, metric=metric, baseline_value=base,
                    target_value=target, target_date=b.d(days))
        )  # fmt: skip

    ae = {
        key: b.add(
            ArchitectureElement(
                program_id=b.pid, code=b.code("AE"), name=name, view=view, workstream_id=ws[w].id,
                hld_ref=hld, lld_ref=lld,
            )
        )
        for key, name, view, w, hld, lld in [
            ("cluster", "Virtualisation clusters (2 sites)", "Technology", "Compute & Storage", "HLD §4.1", "LLD-CS-01"),
            ("block", "Software-defined block storage", "Technology", "Compute & Storage", "HLD §4.2", "LLD-CS-02"),
            ("file", "Scale-out file platform", "Technology", "Compute & Storage", "HLD §4.3", ""),
            ("backup", "Backup platform with immutable copies", "Data", "Data Protection & Cyber Recovery",
             "HLD §5.1", "LLD-DP-01"),
            ("vault", "Isolated cyber recovery vault", "Security", "Data Protection & Cyber Recovery", "HLD §5.2", ""),
            ("fabric", "Leaf-spine DC fabric and WAN edge", "Technology", "Networking", "HLD §6", "LLD-NW-01"),
            ("kms", "Customer-held key management", "Security", "Security & Sovereignty", "HLD §7", ""),
            ("portal", "Self-service portal and catalogue", "Application", "Operations & Capacity Planning",
             "HLD §8", ""),
            ("monitoring", "Monitoring and capacity analytics", "Operations", "Operations & Capacity Planning",
             "HLD §9", ""),
        ]
    }  # fmt: skip

    # Requisitos funcionales
    r = {}
    for key, stmt, prio, src, w, obj, elems in [
        ("vm", "Tenants can self-provision VMs from a service catalogue", "Must", "SOW §3.1",
         "Compute & Storage", "iaas", ["cluster", "portal"]),
        ("block", "Provide block volumes in three performance tiers", "Must", "SOW §3.2",
         "Compute & Storage", "staas", ["block"]),
        ("file", "Provide SMB/NFS shares with quotas per department", "Should", "Workshop W4",
         "Compute & Storage", "faas", ["file"]),
        ("backup", "Back up all production VMs daily with 30-day retention", "Must", "SOW §3.4",
         "Data Protection & Cyber Recovery", "baas", ["backup"]),
        ("vault", "Replicate critical backups to an isolated, air-gapped vault", "Must", "SOW §3.5",
         "Data Protection & Cyber Recovery", "craas", ["vault"]),
        ("showback", "Monthly consumption showback per tenant", "Should", "Presales",
         "Operations & Capacity Planning", "consumption", []),  # RTM-01 ámbar: sin elemento
        ("vdi", "Persistent virtual desktops for 1,500 users", "Must", "SOW §3.7",
         "Compute & Storage", None, []),  # RTM-01 rojo: huérfano Must
        ("keys", "Encryption keys generated and held by the customer", "Must", "Workshop W2",
         "Security & Sovereignty", "residency", ["kms"]),
    ]:  # fmt: skip
        req = b.req(statement=stmt, priority=prio, source=src, status="Approved", workstream_id=ws[w].id)
        r[key] = req
        if obj:
            b.link(objectives[obj], req)
        for e in elems:
            b.link(req, ae[e])

    # NFR medibles (uno vago para RTM-03)
    for key, cat, stmt, criterion, nfr_target, achieved, unit, elems in [
        ("avail", "Availability", "Platform availability for tier-1 services",
         ">= 99.95% monthly, excluding planned maintenance", 99.95, 99.97, "%", ["cluster"]),
        ("rpo", "RTO/RPO", "Recovery point and time objectives for tier-1 workloads",
         "RPO <= 15 min, RTO <= 4 h, proven in a DR test", 15, 20, "min RPO", ["backup"]),
        ("latency", "Performance", "Block storage latency for the gold tier",
         "p95 read latency <= 1 ms at 50k IOPS", 1.0, 0.8, "ms", ["block"]),
        ("capacity", "Capacity", "Usable capacity at go-live with growth headroom",
         ">= 2 PB usable with 30% free headroom", 2.0, 1.6, "PB", ["block", "file"]),
        ("immutable", "Retention", "Immutable retention of backup copies",
         "30-day immutable retention, verified quarterly", 30, 30, "days", ["vault"]),
        ("secure", "Security", "The platform must be highly secure", "", None, None, "", ["kms"]),
    ]:  # fmt: skip
        req = b.req(
            kind="NFR", nfr_category=cat, statement=stmt, priority="Must", measurable_criterion=criterion,
            target_value=nfr_target, achieved_value=achieved, unit=unit, source="SOW §4", status="Approved",
        )  # fmt: skip
        r[key] = req
        b.link(objectives["iaas"] if key != "immutable" else objectives["craas"], req)
        for e in elems:
            b.link(req, ae[e])

    for key, title, kind, res in [
        ("vm", "Catalogue provisioning test (UAT-01)", "Automated test", "Pass"),
        ("avail", "Failover test across sites", "Manual test", "Pass"),
        ("latency", "Storage performance benchmark", "Automated test", "Fail"),
    ]:
        te = b.add(
            TestEvidence(program_id=b.pid, code=b.code("TE"), title=title, kind=kind, result=res,
                         evidence_date=b.d(-10))
        )  # fmt: skip
        b.link(r[key], te)

    # ADRs en todos los estados
    adr_backup = b.add(
        ADR(
            program_id=b.pid, code=b.code("ADR"), title="Use immutable object storage as primary backup target",
            status="Approved", context="Ransomware resilience and 30-day retention requirement (NFR immutable).",
            decision="Backups land on immutable object storage; critical copies replicate to the vault.",
            conditions="Quarterly restore drill evidenced in the RAID log.",
            rationale="Best balance of cost, recovery time and immutability.",
            consequences="Extra capacity in site B; new runbooks for the operations team.",
            impacted_artifacts="HLD §5, LLD-DP-01, RTM, backup runbooks",
            impacted_workstreams="Data Protection & Cyber Recovery; Operations & Capacity Planning",
            cost_impact="+4% storage capex", schedule_impact="None", operations_impact="New restore runbook",
            escalation_level="Architecture", critical_path=True, owner="Daniel Okafor", due_date=b.d(-60),
            approvers="Inés Calderón; Jorge Salvat", submitted_at=b.d(-75), approved_at=b.d(-62),
        )
    )  # fmt: skip
    for name, pros, cons, chosen, scores in [
        ("Immutable object storage", "Immutability, scale-out", "New skills", True,
         {"alignment": 5, "security": 5, "operability": 3, "cost": 4, "schedule": 4, "reversibility": 3,
          "compliance": 5}),
        ("Deduplication appliance only", "Known by ops team", "No immutability at scale", False,
         {"alignment": 3, "security": 2, "operability": 5, "cost": 3, "schedule": 5, "reversibility": 4,
          "compliance": 2}),
    ]:  # fmt: skip
        b.add(ADROption(program_id=b.pid, adr_id=adr_backup.id, name=name, pros=pros, cons=cons,
                        chosen=chosen, scores=scores))  # fmt: skip
    for frm, to, days in [
        ("", "Proposed", -75),
        ("Proposed", "Under Review", -70),
        ("Under Review", "Approved", -62),
    ]:
        b.add(ADRStatusChange(program_id=b.pid, adr_id=adr_backup.id, from_status=frm, to_status=to,
                              changed_at=_dt(b.d(days))))  # fmt: skip
    b.link(ae["backup"], adr_backup)

    adr_fabric = b.add(
        ADR(program_id=b.pid, code=b.code("ADR"), title="Adopt leaf-spine fabric with EVPN for both sites",
            status="Approved", decision="Leaf-spine with EVPN-VXLAN.", rationale="Scales east-west traffic.",
            escalation_level="Architecture", owner="Lucía Ferrán", due_date=b.d(-40), submitted_at=b.d(-55),
            approved_at=b.d(-41))  # ADR-03: sin artefactos impactados
    )  # fmt: skip
    b.link(ae["fabric"], adr_fabric)
    adr_keys = b.add(
        ADR(program_id=b.pid, code=b.code("ADR"), title="Select key management model for data residency",
            status="Proposed", context="CISO requires customer-held keys inside national borders.",
            escalation_level="Executive", critical_path=True, submitted_at=b.d(-5))  # ADR-01: sin owner ni fecha
    )  # fmt: skip
    b.link(ae["kms"], adr_keys)
    adr_vdi = b.add(
        ADR(program_id=b.pid, code=b.code("ADR"), title="VDI broker: persistent vs. non-persistent pools",
            status="Under Review", escalation_level="Architecture", owner="Marta Quiroga",
            due_date=b.d(5), submitted_at=b.d(-30))  # ADR-02: supera el SLA de 10 días
    )  # fmt: skip
    b.add(ADR(program_id=b.pid, code=b.code("ADR"), title="Stretch clusters across sites",
              status="Rejected", rationale="Latency between sites above 5 ms.", owner="Marta Quiroga",
              escalation_level="Architecture", submitted_at=b.d(-90), approved_at=b.d(-85)))  # fmt: skip
    b.add(ADR(program_id=b.pid, code=b.code("ADR"), title="Public cloud burst for VDI peaks",
              status="Deferred", conditions="Revisit after wave 2.", owner="Inés Calderón",
              escalation_level="Program", due_date=b.d(60), submitted_at=b.d(-20)))  # fmt: skip

    # RAID (captura 1 + guía §8)
    def wsid(name: str) -> int | None:
        return ws[name].id

    rk_power = b.raid(
        RAIDType.RISK, title="Data centre power readiness for the new halls", workstream_id=wsid("Compute & Storage"),
        reported_by="Inés Calderón", owner="Raúl Mendieta", organization="Customer", probability=3, impact=3,
        cause="the utility grid upgrade for site B has not been scheduled",
        event="the new halls cannot power all racks at installation",
        consequence="IaaS and STaaS go-live slips and hardware sits idle",
        response="Phase rack power-on; temporary generators for the first rows",
        contingency_plan="Prioritise compute racks; defer VDI racks to wave 2",
        escalation_trigger="No confirmed grid date 30 days before rack delivery",
        escalation_forum="SteerCo", trigger_met=True,  # RAID-04: trigger cumplido sin escalation
        due_date=b.d(14), monitor_status="Action Required",
    )  # fmt: skip
    for days, text in [
        (-21, "Facilities confirmed partial capacity only; follow-up with the utility."),
        (-7, "Utility has not committed a date; generator rental quote requested."),
    ]:
        b.add(RAIDUpdate(program_id=b.pid, raid_item_id=rk_power.id or 0, update_date=b.d(days), text=text))
    rk_hw = b.raid(
        RAIDType.RISK, title="Extended lead time for storage hardware", workstream_id=wsid("Compute & Storage"),
        reported_by="Tomás Ribeiro", owner="Marta Quiroga", probability=3, impact=2,
        cause="global component shortages", event="storage nodes arrive 6 weeks late",
        consequence="migration wave 1 moves right", response="Split the order; ship compute first",
        contingency_plan="Temporary capacity on existing arrays", escalation_trigger="Vendor confirms > 8 weeks",
        escalation_forum="PM / Change Control", due_date=b.d(21), monitor_status="Monitoring",
    )  # fmt: skip
    b.raid(
        RAIDType.RISK, title="Access permits to the data centre for partner engineers",
        workstream_id=wsid("Migration"), reported_by="Hugo Almeida", owner="Nuria Pons", organization="Customer",
        probability=2, impact=3, cause="security vetting takes 4 weeks", event="engineers cannot access the halls",
        consequence="installation crews idle", response="Submit the vetting list in one batch",
        escalation_trigger="Permits not issued 5 days before install", escalation_forum="EA-PM alignment",
        due_date=b.d(-6), monitor_status="Action Required",  # RAID-03: vencido
    )  # fmt: skip
    b.raid(
        RAIDType.RISK, title="Data residency of backup metadata in the vendor support cloud",
        workstream_id=wsid("Security & Sovereignty"), reported_by="Jorge Salvat", organization="Customer",
        probability=3, impact=3, cause="phone-home telemetry includes backup catalogue metadata",
        event="metadata leaves national borders", consequence="residency non-compliance blocks go-live",
        escalation_trigger="CISO rejects the telemetry model", escalation_forum="Design Authority",
        due_date=b.d(10), monitor_status="Open",  # RAID-01: score 9 sin owner ni respuesta
    )  # fmt: skip
    b.raid(
        RAIDType.RISK, title="Third-party WAN provider capacity", workstream_id=wsid("Networking"),
        reported_by="Lucía Ferrán", owner="Lucía Ferrán", probability=2, impact=2,
        event="WAN circuits are not delivered in time", response="Weekly call with the provider",
        due_date=b.d(30), monitor_status="Monitoring",  # RAID-02: sin causa, consecuencia ni trigger
    )  # fmt: skip
    rk_skills = b.raid(
        RAIDType.RISK, title="Operations team skills for the new platform",
        workstream_id=wsid("Operations & Capacity Planning"), reported_by="Sara Lindqvist", owner="Sara Lindqvist",
        organization="Customer", probability=3, impact=2, cause="the team has no experience with SDS and vaults",
        event="incidents after handover are not resolved in time", consequence="SLA breaches and loss of trust",
        response="Training plan and 6-week shadowing", escalation_trigger="Training not started by wave 1",
        escalation_forum="SteerCo", trigger_met=True, due_date=b.d(25), monitor_status="In Progress",
    )  # fmt: skip
    b.raid(
        RAIDType.RISK, title="Licence true-up at the end of year one", reported_by="Tomás Ribeiro",
        owner="Tomás Ribeiro", probability=1, impact=2, cause="consumption grows faster than forecast",
        event="licence true-up exceeds budget", consequence="unplanned opex",
        response="Quarterly consumption review", escalation_trigger="Forecast deviation > 15%",
        escalation_forum="SteerCo", due_date=b.d(90), monitor_status="Monitoring",
    )  # fmt: skip
    b.raid(
        RAIDType.ESCALATION,
        title="Operations skills gap escalated to the sponsor",
        source_risk_id=rk_skills.id,
        owner="Tomás Ribeiro",
        due_date=b.d(7),
        escalation_forum="SteerCo",
        monitor_status="In Progress",
    )
    b.raid(RAIDType.ISSUE, title="Storage nodes for site B delayed 4 weeks", source_risk_id=rk_hw.id,
           owner="Marta Quiroga", severity="High", impact=3, due_date=b.d(12), monitor_status="Action Required",
           description="Vendor confirmed partial shipment.")  # fmt: skip
    b.raid(
        RAIDType.ACTION,
        title="Send consolidated vetting list for partner engineers",
        owner="Hugo Almeida",
        due_date=b.d(-3),
        monitor_status="Open",
    )  # RAID-03
    b.raid(
        RAIDType.ACTION,
        title="Book DR test window with the customer",
        owner="Daniel Okafor",
        due_date=b.d(20),
    )
    b.raid(
        RAIDType.DECISION,
        title="Backup target decision recorded as ADR",
        owner="Inés Calderón",
        monitor_status="Closed",
        description=adr_backup.code,
    )
    change = b.raid(
        RAIDType.CHANGE,
        title="Add a fourth block storage tier for archive workloads",
        owner="Tomás Ribeiro",
        scope_impact="New tier in STaaS catalogue",
        cost_impact="+1.5%",
        schedule_impact="None",
        change_control_decision="Approved",
        monitor_status="Closed",
    )
    b.raid(
        RAIDType.COMM,
        title="Monthly SteerCo pack with RAID and health check",
        owner="Tomás Ribeiro",
        due_date=b.d(10),
        monitor_status="In Progress",
    )
    b.raid(
        RAIDType.LESSON,
        title="Engage facilities before ordering hardware",
        owner="Inés Calderón",
        context="Racks ordered before power capacity was confirmed.",
        decision_taken="Phased rack power-on with generators.",
        result="Two-week delay instead of six.",
        recommendation="Add power and cooling confirmation as a G3 criterion.",
        monitor_status="Closed",
    )

    # Dependencias (§8.1)
    for title, src, tgt, ext, verified, on_cp, days, ev in [
        ("WAN circuits between sites", "Networking", "Telco provider (fictitious)", True, False, True, 20, ""),
        ("Storage hardware delivery", "Compute & Storage", "Hardware vendor", True, True, True, 25,
         "Order acknowledgement with ship dates"),
        ("Power and cooling for new halls", "Compute & Storage", "Customer facilities", True, False, False, 30, ""),
        ("Key management design", "Data Protection & Cyber Recovery", "Security & Sovereignty", False, False,
         True, 15, ""),
    ]:  # fmt: skip
        b.add(Dependency(program_id=b.pid, code=b.code("DEP"), title=title, source=src, target=tgt,
                         external=ext, commitment_verified=verified, critical_path=on_cp, need_date=b.d(days),
                         evidence=ev, owner="Inés Calderón"))  # fmt: skip

    gates = {g.code: g for g in b.gates(passed_through=4)}
    # Gate en el que se acepta cada requisito (columna Gate de la RTM)
    for req in r.values():
        b.link(req, gates["G5" if req.priority == "Must" else "G6"])
    b.raci(
        extra=[
            ("Data residency sign-off", [("A/C", ""), ("I", ""), ("R", ""), ("A", "")]),  # RACI-01: doble A
            ("Capacity planning reviews", [("C", ""), ("A/C", ""), ("C", ""), ("I", "")]),  # RACI-02: sin R
        ]
    )

    quorum = [
        {"role": "Enterprise Architect", "name": "Inés Calderón", "present": True},
        {"role": "Tech / Domain Leads", "name": "Daniel Okafor, Marta Quiroga", "present": True},
        {"role": "Customer", "name": "Jorge Salvat", "present": True},
        {"role": "SMEs as needed", "name": "", "present": False},
        {"role": "PM (informed)", "name": "Tomás Ribeiro", "present": True},
    ]
    agenda = "; ".join(f"{m} min · {t}" for m, t in DA_AGENDA)
    da = b.add(Meeting(program_id=b.pid, forum="Architecture Design Authority", meeting_date=b.d(-62), status="Closed",
                       quorum_met=True, attendees="EA; Tech Leads; CISO; PM", agenda=agenda, participants=quorum,
                       notes="ADR approved with conditions.", started_at=_dt(b.d(-62)), closed_at=_dt(b.d(-62))))  # fmt: skip
    b.link(da, adr_backup)
    b.add(MeetingDecision(program_id=b.pid, meeting_id=da.id, adr_id=adr_backup.id, outcome="Approved",
                          conditions="Quarterly restore drill evidenced in the RAID log.", owner="Daniel Okafor",
                          due_date=b.d(-60)))  # fmt: skip
    nxt = b.add(Meeting(program_id=b.pid, forum="Architecture Design Authority", meeting_date=b.d(5), agenda=agenda,
                        participants=[{**p, "present": False} for p in quorum]))  # fmt: skip
    for order, adr in enumerate((adr_keys, adr_vdi)):
        b.add(MeetingDecision(program_id=b.pid, meeting_id=nxt.id, adr_id=adr.id, order=order, owner=adr.owner,
                              due_date=adr.due_date))  # fmt: skip

    # Roadmap: work packages, hitos y transition states
    for name, w, start, end, ms, ts, dep, gate, status in [
        ("Landing zone and management cluster", "Compute & Storage", -120, -70, False, "TS1 · Foundation", "", "G3", "Done"),
        ("DC fabric and WAN edge", "Networking", -100, -40, False, "TS1 · Foundation", "", "G3", "Done"),
        ("Backup platform and immutable copies", "Data Protection & Cyber Recovery", -60, 20, False, "TS2 · Protected", "WP-001", "G4", "In Progress"),
        ("Site B storage expansion", "Compute & Storage", -20, 45, False, "TS2 · Protected", "WP-001", "G4", "At Risk"),
        ("Key management and residency controls", "Security & Sovereignty", -10, 40, False, "TS2 · Protected", "", "G4", "In Progress"),
        ("IaaS and STaaS go-live", "Compute & Storage", 50, 50, True, "TS3 · Services live", "WP-003, WP-004", "G5", "Planned"),
        ("Migration waves 1-3", "Migration", 55, 150, False, "TS3 · Services live", "WP-006", "G5", "Planned"),
        ("Cyber recovery vault and DR test", "Data Protection & Cyber Recovery", 30, 90, False, "TS3 · Services live", "WP-003", "G5", "Planned"),
        ("Operational acceptance", "Operations & Capacity Planning", 140, 140, True, "TS4 · Run", "WP-007", "G6", "Planned"),
    ]:  # fmt: skip
        b.add(WorkPackage(program_id=b.pid, code=b.code("WP"), name=name, workstream_id=ws[w].id, start=b.d(start),
                          end=b.d(end), milestone=ms, transition_state=ts, depends_on=dep, gate_code=gate, status=status))  # fmt: skip

    # Architecture Brief (§13.1)
    b.add(ArchitectureBrief(
        program_id=b.pid,
        outcomes="Provision infrastructure in under one day (today 15 days). Predictable spend within ±5% of forecast. "
                 "Recover critical services from a cyber event in under 24 h.",
        scope_in="Two-site sovereign private cloud: IaaS, STaaS, FaaS, BaaS, CRaaS and VDIaaS; capacity planning; migration waves 1-3.",
        scope_out="Application refactoring; end-user devices; public cloud workloads; third-party WAN contracts.",
        context="Customer data centres A and B; existing virtualisation estate; national security scheme and data residency policy.",
        principles="Data and keys stay in-country. Operations-ready from day one. Prefer reversible decisions. "
                   "Every requirement traced to an outcome.",
        workstreams="Six workstreams. Critical dependencies: WAN circuits (telco), power for the new halls (facilities), "
                    "storage hardware (vendor).",
        risks_assumptions="Power readiness of the new halls (RK-001); data residency of backup metadata (RK-004); "
                          "operations skills (RK-006). Assumption: customer PAM available for privileged access.",
        open_decisions="ADR-003 key management model (no owner yet); ADR-004 VDI broker pools (overdue for DA).",
        governance="Weekly Design Authority; weekly EA-PM alignment; monthly SteerCo chaired by the CIO. "
                   "Next step: baseline v2 after the key management decision.",
    ))  # fmt: skip

    # Revisión de HLD con una desviación enviada a ADR
    review = b.add(DesignReview(program_id=b.pid, doc_type="HLD", title="Sovereign Private Cloud HLD", doc_version="1.2",
                                reviewer="Inés Calderón", review_date=b.d(-20), status="Changes Requested"))  # fmt: skip
    answers = ["Yes", "Yes", "Partial", "Partial", "No", "Yes", "Yes"]
    comments = ["", "", "Recovery scenario for the vault not described.", "NFR-006 is not measurable.",
                "Patching and observability for the management cluster are missing.", "", ""]  # fmt: skip
    for i, (ans, com) in enumerate(zip(answers, comments, strict=True)):
        b.add(ReviewItem(program_id=b.pid, review_id=review.id, question_key=i, answer=ans, comment=com,
                         deviation=ans == "No"))  # fmt: skip

    for dim, crit in ORR_DIMENSIONS:
        b.add(
            ORRCheck(
                program_id=b.pid,
                dimension=dim,
                criterion=crit,
                owner="",
                status={"Runbooks": "red", "Skills": "amber", "Backup": "green"}.get(dim, "grey"),
            )
        )
    b.add(HandoverItem(program_id=b.pid, kind="TechDebt", title="Manual certificate renewal on management VMs",
                       impact="Outage risk if a renewal is missed", estimated_cost="5 person-days",
                       receiving_owner="Customer operations", review_date=b.d(60)))  # fmt: skip

    # Baseline v1 hace 45 días; después cambian dos requisitos: uno con Change (cubierto) y otro sin (BASE-01)
    approved = _dt(b.d(-45))
    b.baseline(1, "Elena Varga", approved)
    r["block"].statement = "Provide block volumes in four performance tiers (incl. archive)"
    b.link(change, r["block"], when=_dt(b.d(-30)))
    r["file"].statement = "Provide SMB/NFS shares with quotas and snapshots per department"
    session.add_all([r["block"], r["file"]])
    session.flush()
    return p


# --------------------------------------------------------------------------- programas ligeros


def seed_backup_modernisation(session: Session, today: date) -> Program:
    """Fase 5: demuestra RTM-02 (requisito sin evidencia al llegar a G5)."""
    p = Program(code="HBM-ICDA", name="Hybrid Backup Modernisation",
                client="Instituto Cántabro de Datos Abiertos (fictitious)", sponsor="Marcos Llano (CTO)",
                pm="Alba Ruiz", ea="Inés Calderón", phase=5, operations_owner="Iker Sainz",
                operations_engaged=True, start_date=today - timedelta(days=240), is_demo=True)  # fmt: skip
    session.add(p)
    session.flush()
    b = Builder(session, p, today)
    b.settings()
    b.add(Workstream(program_id=b.pid, name="Data Protection", lead="Iker Sainz"))
    for name, stance, dm in [("Marcos Llano", "Sponsor", True), ("Rosa Gil", "Detractor", False)]:
        b.add(Stakeholder(program_id=b.pid, name=name, stance=stance, is_decision_maker=dm, role="Customer"))
    goal = b.add(Goal(program_id=b.pid, code=b.code("GOAL"), title="Modernise backup and recovery"))
    obj = b.add(
        Objective(
            program_id=b.pid,
            goal_id=goal.id,
            code=b.code("OBJ"),
            objective="Replace tape with disk-based immutable backup",
            acceptance_criteria="Go-live for BaaS service",
            completion_status="In Progress",
        )
    )
    elem = b.add(
        ArchitectureElement(program_id=b.pid, code=b.code("AE"), name="Backup appliances", view="Data")
    )
    for stmt, evidence in [
        ("Daily backup of all servers", True),
        ("Restore any file in under 1 hour", False),
    ]:
        req = b.req(statement=stmt, priority="Must", status="Approved")
        b.link(obj, req)
        b.link(req, elem)
        if evidence:
            te = b.add(
                TestEvidence(program_id=b.pid, code=b.code("TE"), title="Backup job report", result="Pass")
            )
            b.link(req, te)
    b.raid(
        RAIDType.RISK,
        title="Tape library decommissioning before data migration",
        owner="Iker Sainz",
        probability=1,
        impact=3,
        cause="contract ends in March",
        event="tape library removed early",
        consequence="historic restores impossible",
        response="Migrate catalogue first",
        escalation_trigger="Contract not extended",
        escalation_forum="SteerCo",
        due_date=b.d(40),
    )
    b.gates(passed_through=5)
    b.raci()
    return p


def seed_edge_discovery(session: Session, today: date) -> Program:
    """Fase 1: demuestra STK-01 (sin detractores identificados en el plan de comunicación)."""
    p = Program(code="EDP-CMM", name="Edge Data Platform Discovery",
                client="Consorcio Mediterráneo de Movilidad (fictitious)", sponsor="Laia Vidal (COO)",
                pm="Óscar Blanco", ea="Inés Calderón", phase=1, start_date=today - timedelta(days=20),
                is_demo=True)  # fmt: skip
    session.add(p)
    session.flush()
    b = Builder(session, p, today)
    b.settings(risk_scale=5, amber_from=5, red_from=15, decision_sla_days=14)
    b.add(
        Stakeholder(program_id=b.pid, name="Laia Vidal", stance="Sponsor", is_decision_maker=True, role="COO")
    )
    goal = b.add(Goal(program_id=b.pid, code=b.code("GOAL"), title="Real-time mobility data at the edge"))
    obj = b.add(
        Objective(
            program_id=b.pid,
            goal_id=goal.id,
            code=b.code("OBJ"),
            objective="Collect sensor data at 40 edge sites",
            acceptance_criteria="Pilot live",
        )
    )
    elem = b.add(ArchitectureElement(program_id=b.pid, code=b.code("AE"), name="Edge micro data centres"))
    req = b.req(statement="Ingest sensor events at each edge site", priority="Must")
    b.link(obj, req)
    b.link(req, elem)
    b.raid(
        RAIDType.RISK,
        title="Edge site connectivity",
        owner="Óscar Blanco",
        probability=3,
        impact=4,
        cause="rural sites lack fibre",
        event="data cannot be backhauled",
        consequence="pilot delayed",
        response="4G fallback",
        escalation_trigger="No fibre plan by G2",
        escalation_forum="SteerCo",
        due_date=b.d(45),
    )
    b.gates(passed_through=1)
    b.raci()
    return p


# --------------------------------------------------------------------------- orquestación


def reset_demo(session: Session) -> None:
    demo_ids = list(session.exec(select(Program.id).where(Program.is_demo == True)).all())  # noqa: E712
    if not demo_ids:
        return
    for model in PROGRAM_TABLES:
        session.exec(delete(model).where(model.program_id.in_(demo_ids)))  # type: ignore[attr-defined]
    session.exec(delete(Program).where(Program.id.in_(demo_ids)))  # type: ignore[union-attr]
    session.flush()


def run(session: Session, today: date | None = None) -> list[Program]:
    today = today or date.today()
    token_audit = audit_enabled.set(False)
    token_user = current_user.set("seed")
    try:
        reset_demo(session)
        programs = [
            seed_sovereign_cloud(session, today),
            seed_backup_modernisation(session, today),
            seed_edge_discovery(session, today),
        ]
        session.commit()
        return programs
    finally:
        audit_enabled.reset(token_audit)
        current_user.reset(token_user)


def main() -> None:
    init_db()
    with Session(get_engine()) as session:
        programs = run(session)
        for p in programs:
            print(f"Seeded demo program {p.code}: {p.name}")


if __name__ == "__main__":
    main()
