"""Enlaces requisito <-> resto de la cadena de trazabilidad (TraceLink), editados por celda de la RTM."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Any

from sqlmodel import Session, select

from app.models import ADR, ArchitectureElement, Gate, Objective, Outcome, TestEvidence, TraceLink

# Tipos que se pueden enlazar con un requisito y su modelo
LINKABLE: dict[str, Any] = {
    "objective": Objective,
    "outcome": Outcome,
    "arch_element": ArchitectureElement,
    "adr": ADR,
    "test_evidence": TestEvidence,
    "gate": Gate,
}

# Celda de la RTM -> tipos que edita. "Outcome / Objective" agrupa los dos tipos aguas arriba.
GROUPS: dict[str, tuple[str, ...]] = {
    "upstream": ("objective", "outcome"),
    "arch_element": ("arch_element",),
    "adr": ("adr",),
    "test_evidence": ("test_evidence",),
    "gate": ("gate",),
}

GROUP_LABELS = {
    "upstream": "outcome / objective",
    "arch_element": "architecture element",
    "adr": "ADR",
    "test_evidence": "test / evidence",
    "gate": "gate",
}


class LinkTargetError(Exception):
    def __init__(self, status: int, message: str = "") -> None:
        super().__init__(message)
        self.status = status


def parse_targets(
    session: Session, program_id: int, kinds: tuple[str, ...], raw: list[str]
) -> set[tuple[str, int]]:
    """'<tipo>:<id>' -> {(tipo, id)}. 422: formato o tipo ajeno al grupo; 404: no existe en el programa."""
    wanted: set[tuple[str, int]] = set()
    for item in raw:
        kind, _, num = item.partition(":")
        if kind not in kinds or not num.isdigit():
            raise LinkTargetError(422, "Invalid link target.")
        obj = session.get(LINKABLE[kind], int(num))
        if obj is None or obj.program_id != program_id:
            raise LinkTargetError(404)
        wanted.add((kind, int(num)))
    return wanted


def candidates(
    session: Session, program_id: int, kinds: tuple[str, ...]
) -> list[tuple[str, list[tuple[str, str]]]]:
    """Todo lo enlazable de esos tipos: [(titulo del bloque, [(tipo:id, etiqueta)])]."""
    out: list[tuple[str, list[tuple[str, str]]]] = []
    for kind in kinds:
        model = LINKABLE[kind]
        rows: Sequence[Any] = session.exec(select(model).where(model.program_id == program_id)).all()
        title, label = _LABELS[kind]
        out.append(
            (title, sorted(((f"{kind}:{r.id}", f"{r.code} {label(r)}") for r in rows), key=lambda i: i[1]))
        )
    return out


_LABELS: dict[str, tuple[str, Callable[[Any], str]]] = {
    "objective": ("Objectives", lambda o: o.objective),
    "outcome": ("Outcomes", lambda o: o.description),
    "arch_element": ("Architecture elements", lambda a: a.name),
    "adr": ("ADRs", lambda a: a.title),
    "test_evidence": ("Test / evidence", lambda e: e.title),
    "gate": ("Gates", lambda g: g.name),
}


def sync_links(
    session: Session,
    program_id: int,
    anchor: tuple[str, int],
    kinds: tuple[str, ...],
    wanted: set[tuple[str, int]],
    upstream_kinds: frozenset[str],
) -> tuple[int, int]:
    """Deja los enlaces del registro `anchor` con `kinds` exactamente en `wanted`. Devuelve (altas, bajas).

    Dirección canónica del TraceLink: los tipos de `upstream_kinds` van hacia el ancla; el resto, desde ella.
    """
    a_type, a_id = anchor
    existing: dict[tuple[str, int], list[TraceLink]] = {}
    for lk in session.exec(select(TraceLink).where(TraceLink.program_id == program_id)).all():
        if lk.src_type == a_type and lk.src_id == a_id and lk.dst_type in kinds:
            existing.setdefault((lk.dst_type, lk.dst_id), []).append(lk)
        elif lk.dst_type == a_type and lk.dst_id == a_id and lk.src_type in kinds:
            existing.setdefault((lk.src_type, lk.src_id), []).append(lk)
    removed = added = 0
    for key, links in existing.items():
        if key not in wanted:
            for lk in links:
                session.delete(lk)
            removed += 1
    for kind, obj_id in sorted(wanted - existing.keys()):
        src, dst = ((kind, obj_id), anchor) if kind in upstream_kinds else (anchor, (kind, obj_id))
        session.add(
            TraceLink(program_id=program_id, src_type=src[0], src_id=src[1], dst_type=dst[0], dst_id=dst[1])
        )
        added += 1
    if added or removed:
        session.commit()
    return added, removed


def set_links(
    session: Session, program_id: int, req_id: int, kinds: tuple[str, ...], wanted: set[tuple[str, int]]
) -> tuple[int, int]:
    """Enlaces de un requisito (RTM): objetivos y outcomes van aguas arriba; lo demás, aguas abajo."""
    return sync_links(
        session, program_id, ("requirement", req_id), kinds, wanted, frozenset({"objective", "outcome"})
    )
