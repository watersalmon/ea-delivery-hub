"""Operaciones de governance con reglas de negocio: ADR, gates, baselines y Design Authority."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import date
from typing import Any

from sqlmodel import Session, col, select

from app.models import (
    ADR,
    ArchitectureElement,
    Baseline,
    Gate,
    Meeting,
    MeetingDecision,
    Program,
    RAIDItem,
    Requirement,
    TraceLink,
    utcnow,
)
from app.models.enums import ADRStatus, MonitorStatus, RAIDType
from app.rules import RuleResult, evaluate, gate_blockers, load_context
from app.rules.context import content_hash
from app.services.ids import next_code


class GovernanceError(ValueError):
    """Operación rechazada por una regla de governance (se muestra al usuario)."""


# ------------------------------------------------------------------ ADR

# Ciclo de vida de CLAUDE.md §5 (PDR-003 #1)
ADR_TRANSITIONS: dict[str, set[str]] = {
    ADRStatus.PROPOSED: {ADRStatus.UNDER_REVIEW, ADRStatus.REJECTED, ADRStatus.DEFERRED},
    ADRStatus.UNDER_REVIEW: {ADRStatus.APPROVED, ADRStatus.REJECTED, ADRStatus.DEFERRED},
    ADRStatus.DEFERRED: {ADRStatus.PROPOSED, ADRStatus.UNDER_REVIEW},
    ADRStatus.APPROVED: {ADRStatus.SUPERSEDED},
    ADRStatus.REJECTED: set(),
    ADRStatus.SUPERSEDED: set(),
}


def change_adr_status(session: Session, adr: ADR, to: str, note: str = "", today: date | None = None) -> None:
    from app.models import ADRStatusChange

    if to not in ADR_TRANSITIONS.get(adr.status, set()):
        raise GovernanceError(f"{adr.code}: cannot move from '{adr.status}' to '{to}'.")
    if to == ADRStatus.APPROVED and adr.critical_path and (not adr.owner.strip() or adr.due_date is None):
        raise GovernanceError(
            f"{adr.code}: a critical-path decision needs an owner and a date before approval (ADR-01)."
        )
    if (
        to == ADRStatus.SUPERSEDED
        and not session.exec(select(ADR).where(ADR.supersedes_id == adr.id)).first()
    ):
        raise GovernanceError(f"{adr.code}: record the new ADR that supersedes it first.")
    session.add(
        ADRStatusChange(
            program_id=adr.program_id,
            adr_id=adr.id or 0,
            from_status=adr.status,
            to_status=to,
            changed_at=utcnow(),
            note=note,
        )
    )
    adr.status = to
    if to == ADRStatus.APPROVED:
        adr.approved_at = today or date.today()
    if to == ADRStatus.PROPOSED and adr.submitted_at is None:
        adr.submitted_at = today or date.today()
    session.add(adr)


def create_adr(session: Session, program_id: int, title: str, **fields: object) -> ADR:
    adr = ADR(
        program_id=program_id,
        code=next_code(session, program_id, "ADR"),
        title=title,
        status=ADRStatus.PROPOSED,
        submitted_at=date.today(),
        **fields,  # type: ignore[arg-type]
    )
    session.add(adr)
    session.flush()
    return adr


# ------------------------------------------------------------------ Gates


@dataclass
class GateCheck:
    gate: Gate
    blockers: list[RuleResult]
    waived: bool

    @property
    def can_pass(self) -> bool:
        return not self.blockers


def check_gate(session: Session, program_id: int, code: str) -> GateCheck:
    ctx = load_context(session, program_id)
    gate = next((g for g in ctx.gates if g.code == code), None)
    if gate is None:
        raise GovernanceError(f"Gate {code} not found.")
    results = evaluate(ctx)
    blockers = gate_blockers(ctx, results, code)
    raw = [r for r in results if r.severity == "red" and code in r.blocks_gates]
    return GateCheck(gate=gate, blockers=blockers, waived=bool(raw) and not blockers)


def pass_gate(session: Session, program_id: int, code: str, approver: str, today: date | None = None) -> Gate:
    """Un gate no se supera con reglas rojas asociadas abiertas, salvo waiver ADR aprobado (CLAUDE.md §6)."""
    check = check_gate(session, program_id, code)
    if not check.can_pass:
        ids = ", ".join(sorted({f"{b.rule_id} {b.entity_code}" for b in check.blockers}))
        raise GovernanceError(f"{code} is blocked by {len(check.blockers)} red rule(s): {ids}.")
    gate = check.gate
    if gate.status == "Passed":
        raise GovernanceError(f"{code} has already been passed.")
    program = session.get(Program, program_id)
    assert program is not None
    if gate.phase != program.phase:
        raise GovernanceError(f"Only the active gate (G{program.phase}) can be passed.")
    gate.status = "Passed"
    gate.passed_at = today or date.today()
    gate.approver = approver or gate.approver
    session.add(gate)
    if program.phase < 6:
        program.phase += 1
        nxt = session.exec(
            select(Gate).where(Gate.program_id == program_id, Gate.phase == program.phase)
        ).first()
        if nxt is not None:
            nxt.status = "In Progress"
            session.add(nxt)
        session.add(program)
    return gate


def set_waiver(session: Session, program_id: int, code: str, adr_id: int | None) -> Gate:
    gate = session.exec(select(Gate).where(Gate.program_id == program_id, Gate.code == code)).one()
    if adr_id is not None:
        adr = session.get(ADR, adr_id)
        if adr is None or adr.program_id != program_id or adr.status != ADRStatus.APPROVED:
            raise GovernanceError("A waiver must be an approved ADR of this program.")
    gate.waiver_adr_id = adr_id
    session.add(gate)
    return gate


# ------------------------------------------------------------------ Baselines


def create_baseline(session: Session, program_id: int, approved_by: str) -> Baseline:
    """Snapshot versionado de requisitos + arquitectura + RAID + roadmap con SHA-256 (CLAUDE.md §5)."""

    def rows(model: Any) -> list[Any]:
        return list(session.exec(select(model).where(model.program_id == program_id)).all())

    reqs, aes = rows(Requirement), rows(ArchitectureElement)
    from app.services.baselines import snapshot_payload

    payload = snapshot_payload(session, program_id)
    raw = json.dumps(payload, sort_keys=True)
    hashes = {f"requirement:{r.id}": content_hash(r) for r in reqs}
    hashes.update({f"arch_element:{a.id}": content_hash(a) for a in aes})
    last = session.exec(
        select(Baseline).where(Baseline.program_id == program_id).order_by(col(Baseline.version).desc())
    ).first()
    baseline = Baseline(
        program_id=program_id,
        version=(last.version + 1) if last else 1,
        approved_by=approved_by,
        approved_at=utcnow(),
        sha256=hashlib.sha256(raw.encode()).hexdigest(),
        payload=raw,
        element_hashes=json.dumps(hashes, sort_keys=True),
    )
    session.add(baseline)
    session.flush()
    return baseline


# ------------------------------------------------------------------ Design Authority


def schedule_da(
    session: Session,
    program_id: int,
    meeting_date: date,
    adr_ids: list[int],
    participants: list[dict[str, object]],
) -> Meeting:
    """Prepara una sesión de la Design Authority: las ADR elegidas pasan a Under Review."""
    meeting = Meeting(
        program_id=program_id,
        forum="Architecture Design Authority",
        meeting_date=meeting_date,
        participants=participants,
        status="Planned",
    )
    session.add(meeting)
    session.flush()
    for order, adr_id in enumerate(adr_ids):
        adr = session.get(ADR, adr_id)
        if adr is None or adr.program_id != program_id:
            continue
        if adr.status in (ADRStatus.PROPOSED, ADRStatus.DEFERRED):
            change_adr_status(session, adr, ADRStatus.UNDER_REVIEW, note=f"Scheduled for DA {meeting_date}")
        session.add(
            MeetingDecision(
                program_id=program_id,
                meeting_id=meeting.id or 0,
                adr_id=adr_id,
                order=order,
                owner=adr.owner,
                due_date=adr.due_date,
            )
        )
    return meeting


@dataclass
class CloseResult:
    meeting: Meeting
    applied: list[MeetingDecision]
    actions: list[RAIDItem]


def close_da(session: Session, meeting: Meeting, today: date | None = None) -> CloseResult:
    """Cierra la sesión: aplica el resultado a cada ADR y crea acciones en el RAID (CLAUDE.md §7.10)."""
    today = today or date.today()
    if meeting.status == "Closed":
        raise GovernanceError("This Design Authority session is already closed.")
    decisions = list(
        session.exec(
            select(MeetingDecision)
            .where(MeetingDecision.meeting_id == meeting.id)
            .order_by(col(MeetingDecision.order))
        ).all()
    )
    pending = [d for d in decisions if not d.outcome]
    if pending:
        raise GovernanceError(
            f"Record an outcome for every decision before closing ({len(pending)} pending)."
        )
    actions: list[RAIDItem] = []
    pid = meeting.program_id
    for d in decisions:
        adr = session.get(ADR, d.adr_id)
        assert adr is not None
        adr.owner = d.owner or adr.owner
        adr.due_date = d.due_date or adr.due_date
        if d.conditions:
            adr.conditions = d.conditions
        target = {
            "Approved": ADRStatus.APPROVED,
            "Rejected": ADRStatus.REJECTED,
            "Deferred": ADRStatus.DEFERRED,
        }[d.outcome]
        if adr.status == ADRStatus.PROPOSED:
            change_adr_status(session, adr, ADRStatus.UNDER_REVIEW, note="Discussed at DA", today=today)
        change_adr_status(session, adr, target, note=f"Design Authority {meeting.meeting_date}", today=today)
        session.add(
            TraceLink(
                program_id=pid, src_type="meeting", src_id=meeting.id or 0, dst_type="adr", dst_id=adr.id or 0
            )
        )
        title = None
        if d.outcome == "Approved" and d.conditions:
            title = f"Apply the conditions of {adr.code}: {d.conditions}"
        elif d.outcome == "Approved" and not adr.impacted_artifacts.strip():
            title = f"Update the artifacts impacted by {adr.code}"
        elif d.outcome == "Deferred":
            title = f"Prepare {adr.code} for re-submission: {d.notes or 'address the open questions'}"
        if title:
            actions.append(
                _action(session, pid, meeting, title[:250], d.owner or adr.owner, d.due_date or today)
            )
    meeting.status = "Closed"
    meeting.closed_at = utcnow()
    present = [p for p in meeting.participants if p.get("present")]
    roles = {str(p.get("role", "")) for p in present}
    meeting.quorum_met = {"Enterprise Architect", "Customer"} <= roles and any("Lead" in r for r in roles)
    meeting.attendees = "; ".join(f"{p.get('name') or p.get('role')} ({p.get('role')})" for p in present)
    session.add(meeting)
    session.flush()
    return CloseResult(meeting=meeting, applied=decisions, actions=actions)


def _action(
    session: Session, program_id: int, meeting: Meeting, title: str, owner: str, due: date
) -> RAIDItem:
    item = RAIDItem(
        program_id=program_id,
        type=RAIDType.ACTION,
        code=next_code(session, program_id, "AC"),
        title=title,
        owner=owner,
        due_date=due,
        date_added=date.today(),
        organization="Dell",
        monitor_status=MonitorStatus.OPEN,
        reported_by="Design Authority",
        description=f"Raised at the Design Authority of {meeting.meeting_date}.",
    )
    session.add(item)
    session.flush()
    session.add(
        TraceLink(
            program_id=program_id,
            src_type="meeting",
            src_id=meeting.id or 0,
            dst_type="raid",
            dst_id=item.id or 0,
        )
    )
    return item


def add_meeting_action(session: Session, meeting: Meeting, title: str, owner: str, due: date) -> RAIDItem:
    if not title.strip():
        raise GovernanceError("An action needs a title.")
    return _action(session, meeting.program_id, meeting, title.strip(), owner.strip(), due)


def meeting_actions(session: Session, meeting: Meeting) -> list[RAIDItem]:
    ids = session.exec(
        select(TraceLink.dst_id).where(
            TraceLink.src_type == "meeting", TraceLink.src_id == meeting.id, TraceLink.dst_type == "raid"
        )
    ).all()
    if not ids:
        return []
    return list(
        session.exec(select(RAIDItem).where(col(RAIDItem.id).in_(ids)).order_by(col(RAIDItem.code))).all()
    )
