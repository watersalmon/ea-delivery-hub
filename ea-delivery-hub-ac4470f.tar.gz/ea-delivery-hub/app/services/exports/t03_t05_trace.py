"""T03 · Goals & Solution Dependency Map (XLSX) y T05 · Requirements Traceability Matrix (XLSX).

T03 replica la captura 2 (cabecera a dos niveles y celdas combinadas por Goal) con lista de Completion
Status. T05 añade Outcomes, Requirements, Trace (cadena de la pantalla RTM), la pestaña Solution
Dependency y Coverage con fórmulas vivas; los huérfanos se resaltan con formato condicional.
"""

from __future__ import annotations

from io import BytesIO
from typing import Any

from openpyxl import Workbook
from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter
from sqlmodel import select

from app.content.artifacts import ARTIFACTS
from app.models import Goal, Objective, Outcome, Workstream
from app.models.enums import CompletionStatus, MoSCoW, NFRCategory
from app.services.exports.base import (
    FIRST_DATA_ROW,
    HEADER_ROW,
    MAX_ROWS,
    ExportContext,
    Lists,
    Style,
    XCol,
    add_banding,
    new_workbook,
    sheet_title,
    write_banner,
    write_cover,
    write_table,
)

COMPLETION_FILL = {"Complete": "green", "In Progress": "blue", "At Risk": "red", "Not Started": "grey"}

EXAMPLE_GOALS = [
    (
        "Goal-001",
        "Build private cloud capabilities with a predictable consumption model",
        [
            (
                "Obj-001",
                "Implement Infrastructure-as-a-Service to host virtual and physical compute",
                "Go-live for IaaS service",
                "In Progress",
                "Customer sponsor",
            ),
            (
                "Obj-002",
                "Implement Backup-as-a-Service to host backup and recovery",
                "Go-live for BaaS service",
                "Not Started",
                "Customer sponsor",
            ),
        ],
    ),
    (
        "Goal-002",
        "Maximise value and minimise cost",
        [
            (
                "Obj-003",
                "Implement a predictable as-a-service consumption pricing model",
                "Completion of MVP (all services live)",
                "Not Started",
                "CFO",
            ),
        ],
    ),
]


# ------------------------------------------------------------------ Solution Dependency (T03 y hoja de T05)


def _sdm_data(ctx: ExportContext) -> list[tuple[str, str, list[tuple[str, str, str, str, str]]]]:
    if not (ctx.filled and ctx.session is not None and ctx.program is not None):
        return EXAMPLE_GOALS
    pid = ctx.program.id
    goals = ctx.session.exec(select(Goal).where(Goal.program_id == pid).order_by(Goal.code)).all()
    objs = ctx.session.exec(
        select(Objective).where(Objective.program_id == pid).order_by(Objective.code)
    ).all()
    out = []
    for g in goals:
        rows = [
            (o.code, o.objective, o.acceptance_criteria, o.completion_status, o.approver)
            for o in objs
            if o.goal_id == g.id
        ]
        out.append((g.code, g.title, rows))
    return out


def write_sdm_sheet(wb: Workbook, st: Style, ctx: ExportContext, lists: Lists) -> None:
    ws = wb.create_sheet(sheet_title(ctx.t("sdm_sheet")), index=len(wb.sheetnames) - 1)
    ncols = 7
    write_banner(ws, st, ctx.t("sdm"), ncols)
    widths = [11, 34, 9, 50, 36, 17, 20]
    for j, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(j)].width = w

    def head(row: int, col: int, text: str, fill: str, dark: bool, end_col: int | None = None) -> None:
        if end_col:
            ws.merge_cells(start_row=row, start_column=col, end_row=row, end_column=end_col)
        c = ws.cell(row=row, column=col, value=text)
        c.font = st.font(bold=True, color="FFFFFF" if dark else "000000")
        c.fill = st.fill(fill)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for cc in range(col, (end_col or col) + 1):
            ws.cell(row=row, column=cc).border = st.border
            ws.cell(row=row, column=cc).fill = st.fill(fill)

    head(3, 1, ctx.t("sdm_log"), st.blue, True, ncols)
    head(4, 1, ctx.t("goals_objectives"), st.header_sub, False, 4)
    head(4, 5, ctx.t("req_completion"), st.header_dark, True, 7)
    for j, key in enumerate(("Goal ID", "Goal", "Obj ID", "Objective"), start=1):
        head(5, j, ctx.t(key), st.header_sub, False)
    for j, key in enumerate(("Acceptance Criteria", "Completion Status", "Approver"), start=5):
        head(5, j, ctx.t(key), st.header_dark, True)

    example = not ctx.filled
    row = 6
    shade = st.fill(st.tint(st.header_sub, 0.25))  # sombreado alterno por Goal, como la captura
    for gi, (gcode, gtitle, objs) in enumerate(_sdm_data(ctx)):
        start = row
        for ocode, objective, criteria, status, approver in objs or [("", "", "", "", "")]:
            for j, value in enumerate((gcode, gtitle, ocode, objective, criteria, status, approver), start=1):
                c = ws.cell(row=row, column=j, value=value if (j > 2 or row == start) else None)
                c.alignment = Alignment(
                    wrap_text=True,
                    vertical="center" if j <= 2 else "top",
                    horizontal="center" if j in (1, 3, 6) else None,
                )
                c.border = st.border
                c.font = st.font(bold=j <= 2, italic=example, color=st.grey if example else None)
                if gi % 2 == 0:
                    c.fill = shade
            row += 1
        if row - start > 1:
            ws.merge_cells(start_row=start, start_column=1, end_row=row - 1, end_column=1)
            ws.merge_cells(start_row=start, start_column=2, end_row=row - 1, end_column=2)

    last = 5 + MAX_ROWS
    lists.add("L_Completion", [c.value for c in CompletionStatus])
    from openpyxl.worksheet.datavalidation import DataValidation

    dv = DataValidation(type="list", formula1="=L_Completion", allow_blank=True, showErrorMessage=True)
    dv.add(f"F6:F{last}")
    ws.add_data_validation(dv)
    colors = {"green": st.green, "blue": st.blue, "red": st.red, "grey": st.grey}
    for status, rag in COMPLETION_FILL.items():
        ws.conditional_formatting.add(
            f"F6:F{last}",
            CellIsRule(
                operator="equal",
                formula=[f'"{status}"'],
                fill=st.fill(colors[rag]),
                font=st.font(bold=True, color="FFFFFF"),
            ),
        )
    ws.freeze_panes = "A6"
    ws.oddFooter.center.text = st.classification
    ws.page_setup.orientation = "landscape"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToHeight = 0


def build_t03(ctx: ExportContext) -> bytes:
    wb, st = new_workbook()
    write_cover(wb, st, ctx, ctx.t("sdm"), ARTIFACTS["goals"])
    lists = Lists(wb)
    write_sdm_sheet(wb, st, ctx, lists)
    wb.active = 1
    out = BytesIO()
    wb.save(out)
    return out.getvalue()


# ------------------------------------------------------------------ RTM (T05)


def _trace_rows(ctx: ExportContext) -> list[list[Any]]:
    from app.routers.traceability import build_trace

    assert ctx.session is not None and ctx.view is not None
    rows = []
    for r in build_trace(ctx.session, ctx.view):
        rows.append(
            [
                r.req.code,
                r.req.statement,
                r.req.priority,
                "\n".join(u.code for u in r.upstream),
                "\n".join(f"{e.code} {e.name}" for e in r.elements),
                "\n".join(f"{a.code} ({a.status})" for a in r.adrs),
                "\n".join(f"{e.code} {e.title} [{e.result}]" for e in r.evidence),
                ", ".join(g.code for g in r.gates),
            ]
        )
    return rows


EXAMPLE_TRACE = [
    [
        "REQ-001",
        "Tenants can self-provision VMs from a catalogue",
        "Must",
        "Obj-001",
        "AE-001 Virtualisation clusters",
        "ADR-001 (Approved)",
        "TE-001 Catalogue UAT [Pass]",
        "G5",
    ],
    ["REQ-002", "Monthly consumption showback per tenant", "Should", "Obj-003", "", "", "", "G6"],
    [
        "NFR-001",
        "Platform availability for tier-1 services",
        "Must",
        "",
        "AE-001 Virtualisation clusters",
        "",
        "",
        "G5",
    ],
]

TRACE_COLS = [
    XCol("ID", 10, wrap=False, center=True),
    XCol("Requirement", 40),
    XCol("Priority", 10, list_name="L_MoSCoW", center=True),
    XCol("Outcome / Objective", 16),
    XCol("Architecture Element", 30),
    XCol("ADR", 22),
    XCol("Test / Evidence", 32),
    XCol("Gate", 8, center=True),
    XCol("Upstream", 11, center=True),
    XCol("Design", 11, center=True),
    XCol("Evidence", 11, center=True),
    XCol("E2E", 11, center=True),
]


def _write_trace(wb: Workbook, st: Style, ctx: ExportContext, lists: Lists) -> None:
    ws = wb.create_sheet(sheet_title(ctx.t("Trace")), index=len(wb.sheetnames) - 1)
    write_banner(ws, st, ctx.t("rtm"), len(TRACE_COLS))
    rows = _trace_rows(ctx) if ctx.filled else EXAMPLE_TRACE
    write_table(ws, st, ctx, TRACE_COLS, rows, lists, example=not ctx.filled)
    first, last = FIRST_DATA_ROW, HEADER_ROW + MAX_ROWS
    yes, no = '"Yes"', '"No"'
    for r in range(first, last + 1):
        for col, src in (("I", "D"), ("J", "E"), ("K", "G")):
            ws[f"{col}{r}"] = f'=IF($A{r}="","",IF(LEN(TRIM({src}{r}))>0,{yes},{no}))'
        ws[f"L{r}"] = f'=IF($A{r}="","",IF(AND(I{r}={yes},J{r}={yes},K{r}={yes}),{yes},{no}))'
        for c in "IJKL":
            ws[f"{c}{r}"].font = st.font()
            ws[f"{c}{r}"].alignment = Alignment(horizontal="center")
    # Huérfanos (RTM-01): rojo si Must, ámbar el resto
    orphan = f'AND($A{first}<>"",OR($I{first}={no},$J{first}={no}))'
    ws.conditional_formatting.add(
        f"A{first}:H{last}",
        FormulaRule(
            formula=[f'AND({orphan},$C{first}="Must")'],
            fill=st.fill(st.tint(st.red, 0.2)),
            font=st.font(color=st.red, bold=True),
        ),
    )
    ws.conditional_formatting.add(
        f"A{first}:H{last}", FormulaRule(formula=[orphan], fill=st.fill(st.tint(st.amber, 0.3)))
    )
    for rag, value in ((st.green, yes), (st.red, no)):
        ws.conditional_formatting.add(
            f"I{first}:L{last}",
            CellIsRule(operator="equal", formula=[value], font=st.font(bold=True, color=rag)),
        )
    add_banding(ws, st, len(TRACE_COLS))


def build_t05(ctx: ExportContext) -> bytes:
    wb, st = new_workbook()
    write_cover(wb, st, ctx, ctx.t("rtm"), ARTIFACTS["rtm"])
    lists = Lists(wb)
    lists.add("L_MoSCoW", [m.value for m in MoSCoW])
    lists.add("L_ReqType", ["FR", "NFR"])
    lists.add("L_NFRCategory", [c.value for c in NFRCategory])
    lists.add("L_ReqStatus", ["Proposed", "Approved", "Implemented", "Verified"])

    # Outcomes
    ws = wb.create_sheet(sheet_title(ctx.t("Outcomes")), index=len(wb.sheetnames) - 1)
    cols = [
        XCol("ID", 10, wrap=False, center=True),
        XCol("Outcome", 40),
        XCol("Metric", 34),
        XCol("Baseline", 14, center=True),
        XCol("Target", 14, center=True),
        XCol("Target Date", 13, number_format="m/d/yyyy", center=True),
    ]
    write_banner(ws, st, ctx.t("Outcomes").upper(), len(cols))
    if ctx.filled and ctx.session is not None and ctx.program is not None:
        outs = ctx.session.exec(
            select(Outcome).where(Outcome.program_id == ctx.program.id).order_by(Outcome.code)
        ).all()
        rows: list[list[Any]] = [
            [o.code, o.description, o.metric, o.baseline_value, o.target_value, o.target_date] for o in outs
        ]
    else:
        rows = [
            [
                "OUT-001",
                "Faster provisioning of infrastructure",
                "Lead time to provision a VM",
                "15 days",
                "< 1 day",
                ctx.today,
            ]
        ]
    write_table(ws, st, ctx, cols, rows, lists, example=not ctx.filled)
    add_banding(ws, st, len(cols))

    # Requirements
    ws = wb.create_sheet(sheet_title(ctx.t("Requirements")), index=len(wb.sheetnames) - 1)
    cols = [
        XCol("ID", 10, wrap=False, center=True),
        XCol("Type", 7, list_name="L_ReqType", center=True),
        XCol("Requirement", 44),
        XCol("Priority", 10, list_name="L_MoSCoW", center=True),
        XCol("NFR Category", 14, list_name="L_NFRCategory"),
        XCol("Measurable Criterion", 38),
        XCol("Source", 14),
        XCol("Status", 12, list_name="L_ReqStatus", center=True),
        XCol("Workstream", 22),
    ]
    write_banner(ws, st, ctx.t("Requirements").upper(), len(cols))
    if ctx.filled and ctx.view is not None and ctx.session is not None:
        wsn = {
            w.id: w.name
            for w in ctx.session.exec(
                select(Workstream).where(Workstream.program_id == ctx.view.program.id)
            ).all()
        }
        reqs = sorted(ctx.view.ctx.requirements, key=lambda r: (r.kind, r.code))
        rows = [
            [
                r.code,
                r.kind,
                r.statement,
                r.priority,
                r.nfr_category,
                r.measurable_criterion,
                r.source,
                r.status,
                wsn.get(r.workstream_id, ""),
            ]
            for r in reqs
        ]
    else:
        rows = [
            [
                "REQ-001",
                "FR",
                "Tenants can self-provision VMs from a catalogue",
                "Must",
                "",
                "",
                "SOW §3.1",
                "Approved",
                "Compute & Storage",
            ],
            [
                "NFR-001",
                "NFR",
                "Platform availability for tier-1 services",
                "Must",
                "Availability",
                ">= 99.95% monthly, excluding planned maintenance",
                "SOW §4",
                "Approved",
                "",
            ],
        ]
    write_table(ws, st, ctx, cols, rows, lists, example=not ctx.filled)
    first, last = FIRST_DATA_ROW, HEADER_ROW + MAX_ROWS
    ws.conditional_formatting.add(  # RTM-03: NFR sin criterio medible
        f"F{first}:F{last}",
        FormulaRule(formula=[f'AND($B{first}="NFR",LEN(TRIM($F{first}))=0)'], fill=st.fill(st.amber)),
    )
    add_banding(ws, st, len(cols))

    _write_trace(wb, st, ctx, lists)
    write_sdm_sheet(wb, st, ctx, lists)

    # Coverage con fórmulas vivas
    ws = wb.create_sheet(sheet_title(ctx.t("Coverage")), index=len(wb.sheetnames) - 1)
    write_banner(ws, st, ctx.t("Coverage").upper(), 2)
    tr = sheet_title(ctx.t("Trace"))
    a, i, j, k, l_ = (f"'{tr}'!{c}{FIRST_DATA_ROW}:{c}{HEADER_ROW + MAX_ROWS}" for c in "AIJKL")
    measures = [
        ("cov_total", f"=COUNTA({a})", "0"),
        ("cov_upstream", f'=IF($B$5=0,0,COUNTIF({i},"Yes")/$B$5)', "0%"),
        ("cov_design", f'=IF($B$5=0,0,COUNTIF({j},"Yes")/$B$5)', "0%"),
        ("cov_evidence", f'=IF($B$5=0,0,COUNTIF({k},"Yes")/$B$5)', "0%"),
        ("cov_e2e", f'=IF($B$5=0,0,COUNTIF({l_},"Yes")/$B$5)', "0%"),
        ("cov_orphans", f'=SUMPRODUCT(({a}<>"")*((({i}="No")+({j}="No"))>0))', "0"),
    ]
    for col, key in ((1, "Measure"), (2, "Value")):
        c = ws.cell(row=HEADER_ROW, column=col, value=ctx.t(key))
        c.font = st.font(bold=True, color="FFFFFF")
        c.fill = st.fill(st.blue)
        c.border = st.border
    ws.column_dimensions["A"].width = 38
    ws.column_dimensions["B"].width = 14
    for n, (key, formula, fmt) in enumerate(measures, start=FIRST_DATA_ROW):
        ws.cell(row=n, column=1, value=ctx.t(key)).border = st.border
        v = ws.cell(row=n, column=2, value=formula)
        v.number_format = fmt
        v.border = st.border
        v.font = st.font(bold=True)
        v.alignment = Alignment(horizontal="center")
    pct = f"B{FIRST_DATA_ROW + 1}:B{FIRST_DATA_ROW + 4}"
    ws.conditional_formatting.add(
        pct,
        CellIsRule(
            operator="greaterThanOrEqual",
            formula=["0.9"],
            fill=st.fill(st.green),
            font=st.font(bold=True, color="FFFFFF"),
        ),
    )
    ws.conditional_formatting.add(
        pct,
        CellIsRule(
            operator="greaterThanOrEqual", formula=["0.6"], fill=st.fill(st.amber), font=st.font(bold=True)
        ),
    )
    ws.conditional_formatting.add(
        pct,
        CellIsRule(
            operator="lessThan",
            formula=["0.6"],
            fill=st.fill(st.red),
            font=st.font(bold=True, color="FFFFFF"),
        ),
    )
    orph = f"B{FIRST_DATA_ROW + 5}"
    ws.conditional_formatting.add(
        orph,
        CellIsRule(
            operator="greaterThan",
            formula=["0"],
            fill=st.fill(st.red),
            font=st.font(bold=True, color="FFFFFF"),
        ),
    )
    ws.oddFooter.center.text = st.classification

    wb.active = wb.sheetnames.index(tr)
    out = BytesIO()
    wb.save(out)
    return out.getvalue()
