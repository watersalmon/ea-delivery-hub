"""T04 · RAID Log (XLSX): pestañas de la captura 1 + causa/evento/consecuencia (guía §8).

Validaciones: P e I con lista, score = PxI con fórmula y semáforo, Monitor Status con lista,
resaltado de riesgo rojo sin owner y de elementos vencidos.
"""

from __future__ import annotations

from datetime import date, timedelta
from io import BytesIO
from typing import Any

from openpyxl.formatting.rule import FormulaRule, IconSetRule
from openpyxl.utils import get_column_letter
from sqlmodel import select

from app.content.artifacts import ARTIFACTS
from app.content.raid_layout import Col, columns_for
from app.models import ProgramSettings, RAIDItem, RAIDUpdate, Workstream
from app.models.enums import ESCALATION_FORUM, CompletionStatus, MonitorStatus, Organization, RAIDType
from app.services.exports.base import (
    FIRST_DATA_ROW,
    HEADER_ROW,
    MAX_ROWS,
    ExportContext,
    Lists,
    XCol,
    add_banding,
    new_workbook,
    sheet_title,
    write_banner,
    write_cover,
    write_table,
)
from app.services.governance import RAID_TABS

_ = CompletionStatus  # vocabulario cerrado disponible para otras plantillas

WIDTHS = {
    "code": 9,
    "organization": 14,
    "date_added": 11,
    "reported_by": 15,
    "title": 32,
    "workstream_id": 18,
    "owner": 18,
    "probability": 6,
    "impact": 6,
    "score": 7,
    "due_date": 11,
    "monitor_status": 15,
    "contingency_plan": 34,
    "updates": 44,
    "cause": 28,
    "event": 28,
    "consequence": 28,
    "escalation_trigger": 26,
    "escalation_forum": 20,
    "description": 36,
    "severity": 10,
    "source": 10,
    "resolution": 32,
    "scope_impact": 26,
    "cost_impact": 14,
    "schedule_impact": 14,
    "change_control_decision": 14,
    "context": 30,
    "decision_taken": 30,
    "result": 26,
    "recommendation": 32,
}
LISTS = {
    "organization": "L_Organization",
    "workstream_id": "L_Workstream",
    "probability": "L_Scale",
    "impact": "L_Scale",
    "monitor_status": "L_MonitorStatus",
    "escalation_forum": "L_Forum",
    "severity": "L_Severity",
    "change_control_decision": "L_ChangeControl",
}
CENTER = {
    "code",
    "organization",
    "date_added",
    "probability",
    "impact",
    "score",
    "due_date",
    "monitor_status",
    "severity",
    "source",
    "change_control_decision",
}
DATES = {"date_added", "due_date"}

EXAMPLES: dict[str, list[dict[str, Any]]] = {
    RAIDType.RISK: [
        {
            "code": "RK-001",
            "organization": "Customer",
            "reported_by": "Enterprise Architect",
            "title": "Data centre power readiness",
            "owner": "Facilities manager",
            "probability": 3,
            "impact": 3,
            "monitor_status": "Action Required",
            "contingency_plan": "Phase rack power-on",
            "updates": "Response: temporary generators\n2/21: utility date still pending",
            "cause": "the grid upgrade is not scheduled",
            "event": "racks cannot be powered at install",
            "consequence": "go-live slips",
            "escalation_trigger": "No grid date 30 days before delivery",
            "escalation_forum": "SteerCo / sponsor",
        },
        {
            "code": "RK-002",
            "organization": "Dell",
            "reported_by": "Project Manager",
            "title": "Extended hardware lead time",
            "owner": "Compute lead",
            "probability": 2,
            "impact": 2,
            "monitor_status": "Monitoring",
            "contingency_plan": "Temporary capacity on existing arrays",
            "updates": "Response: split the order",
            "cause": "component shortages",
            "event": "late delivery",
            "consequence": "migration wave 1 moves right",
            "escalation_trigger": "Vendor confirms > 8 weeks",
            "escalation_forum": "PM / Change Control",
        },
    ],
    RAIDType.ACTION: [
        {
            "code": "AC-001",
            "title": "Send vetting list for partner engineers",
            "owner": "Migration lead",
            "monitor_status": "Open",
            "description": "One consolidated batch",
        }
    ],
    RAIDType.ISSUE: [
        {
            "code": "IS-001",
            "title": "Storage nodes delayed 4 weeks",
            "owner": "Compute lead",
            "severity": "High",
            "source": "RK-002",
            "monitor_status": "Action Required",
        }
    ],
    RAIDType.DECISION: [
        {
            "code": "DC-001",
            "title": "Backup target recorded as ADR-001",
            "owner": "EA",
            "monitor_status": "Closed",
            "description": "ADR-001",
        }
    ],
    RAIDType.ESCALATION: [
        {
            "code": "ES-001",
            "title": "Operations skills gap",
            "source": "RK-006",
            "escalation_forum": "SteerCo / sponsor",
            "owner": "PM",
            "monitor_status": "In Progress",
        }
    ],
    RAIDType.CHANGE: [
        {
            "code": "CH-001",
            "title": "Add an archive storage tier",
            "scope_impact": "New catalogue tier",
            "cost_impact": "+1.5%",
            "schedule_impact": "None",
            "change_control_decision": "Pending",
            "owner": "PM",
            "monitor_status": "Open",
        }
    ],
    RAIDType.COMM: [
        {
            "code": "CM-001",
            "title": "Monthly SteerCo pack",
            "owner": "PM",
            "monitor_status": "In Progress",
            "description": "Sponsor, CISO, PM",
        }
    ],
    RAIDType.LESSON: [
        {
            "code": "LL-001",
            "title": "Engage facilities before ordering hardware",
            "context": "Racks ordered before power was confirmed",
            "decision_taken": "Phased power-on",
            "result": "Two-week delay instead of six",
            "recommendation": "Make power a G3 criterion",
            "owner": "EA",
        }
    ],
}


def _xcols(cols: list[Col]) -> list[XCol]:
    return [
        XCol(
            key=c.label,
            width=WIDTHS.get(c.field, 16),
            wrap=c.field not in {"code", "probability", "impact", "score"},
            list_name=LISTS.get(c.field),
            number_format="m/d/yyyy" if c.field in DATES else None,
            center=c.field in CENTER,
            group=c.extra,
        )
        for c in cols
    ]


def _value(item: RAIDItem, field: str, lookups: dict[str, Any]) -> Any:
    if field == "workstream_id":
        return lookups["workstreams"].get(item.workstream_id, "")
    if field == "score":
        return None  # fórmula
    if field == "updates":
        lines = [f"Response: {item.response}"] if item.response else []
        lines += [
            f"{u.update_date.month}/{u.update_date.day}: {u.text}"
            for u in lookups["updates"].get(item.id, [])
        ]
        return "\n".join(lines)
    if field == "source":
        return lookups["codes"].get(item.source_risk_id, "")
    value = getattr(item, field, None)
    return "" if value is None else value


def build(ctx: ExportContext) -> bytes:
    wb, st = new_workbook()
    write_cover(wb, st, ctx, ctx.t("raid_log"), ARTIFACTS["raid"])
    lists = Lists(wb)

    settings = ProgramSettings(program_id=0)
    lookups: dict[str, Any] = {"workstreams": {}, "updates": {}, "codes": {}}
    items: list[RAIDItem] = []
    if ctx.filled and ctx.view is not None and ctx.session is not None:
        settings = ctx.view.ctx.settings
        items = sorted(ctx.view.ctx.raid_items, key=lambda i: i.code)
        pid = ctx.view.program.id
        ws_rows = ctx.session.exec(select(Workstream).where(Workstream.program_id == pid)).all()
        lookups["workstreams"] = {w.id: w.name for w in ws_rows}
        for u in ctx.session.exec(select(RAIDUpdate).where(RAIDUpdate.program_id == pid)).all():
            lookups["updates"].setdefault(u.raid_item_id, []).append(u)
        lookups["codes"] = {i.id: i.code for i in items}
    workstreams = sorted(lookups["workstreams"].values()) or [
        "Compute & Storage",
        "Data Protection",
        "Networking",
        "Security",
        "Operations",
        "Migration",
    ]

    lists.add("L_Scale", [str(n) for n in range(1, settings.risk_scale + 1)])
    lists.add("L_MonitorStatus", [m.value for m in MonitorStatus])
    lists.add("L_Organization", [o.value for o in Organization])
    lists.add("L_Workstream", workstreams)
    lists.add("L_Forum", list(dict.fromkeys([*ESCALATION_FORUM.values(), "SteerCo", "EA-PM alignment"])))
    lists.add("L_Severity", ["Low", "Medium", "High", "Critical"])
    lists.add("L_ChangeControl", ["Pending", "Approved", "Rejected"])

    for _key, label, raid_type in RAID_TABS:
        if raid_type is None:
            continue
        cols = columns_for(raid_type, export=True)
        ws = wb.create_sheet(sheet_title(ctx.t(label)), index=len(wb.sheetnames) - 1)
        title = (
            f"{ctx.t(label).upper()} {ctx.t('log')}"
            if ctx.lang == "en"
            else f"{ctx.t('log')} · {ctx.t(label).upper()}"
        )
        write_banner(ws, st, title, len(cols))
        fields = [c.field for c in cols]
        if ctx.filled:
            rows = [[_value(i, f, lookups) for f in fields] for i in items if i.type == raid_type]
            example = False
        else:
            base = ctx.today - timedelta(days=7)
            rows = [[_example_value(ex, f, base) for f in fields] for ex in EXAMPLES[raid_type]]
            example = True
        write_table(ws, st, ctx, _xcols(cols), rows, lists, example=example)
        _formulas_and_rules(ws, st, fields, settings)
        add_banding(ws, st, len(cols))
    wb.active = 1  # se abre en Risks, como en la captura
    out = BytesIO()
    wb.save(out)
    return out.getvalue()


def _example_value(ex: dict[str, Any], field: str, base: date) -> Any:
    if field in DATES:
        return base if field == "date_added" else base + timedelta(days=21)
    if field == "workstream_id":
        return "Compute & Storage"
    return ex.get(field, "")


def _formulas_and_rules(ws: Any, st: Any, fields: list[str], settings: ProgramSettings) -> None:
    def col(field: str) -> str:
        return get_column_letter(fields.index(field) + 1)

    first, last = FIRST_DATA_ROW, HEADER_ROW + MAX_ROWS
    if "score" in fields:
        p, i, s = col("probability"), col("impact"), col("score")
        for r in range(first, last + 1):
            cell = ws[f"{s}{r}"]
            cell.value = f'=IF(AND(ISNUMBER({p}{r}),ISNUMBER({i}{r})),{p}{r}*{i}{r},"")'
            cell.font = st.font(bold=True)
        # Punto de color + número (columna Risk Score de la captura 1)
        ws.conditional_formatting.add(
            f"{s}{first}:{s}{last}",
            IconSetRule(
                "3TrafficLights1", "num", [0, settings.amber_from, settings.red_from], showValue=True
            ),
        )
        # Riesgo rojo sin owner: owner e ID en rojo (RAID-01)
        o, idc = col("owner"), col("code")
        rule = f"AND(ISNUMBER(${s}{first}),${s}{first}>={settings.red_from},LEN(TRIM(${o}{first}))=0)"
        ws.conditional_formatting.add(
            f"{o}{first}:{o}{last}",
            FormulaRule(formula=[rule], fill=st.fill(st.red), font=st.font(bold=True, color="FFFFFF")),
        )
        ws.conditional_formatting.add(
            f"{idc}{first}:{idc}{last}",
            FormulaRule(formula=[rule], fill=st.fill(st.red), font=st.font(bold=True, color="FFFFFF")),
        )
    if "due_date" in fields and "monitor_status" in fields:
        d, m = col("due_date"), col("monitor_status")
        overdue = f'AND(ISNUMBER(${d}{first}),${d}{first}<TODAY(),${m}{first}<>"Closed")'
        ws.conditional_formatting.add(
            f"{d}{first}:{d}{last}",
            FormulaRule(formula=[overdue], fill=st.fill(st.amber), font=st.font(bold=True)),
        )
