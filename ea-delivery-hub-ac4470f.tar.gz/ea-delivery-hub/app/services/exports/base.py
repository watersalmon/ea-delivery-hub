"""Base de las plantillas (CLAUDE.md §8): contexto, nombre de fichero, portada y estilo Dell en Excel."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.worksheet import Worksheet
from sqlmodel import Session, select

from app.config import BASE_DIR, get_branding
from app.content.artifacts import ArtifactDefinition
from app.models import Baseline, Program
from app.services.exports.i18n import t
from app.services.governance import ProgramView, build_view

# Filas reservadas: 1 título, 2 banda de metodología, 3 vacía, 4 cabecera, 5+ datos
TITLE_ROW, BANNER_ROW, HEADER_ROW, FIRST_DATA_ROW = 1, 2, 4, 5
# Rango con validaciones y fórmulas para que la plantilla siga funcionando al añadir filas
MAX_ROWS = 300


@dataclass
class ExportContext:
    """Qué se exporta: plantilla vacía (program=None) o rellena con los datos de un programa."""

    mode: str  # "blank" | "filled"
    lang: str = "en"
    session: Session | None = None
    program: Program | None = None
    view: ProgramView | None = None
    version: str = "1.0"
    today: date = field(default_factory=date.today)
    item: str | None = None  # p. ej. código de ADR (T08) o id de reunión (T09)

    @property
    def filled(self) -> bool:
        return self.mode == "filled" and self.program is not None

    def t(self, key: str) -> str:
        return t(key, self.lang)


def make_context(
    session: Session, program: Program | None, mode: str, lang: str | None = None, today: date | None = None
) -> ExportContext:
    if mode == "blank" or program is None:
        return ExportContext(
            mode="blank",
            lang=lang or get_branding().get("export_language") or "en",
            session=session,
            version="1.0",
            today=today or date.today(),
        )
    assert program.id is not None
    baseline = session.exec(
        select(Baseline).where(Baseline.program_id == program.id).order_by(Baseline.version.desc())  # type: ignore[attr-defined]
    ).first()
    return ExportContext(
        mode="filled",
        lang=lang or program.export_language or "en",
        session=session,
        program=program,
        view=build_view(session, program.id, today=today),
        version=f"{baseline.version}.0" if baseline else "0.1",
        today=today or date.today(),
    )


def _slug(text: str) -> str:
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-")


def filename(ctx: ExportContext, artifact: str, ext: str) -> str:
    """{Programa}_{Artefacto}_v{versión}_{AAAAMMDD}.{ext} (CLAUDE.md §8)."""
    program = _slug(ctx.program.name) if ctx.filled and ctx.program else "Template"
    return f"{program}_{_slug(artifact)}_v{ctx.version}_{ctx.today:%Y%m%d}.{ext}"


def logo_path() -> Path | None:
    """Solo se usa un logo si existe en branding/ (CLAUDE.md §11: nunca se inventa)."""
    logo = get_branding().get("logo")
    if not logo:
        return None
    path = BASE_DIR / str(logo)
    return path if path.exists() else None


# ------------------------------------------------------------------ estilo Excel


def hex6(color: str) -> str:
    return color.lstrip("#").upper()


class Style:
    """Estilos Dell Delivery leídos de branding.yaml (nada hardcodeado)."""

    def __init__(self) -> None:
        b = get_branding()
        c, rag = b.get("colors", {}), b.get("rag", {})
        self.font_name = b.get("font_office", "Arial")
        self.blue = hex6(c.get("dell_blue", "#0076CE"))
        self.navy = hex6(c.get("navy_900", "#0A1F44"))
        self.navy_700 = hex6(c.get("navy_700", "#0B3D91"))
        self.row_alt = hex6(c.get("row_alt", "#DDEBF7"))
        self.header_sub = hex6(c.get("header_sub", "#8EA9DB"))
        self.header_dark = hex6(c.get("header_dark", "#1F3864"))
        self.banner = hex6(c.get("banner_black", "#000000"))
        self.title_on_dark = hex6(c.get("title_on_dark", "#4FA9F0"))
        self.green = hex6(rag.get("green", "#2E8540"))
        self.amber = hex6(rag.get("amber", "#F0B323"))
        self.red = hex6(rag.get("red", "#D0021B"))
        self.grey = hex6(rag.get("grey", "#8C8C8C"))
        self.classification = b.get("classification", "Internal Use - Confidential")
        self.methodology = b.get("methodology_banner", "")
        thin = Side(style="thin", color="BFBFBF")
        self.border = Border(left=thin, right=thin, top=thin, bottom=thin)

    @staticmethod
    def tint(color: str, alpha: float) -> str:
        """Color de marca mezclado con blanco (alpha = opacidad del color)."""
        rgb = [int(color[i : i + 2], 16) for i in (0, 2, 4)]
        return "".join(f"{round(255 - (255 - c) * alpha):02X}" for c in rgb)

    def font(self, **kw: Any) -> Font:
        kw.setdefault("name", self.font_name)
        kw.setdefault("size", 10)
        return Font(**kw)

    def fill(self, color: str) -> PatternFill:
        return PatternFill("solid", start_color=color, end_color=color)


@dataclass(frozen=True)
class XCol:
    """Columna de una hoja de datos exportada."""

    key: str  # etiqueta (clave i18n)
    width: float = 14
    wrap: bool = True
    list_name: str | None = None  # validación: nombre de lista en la hoja Lists
    number_format: str | None = None
    center: bool = False
    group: bool = False  # columna plegable (outline)


class Lists:
    """Hoja oculta 'Lists' con las listas cerradas; las validaciones apuntan a rangos con nombre."""

    def __init__(self, wb: Workbook) -> None:
        self.ws = wb.create_sheet("Lists")
        self.ws.sheet_state = "hidden"
        self.wb = wb
        self.col = 0
        self.names: set[str] = set()

    def add(self, name: str, values: Sequence[str]) -> str:
        if name in self.names:
            return name
        self.col += 1
        letter = get_column_letter(self.col)
        self.ws.cell(row=1, column=self.col, value=name)
        for i, v in enumerate(values or ["—"], start=2):
            self.ws.cell(row=i, column=self.col, value=v)
        last = max(len(values), 1) + 1
        ref = f"Lists!${letter}$2:${letter}${last}"
        self.wb.defined_names[name] = DefinedName(name, attr_text=ref)
        self.names.add(name)
        return name


def sheet_title(name: str) -> str:
    """Nombre de hoja válido en Excel (máx. 31 caracteres, sin []:*?/\\)."""
    return re.sub(r"[\[\]:*?/\\]", "-", name)[:31]


def write_banner(ws: Worksheet, st: Style, title: str, ncols: int) -> None:
    ws.cell(row=TITLE_ROW, column=1, value=title).font = st.font(size=18, bold=False)
    ws.row_dimensions[TITLE_ROW].height = 30
    cls = ws.cell(row=TITLE_ROW, column=ncols, value=st.classification)
    cls.font = st.font(size=8, italic=True, color=st.grey)
    cls.alignment = Alignment(horizontal="right", vertical="top")
    if st.methodology:
        ws.merge_cells(start_row=BANNER_ROW, start_column=1, end_row=BANNER_ROW, end_column=ncols)
        cell = ws.cell(row=BANNER_ROW, column=1, value=st.methodology)
        cell.font = st.font(size=9, italic=True, bold=True, color="FFFFFF")
        cell.fill = st.fill(st.banner)
        cell.alignment = Alignment(horizontal="center", vertical="center")


def write_table(
    ws: Worksheet,
    st: Style,
    ctx: ExportContext,
    cols: Sequence[XCol],
    rows: Iterable[Sequence[Any]],
    lists: Lists | None = None,
    header_row: int = HEADER_ROW,
    example: bool = False,
) -> int:
    """Cabecera azul Dell, filas, validaciones hasta MAX_ROWS, paneles inmovilizados y autofiltro.

    Devuelve la última fila con datos. `example=True` pinta las filas en gris cursiva (modo vacío).
    """
    for j, col in enumerate(cols, start=1):
        cell = ws.cell(row=header_row, column=j, value=ctx.t(col.key))
        cell.font = st.font(bold=True, color="FFFFFF")
        cell.fill = st.fill(st.blue)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = st.border
        dim = ws.column_dimensions[get_column_letter(j)]
        dim.width = col.width
        if col.group:
            dim.outlineLevel = 1
    ws.row_dimensions[header_row].height = 32

    r = header_row
    for r, values in enumerate(rows, start=header_row + 1):
        for j, (col, value) in enumerate(zip(cols, values, strict=False), start=1):
            cell = ws.cell(row=r, column=j, value=value)
            cell.alignment = Alignment(
                wrap_text=col.wrap, vertical="top", horizontal="center" if col.center else None
            )
            cell.border = st.border
            cell.font = st.font(italic=True, color=st.grey) if example else st.font()
            if col.number_format:
                cell.number_format = col.number_format

    last_row = header_row + MAX_ROWS
    ncols = len(cols)
    last_col = get_column_letter(ncols)
    for j, col in enumerate(cols, start=1):
        letter = get_column_letter(j)
        if col.list_name and lists is not None:
            dv = DataValidation(
                type="list",
                formula1=f"={col.list_name}",
                allow_blank=True,
                showErrorMessage=True,
                errorTitle=ctx.t(col.key),
                error="Pick a value from the list.",
            )
            dv.add(f"{letter}{header_row + 1}:{letter}{last_row}")
            ws.add_data_validation(dv)
        if col.number_format:
            for rr in range(r + 1, last_row + 1):
                ws.cell(row=rr, column=j).number_format = col.number_format

    ws.freeze_panes = ws.cell(row=header_row + 1, column=2)
    ws.auto_filter.ref = f"A{header_row}:{last_col}{max(r, header_row + 1)}"
    ws.sheet_view.zoomScale = 90
    ws.oddFooter.center.text = st.classification
    ws.oddFooter.right.text = "&P / &N"
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_title_rows = f"{header_row}:{header_row}"
    # Área de impresión = datos reales (+ unas filas libres), no las MAX_ROWS preparadas para crecer
    ws.print_area = f"A1:{last_col}{max(r, header_row) + 5}"
    return r


def add_banding(ws: Worksheet, st: Style, ncols: int, header_row: int = HEADER_ROW) -> None:
    """Filas alternas azul claro como formato condicional (sobrevive a ordenar y filtrar).

    Se añade al final para que tenga la menor prioridad y no tape los formatos RAG.
    """
    last_col = get_column_letter(ncols)
    ws.conditional_formatting.add(
        f"A{header_row + 1}:{last_col}{header_row + MAX_ROWS}",
        FormulaRule(formula=["MOD(ROW(),2)=0"], fill=st.fill(st.row_alt)),
    )


def write_cover(
    wb: Workbook, st: Style, ctx: ExportContext, artifact_title: str, defn: ArtifactDefinition | None = None
) -> Worksheet:
    """Hoja Cover: programa, cliente, versión, fecha, owner, estado, clasificación y control de versiones."""
    ws = wb.active
    assert ws is not None
    ws.title = sheet_title(ctx.t("cover"))
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 26
    ws.column_dimensions["C"].width = 60
    ws.column_dimensions["D"].width = 22
    ws.column_dimensions["E"].width = 40

    ws.merge_cells("B2:E2")
    title = ws["B2"]
    title.value = artifact_title
    title.font = st.font(size=22, color=st.title_on_dark)
    title.fill = st.fill(st.navy)
    title.alignment = Alignment(vertical="center", indent=1)
    ws.row_dimensions[2].height = 44
    if st.methodology:
        ws.merge_cells("B3:E3")
        ws["B3"].value = st.methodology
        ws["B3"].font = st.font(size=9, italic=True, bold=True, color="FFFFFF")
        ws["B3"].fill = st.fill(st.banner)
        ws["B3"].alignment = Alignment(horizontal="center")

    p = ctx.program if ctx.filled else None
    meta = [
        ("program", p.name if p else "<Program name>"),
        ("customer", p.client if p else "<Customer>"),
        ("version", ctx.version),
        ("date", ctx.today),
        ("owner", (p.ea or p.pm) if p else "<Enterprise Architect>"),
        ("status", ctx.t("draft")),
        ("classification", st.classification),
    ]
    for i, (key, value) in enumerate(meta, start=5):
        k = ws.cell(row=i, column=2, value=ctx.t(key))
        k.font = st.font(bold=True, color="FFFFFF")
        k.fill = st.fill(st.blue)
        k.border = st.border
        v = ws.cell(row=i, column=3, value=value)
        v.border = st.border
        v.font = st.font(italic=not p, color=None if p else st.grey)
        if isinstance(value, date):
            v.number_format = "m/d/yyyy"
            v.alignment = Alignment(horizontal="left")

    row = 5 + len(meta) + 1
    if defn is not None:
        for key, text in (
            ("purpose", defn.purpose),
            ("process", "\n".join(f"{n}. {x}" for n, x in enumerate(defn.process, 1))),
            ("additional", "\n".join(f"• {x}" for x in defn.additional)),
        ):
            h = ws.cell(row=row, column=2, value=ctx.t(key) + ":")
            h.font = st.font(bold=True, underline="single")
            h.alignment = Alignment(vertical="top")
            ws.merge_cells(start_row=row, start_column=3, end_row=row, end_column=5)
            body = ws.cell(row=row, column=3, value=text)
            body.alignment = Alignment(wrap_text=True, vertical="top")
            ws.row_dimensions[row].height = 15 * max(2, text.count("\n") + 2)
            row += 1
        row += 1

    ws.cell(row=row, column=2, value=ctx.t("version_control")).font = st.font(bold=True, size=11)
    row += 1
    for j, key in enumerate(("version", "date", "author", "changes"), start=2):
        c = ws.cell(row=row, column=j, value=ctx.t(key))
        c.font = st.font(bold=True, color="FFFFFF")
        c.fill = st.fill(st.blue)
        c.border = st.border
    values = [ctx.version, ctx.today, (p.ea if p else ""), ctx.t("first_issue") + " · " + ctx.t("issued")]
    for j, value in enumerate(values, start=2):
        c = ws.cell(row=row + 1, column=j, value=value)
        c.border = st.border
        if isinstance(value, date):
            c.number_format = "m/d/yyyy"
    if not ctx.filled:
        note = ws.cell(row=row + 3, column=2, value=ctx.t("example_note"))
        note.font = st.font(italic=True, color=st.grey)

    logo = logo_path()
    if logo is not None:
        from openpyxl.drawing.image import Image

        img = Image(str(logo))
        img.height, img.width = 40, 40 * img.width / max(img.height, 1)
        ws.add_image(img, "E5")
    ws.oddFooter.center.text = st.classification
    ws.page_setup.orientation = "landscape"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    return ws


def add_note(ws: Worksheet, ref: str, text: str) -> None:
    ws[ref].comment = Comment(text, "EA Delivery Hub")


def new_workbook() -> tuple[Workbook, Style]:
    wb = Workbook()
    wb.properties.creator = "EA Delivery Hub"
    return wb, Style()
