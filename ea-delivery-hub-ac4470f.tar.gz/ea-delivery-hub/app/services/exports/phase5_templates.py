"""Plantillas de la Fase 5: T07 Stakeholder Map & Comms Plan, T13 ORR, T14 As-built & Handover + DoD, T17 Lessons Learned."""

from __future__ import annotations

import json
from io import BytesIO
from typing import Any

from openpyxl.formatting.rule import CellIsRule, FormulaRule
from sqlmodel import col, select

from app.content.artifacts import ARTIFACTS
from app.content.guide import EA_DOD
from app.models import Baseline, ChecklistItem, HandoverItem, ORRCheck, RAIDItem, Stakeholder
from app.models.enums import ADR_OPEN, RAIDType
from app.services.exports.base import (
    FIRST_DATA_ROW,
    HEADER_ROW,
    MAX_ROWS,
    ExportContext,
    Lists,
    XCol,
    add_banding,
    new_workbook,
    write_banner,
    write_cover,
    write_table,
)
from app.services.exports.docx_base import Doc


def _save(wb: Any) -> bytes:
    out = BytesIO()
    wb.save(out)
    return out.getvalue()


# ------------------------------------------------------------------ T07 Stakeholder Map & Comms Plan


def build_t07(ctx: ExportContext) -> bytes:
    wb, st = new_workbook()
    write_cover(wb, st, ctx, "Stakeholder Map & Comms Plan", ARTIFACTS["stakeholders"])
    lists = Lists(wb)
    lists.add("L_Org", ["Customer", "Dell", "Partner"])
    lists.add("L_Stance", ["Sponsor", "Neutral", "Detractor"])
    lists.add("L_1to5", ["1", "2", "3", "4", "5"])
    lists.add("L_YesNo", ["Yes", "No"])
    if ctx.filled and ctx.session is not None and ctx.program is not None:
        people = ctx.session.exec(select(Stakeholder).where(Stakeholder.program_id == ctx.program.id)).all()
        rows: list[list[Any]] = [
            [
                s.name,
                s.organization,
                s.role,
                s.influence,
                s.interest,
                s.stance,
                "Yes" if s.is_decision_maker else "No",
                s.key_message,
                s.channel,
                s.cadence,
                s.comms_owner,
            ]
            for s in sorted(people, key=lambda s: (-s.influence, s.name))
        ]
    else:
        rows = [
            [
                "<Name>",
                "Customer",
                "CIO / Sponsor",
                5,
                5,
                "Sponsor",
                "Yes",
                "Outcome on time with predictable cost",
                "SteerCo",
                "Monthly",
                "EA",
            ],
            [
                "<Name>",
                "Customer",
                "Head of Operations",
                4,
                3,
                "Detractor",
                "No",
                "A platform the team can run",
                "1:1",
                "Weekly",
                "EA",
            ],
        ]
    ws = wb.create_sheet("Comms Plan", index=len(wb.sheetnames) - 1)
    cols = [
        XCol("Stakeholder", 20),
        XCol("Organization", 13, list_name="L_Org", center=True),
        XCol("Role", 22),
        XCol("Influence", 9, list_name="L_1to5", center=True),
        XCol("Interest", 9, list_name="L_1to5", center=True),
        XCol("Stance", 11, list_name="L_Stance", center=True),
        XCol("Decision maker", 10, list_name="L_YesNo", center=True),
        XCol("Key message", 40),
        XCol("Channel", 20),
        XCol("Cadence", 12),
        XCol("Owner", 16),
    ]
    write_banner(ws, st, "STAKEHOLDER MAP & COMMS PLAN", len(cols))
    write_table(ws, st, ctx, cols, rows, lists, example=not ctx.filled)
    first, last = FIRST_DATA_ROW, HEADER_ROW + MAX_ROWS
    ws.conditional_formatting.add(
        f"F{first}:F{last}",
        CellIsRule(
            operator="equal",
            formula=['"Detractor"'],
            fill=st.fill(st.red),
            font=st.font(bold=True, color="FFFFFF"),
        ),
    )
    ws.conditional_formatting.add(
        f"F{first}:F{last}",
        CellIsRule(
            operator="equal",
            formula=['"Sponsor"'],
            fill=st.fill(st.green),
            font=st.font(bold=True, color="FFFFFF"),
        ),
    )
    # STK-01: aviso si no hay decisores o no hay detractores identificados (fórmula viva)
    note_row = HEADER_ROW + max(len(rows), 1) + 3
    ws.cell(row=note_row, column=1, value="STK-01 check").font = st.font(bold=True)
    check = ws.cell(
        row=note_row,
        column=2,
        value=(
            f'=IF(COUNTIF(G{first}:G{last},"Yes")=0,"Missing decision makers",'
            f'IF(COUNTIF(F{first}:F{last},"Detractor")=0,"No detractors identified","OK: decision makers and detractors identified"))'
        ),
    )
    check.font = st.font(bold=True)
    ws.conditional_formatting.add(
        f"B{note_row}", FormulaRule(formula=[f'LEFT(B{note_row},2)<>"OK"'], fill=st.fill(st.amber))
    )
    add_banding(ws, st, len(cols))
    wb.active = 1
    return _save(wb)


# ------------------------------------------------------------------ T13 Operational Readiness Review

ORR_EXAMPLE = [
    ["Monitoring", "Platform and service alerts routed to the customer NOC", "", "grey", "<Owner>"],
    ["Backup", "Backup policies tested with a restore drill", "", "grey", "<Owner>"],
    ["Support", "Support model, L1-L3 and escalation matrix agreed", "", "grey", "<Owner>"],
    ["Access", "Privileged access managed through the customer PAM", "", "grey", "<Owner>"],
    ["Capacity", "Capacity baseline and growth thresholds defined", "", "grey", "<Owner>"],
    ["Runbooks", "Runbooks reviewed and accepted by operations", "", "grey", "<Owner>"],
    ["Skills", "Operations team trained and shadowing completed", "", "grey", "<Owner>"],
]
RAG_WORD = {"green": "Green", "amber": "Amber", "red": "Red", "grey": "Not assessed"}


def build_t13(ctx: ExportContext) -> bytes:
    wb, st = new_workbook()
    write_cover(wb, st, ctx, "Operational Readiness Review")
    lists = Lists(wb)
    lists.add("L_RAG4", ["Green", "Amber", "Red", "Not assessed"])
    if ctx.filled and ctx.session is not None and ctx.program is not None:
        checks = ctx.session.exec(
            select(ORRCheck).where(ORRCheck.program_id == ctx.program.id).order_by(col(ORRCheck.id))
        ).all()
        rows: list[list[Any]] = [
            [c.dimension, c.criterion, c.evidence, RAG_WORD.get(c.status, c.status), c.owner] for c in checks
        ]
    else:
        rows = [[d, c, e, "", o] for d, c, e, _s, o in ORR_EXAMPLE]
    ws = wb.create_sheet("ORR", index=len(wb.sheetnames) - 1)
    cols = [
        XCol("Dimension", 16),
        XCol("Criterion", 46),
        XCol("Evidence", 40),
        XCol("Status", 13, list_name="L_RAG4", center=True),
        XCol("Owner", 18),
    ]
    write_banner(ws, st, "OPERATIONAL READINESS REVIEW", len(cols))
    write_table(ws, st, ctx, cols, rows, lists, example=False)
    first, last = FIRST_DATA_ROW, HEADER_ROW + MAX_ROWS
    for word, color, font in (
        ("Green", st.green, "FFFFFF"),
        ("Amber", st.amber, "000000"),
        ("Red", st.red, "FFFFFF"),
    ):
        ws.conditional_formatting.add(
            f"D{first}:D{last}",
            CellIsRule(
                operator="equal",
                formula=[f'"{word}"'],
                fill=st.fill(color),
                font=st.font(bold=True, color=font),
            ),
        )
    gate_row = HEADER_ROW + max(len(rows), 1) + 3
    ws.cell(row=gate_row, column=1, value="G5 readiness").font = st.font(bold=True)
    g = ws.cell(
        row=gate_row,
        column=2,
        value=f'=IF(COUNTIF(D{first}:D{last},"Red")>0,"BLOCKED: "&COUNTIF(D{first}:D{last},"Red")&" red check(s) (ORR-01)","Not blocked by readiness")',
    )
    g.font = st.font(bold=True)
    ws.conditional_formatting.add(
        f"B{gate_row}",
        FormulaRule(
            formula=[f'LEFT(B{gate_row},7)="BLOCKED"'],
            fill=st.fill(st.red),
            font=st.font(bold=True, color="FFFFFF"),
        ),
    )
    add_banding(ws, st, len(cols))
    wb.active = 1
    return _save(wb)


# ------------------------------------------------------------------ T14 As-built & Handover + EA Definition of Done


def build_t14(ctx: ExportContext) -> bytes:
    d = Doc(ctx)
    d.cover(
        "As-built & Handover",
        "Final architecture, deviations, technical debt and ownership (guide §10, Annex A)",
    )
    filled = ctx.filled and ctx.session is not None and ctx.program is not None and ctx.view is not None
    d.heading("1. Baseline reconciliation", 1)
    if filled:
        assert ctx.session is not None and ctx.program is not None
        from app.services.baselines import diff_payloads, snapshot_payload

        first = ctx.session.exec(
            select(Baseline).where(Baseline.program_id == ctx.program.id).order_by(col(Baseline.version))
        ).first()
        if first:
            diff = diff_payloads(
                json.loads(first.payload), snapshot_payload(ctx.session, ctx.program.id or 0)
            )
            d.para(
                f"Baseline v{first.version} (SHA-256 {first.sha256[:16]}…) compared with the solution as implemented."
            )
            rows = [
                [
                    sec.title,
                    len(sec.added),
                    len(sec.removed),
                    len(sec.changed),
                    ", ".join(c.code for c in (sec.added + sec.changed + sec.removed)[:8]),
                ]
                for sec in diff
            ]
            d.table(["Area", "Added", "Removed", "Changed", "Items"], rows, widths=[3, 2, 2, 2, 8])
        else:
            d.para("No baseline recorded.", italic=True)
    else:
        d.table(
            ["Area", "Added", "Removed", "Changed", "Items"],
            [["Requirements", 0, 0, 0, "REQ-###"]],
            example=True,
        )

    d.heading("2. Deviations, technical debt and transfers", 1)
    if filled:
        assert ctx.session is not None and ctx.program is not None
        items = ctx.session.exec(
            select(HandoverItem)
            .where(HandoverItem.program_id == ctx.program.id)
            .order_by(col(HandoverItem.id))
        ).all()
        rows = [
            [i.kind, i.title, i.impact, i.estimated_cost, i.receiving_owner, i.review_date or ""]
            for i in items
        ] or [["", "None", "", "", "", ""]]
        d.table(
            ["Type", "Item", "Impact", "Cost", "Receiving owner", "Review"],
            rows,
            widths=[2.2, 5, 4, 2, 2.6, 2],
        )
    else:
        d.table(
            ["Type", "Item", "Impact", "Cost", "Receiving owner", "Review"],
            [["TechDebt", "<Debt>", "<Impact>", "<Cost>", "<Owner>", "<Date>"]],
            example=True,
        )

    d.heading("3. Open decisions and risks to close or transfer", 1)
    if filled:
        assert ctx.view is not None
        rows = [[a.code, a.title, a.status, a.owner] for a in ctx.view.ctx.adrs if a.status in ADR_OPEN]
        rows += [
            [i.code, i.title, i.monitor_status, i.owner]
            for i in ctx.view.ctx.raid_items
            if i.type in (RAIDType.RISK, RAIDType.ISSUE) and not i.is_closed
        ]
        d.table(
            ["ID", "Item", "Status", "Current owner"], rows or [["", "None", "", ""]], widths=[2, 9, 3, 3]
        )
    else:
        d.table(
            ["ID", "Item", "Status", "Current owner"],
            [["ADR-### / RK-###", "<Item>", "<Status>", "<Owner>"]],
            example=True,
        )

    d.heading("4. EA Definition of Done (Annex A)", 1)
    done: dict[int, bool] = {}
    if filled:
        assert ctx.session is not None and ctx.program is not None
        done = {
            c.item_key: c.checked
            for c in ctx.session.exec(
                select(ChecklistItem).where(
                    ChecklistItem.program_id == ctx.program.id, ChecklistItem.checklist == "ea_dod"
                )
            ).all()
        }
    fills = {(k, 0): d.st.green for k in range(len(EA_DOD)) if done.get(k)}
    d.table(
        ["Done", "Criterion"],
        [["✔" if done.get(k) else "☐", t] for k, t in enumerate(EA_DOD)],
        widths=[1.5, 15.5],
        fills=fills,
    )
    d.heading("5. Acceptance", 1)
    d.kv_table([("Accepted by (customer)", ""), ("Accepted by (operations)", ""), ("Date", "")])
    return d.save()


# ------------------------------------------------------------------ T17 Lessons Learned


def build_t17(ctx: ExportContext) -> bytes:
    wb, st = new_workbook()
    write_cover(wb, st, ctx, "Lessons Learned")
    lists = Lists(wb)
    if ctx.filled and ctx.session is not None and ctx.program is not None:
        items = ctx.session.exec(
            select(RAIDItem)
            .where(RAIDItem.program_id == ctx.program.id, RAIDItem.type == RAIDType.LESSON)
            .order_by(col(RAIDItem.code))
        ).all()
        rows: list[list[Any]] = [
            [i.code, i.title, i.context, i.decision_taken, i.result, i.recommendation, i.owner] for i in items
        ]
    else:
        rows = [
            [
                "LL-001",
                "Engage facilities before ordering hardware",
                "Racks ordered before power was confirmed",
                "Phased rack power-on with generators",
                "Two-week delay instead of six",
                "Make power confirmation a G3 criterion",
                "EA",
            ]
        ]
    ws = wb.create_sheet("Lessons Learned", index=len(wb.sheetnames) - 1)
    cols = [
        XCol("ID", 9, wrap=False, center=True),
        XCol("Lesson", 30),
        XCol("Context", 34),
        XCol("Decision", 30),
        XCol("Result", 28),
        XCol("Recommendation", 36),
        XCol("Owner", 16),
    ]
    write_banner(ws, st, "LESSONS LEARNED", len(cols))
    write_table(ws, st, ctx, cols, rows, lists, example=not ctx.filled)
    ws.conditional_formatting.add(
        f"F{FIRST_DATA_ROW}:F{HEADER_ROW + MAX_ROWS}",
        FormulaRule(
            formula=[f'AND($A{FIRST_DATA_ROW}<>"",LEN(TRIM($F{FIRST_DATA_ROW}))=0)'], fill=st.fill(st.amber)
        ),
    )
    add_banding(ws, st, len(cols))
    wb.active = 1
    return _save(wb)
