"""Plantillas Word de la Fase 4: T01 Architecture Brief, T02 Governance Charter, T08 ADR y T09 Design Authority."""

from __future__ import annotations

from datetime import date, timedelta

from sqlmodel import col, select

from app.content.guide import (
    BRIEF_MAX_WORDS,
    BRIEF_SECTIONS,
    DA_AGENDA,
    DA_CRITERIA,
    DA_INPUT,
    DA_OUTPUT,
    DA_PARTICIPANTS,
    DA_SLA,
    ESCALATION_LEVELS,
    FORUMS,
)
from app.models import ADR, ADROption, ArchitectureBrief, Meeting, MeetingDecision
from app.services.exports.base import ExportContext
from app.services.exports.docx_base import Doc

# ------------------------------------------------------------------ T01 Architecture Brief

EXAMPLE_BRIEF = {
    "outcomes": "Provision infrastructure in under one day (today 15 days). Predictable spend within ±5% of forecast.",
    "scope_in": "Two-site private cloud: compute, block and file storage, backup and cyber recovery vault.",
    "scope_out": "Application refactoring; end-user devices; public cloud workloads.",
    "context": "Customer data centres A and B, existing virtualisation estate, national security requirements.",
    "principles": "Data and keys stay in-country. Operations-ready from day one. Prefer reversible decisions.",
    "workstreams": "Compute & Storage; Data Protection; Networking; Security; Operations; Migration.",
    "risks_assumptions": "Power readiness of the new halls; hardware lead times; operations skills.",
    "open_decisions": "Key management model (owner, date); VDI broker pools.",
    "governance": "Weekly Design Authority; EA-PM alignment; monthly SteerCo with the CIO as sponsor.",
}


def brief_text(ctx: ExportContext) -> dict[str, str]:
    if not (ctx.filled and ctx.session is not None and ctx.program is not None):
        return EXAMPLE_BRIEF
    b = ctx.session.exec(
        select(ArchitectureBrief).where(ArchitectureBrief.program_id == ctx.program.id)
    ).first()
    return {s.key: (getattr(b, s.key) if b else "") for s in BRIEF_SECTIONS}


def build_t01(ctx: ExportContext) -> bytes:
    d = Doc(ctx)
    d.cover("Architecture Brief", "One to two pages · understood in ten minutes (guide §13.1)")
    text = brief_text(ctx)
    words = sum(len(v.split()) for v in text.values())
    if ctx.filled and words > BRIEF_MAX_WORDS:
        d.para(
            f"Warning: this brief has {words} words and will likely exceed two pages.",
            italic=True,
            color=d.st.red,
        )
    for s in BRIEF_SECTIONS:
        d.heading(s.title, 2)
        value = text.get(s.key, "")
        if ctx.filled:
            d.para(value or "—")
        else:
            d.example(value)
    return d.save()


# ------------------------------------------------------------------ T02 Governance Charter


def build_t02(ctx: ExportContext) -> bytes:
    d = Doc(ctx)
    d.cover("Architecture Governance Charter", "Forums, Design Authority, escalation and calendar")
    d.heading("1. Forums", 1)
    d.table(["Forum", "Frequency", "Purpose", "Output"], [list(f) for f in FORUMS], widths=[4, 3, 6, 4])
    d.heading("2. Design Authority", 1)
    d.kv_table(
        [
            ("Input", DA_INPUT),
            ("Participants", ", ".join(DA_PARTICIPANTS)),
            ("Criteria", ", ".join(label for _k, label in DA_CRITERIA)),
            ("Output", DA_OUTPUT),
            ("SLA", DA_SLA),
        ]
    )
    d.para("")
    d.heading("Agenda (60 minutes)", 2)
    d.table(["Minutes", "Block"], [[m, t] for m, t in DA_AGENDA], widths=[2, 15])
    d.heading("3. Escalation levels", 1)
    d.table(["Level", "Example", "Forum"], [list(x) for x in ESCALATION_LEVELS], widths=[3, 9, 5])
    d.heading("4. Calendar", 1)
    rows = []
    if ctx.filled and ctx.session is not None and ctx.program is not None:
        meetings = ctx.session.exec(
            select(Meeting)
            .where(Meeting.program_id == ctx.program.id, Meeting.meeting_date >= ctx.today)
            .order_by(col(Meeting.meeting_date))
        ).all()
        rows = [[m.meeting_date, m.forum, m.status, m.agenda] for m in meetings]
    # Cadencia estándar de las próximas 4 semanas (guía §5.1) para completar el calendario
    monday = ctx.today + timedelta(days=(7 - ctx.today.weekday()) % 7 or 7)
    for w in range(4):
        week = monday + timedelta(weeks=w)
        rows += [
            [week, "Workstream design sync", "Planned", ""],
            [week + timedelta(days=1), "EA-PM alignment", "Planned", ""],
            [week + timedelta(days=3), "Architecture Design Authority", "Planned", ""],
        ]
        if w % 2 == 1:
            rows.append([week + timedelta(days=2), "Customer architecture review", "Planned", ""])
    rows.append([monday + timedelta(weeks=4), "SteerCo", "Planned", "Monthly / per gate"])
    rows.sort(key=lambda r: r[0] if isinstance(r[0], date) else ctx.today)
    d.table(["Date", "Forum", "Status", "Agenda"], rows, widths=[3, 5, 2.5, 6.5], example=not ctx.filled)
    d.heading("5. Repository and decision log", 1)
    d.para(
        "Decisions are recorded as ADRs in EA Delivery Hub; the RAID log, RTM and baselines live in the same repository."
    )
    return d.save()


# ------------------------------------------------------------------ T08 ADR (una por decisión)


def _adr_for(ctx: ExportContext) -> ADR | None:
    if not (ctx.filled and ctx.session is not None and ctx.program is not None):
        return None
    stmt = select(ADR).where(ADR.program_id == ctx.program.id)
    if ctx.item:
        adr = ctx.session.exec(stmt.where(ADR.code == ctx.item)).first()
        if adr is None:
            raise LookupError(f"ADR {ctx.item} not found")
        return adr
    return ctx.session.exec(stmt.order_by(col(ADR.code))).first()


def build_t08(ctx: ExportContext) -> bytes:
    adr = _adr_for(ctx)
    d = Doc(ctx)
    title = f"{adr.code} · {adr.title}" if adr else "ADR-### · <Concrete decision>"
    d.cover("Architecture Decision Record", title, status=adr.status if adr else "Proposed")
    if adr is None:
        rows = [
            ("ID / Title", "ADR-### | Concrete decision"),
            ("Status", "Proposed / Approved / Rejected / Superseded"),
            ("Context", "Problem, drivers and constraints"),
            ("Options", "Real alternatives considered"),
            ("Decision", "Chosen option and conditions"),
            ("Rationale", "Why it is the best option in this context"),
            ("Consequences", "Benefits, trade-offs, risks and debt"),
            ("Impacts", "Artifacts, workstreams, cost, schedule, operations"),
            ("Approvers / date", "Authority and record date"),
        ]
        d.kv_table(rows)
        return d.save()
    assert ctx.session is not None
    options = ctx.session.exec(
        select(ADROption).where(ADROption.adr_id == adr.id).order_by(col(ADROption.id))
    ).all()
    impacts = "\n".join(
        x
        for x in (
            f"Artifacts: {adr.impacted_artifacts}" if adr.impacted_artifacts else "",
            f"Workstreams: {adr.impacted_workstreams}" if adr.impacted_workstreams else "",
            f"Cost: {adr.cost_impact}" if adr.cost_impact else "",
            f"Schedule: {adr.schedule_impact}" if adr.schedule_impact else "",
            f"Operations: {adr.operations_impact}" if adr.operations_impact else "",
        )
        if x
    )
    d.kv_table(
        [
            ("ID / Title", f"{adr.code} | {adr.title}"),
            ("Status", adr.status),
            ("Context", adr.context or "—"),
            ("Options", "\n".join(f"{'✔ ' if o.chosen else '• '}{o.name}" for o in options) or "—"),
            ("Decision", adr.decision or "—"),
            ("Conditions", adr.conditions or "—"),
            ("Rationale", adr.rationale or "—"),
            ("Consequences", adr.consequences or "—"),
            ("Impacts", impacts or "—"),
            ("Escalation level", adr.escalation_level),
            ("Critical path", "Yes" if adr.critical_path else "No"),
            ("Owner / due date", f"{adr.owner or '—'} · {adr.due_date or '—'}"),
            ("Approvers / date", f"{adr.approvers or '—'} · {adr.approved_at or '—'}"),
        ]
    )
    if options:
        d.para("")
        d.heading("Options and trade-offs", 2)
        header = ["Option", *[label for _k, label in DA_CRITERIA], "Total"]
        trade_rows: list[list[object]] = [
            [
                o.name,
                *[(o.scores or {}).get(k, "") for k, _l in DA_CRITERIA],
                sum(int(v) for v in (o.scores or {}).values()),
            ]
            for o in options
        ]
        d.table(header, trade_rows)
        d.table(
            ["Option", "Pros", "Cons", "Cost", "Risk"],
            [[o.name, o.pros, o.cons, o.cost, o.risk] for o in options],
        )
    return d.save()


# ------------------------------------------------------------------ T09 Design Authority (agenda y acta)


def build_t09(ctx: ExportContext) -> bytes:
    d = Doc(ctx)
    meeting = None
    if ctx.filled and ctx.session is not None and ctx.program is not None:
        stmt = select(Meeting).where(
            Meeting.program_id == ctx.program.id, Meeting.forum == "Architecture Design Authority"
        )
        if ctx.item:
            meeting = ctx.session.get(Meeting, int(ctx.item)) if ctx.item.isdigit() else None
            if meeting is None or meeting.program_id != ctx.program.id:
                raise LookupError(f"Design Authority session {ctx.item} not found")
        else:
            meeting = ctx.session.exec(stmt.order_by(col(Meeting.meeting_date).desc())).first()
    closed = meeting is not None and meeting.status == "Closed"
    kind = "Minutes" if closed else "Agenda"
    when = f"{meeting.meeting_date:%d %b %Y}" if meeting else "<Date>"
    d.cover(f"Design Authority · {kind}", f"Session of {when}", status="Final" if closed else "Draft")

    d.heading("Agenda (guide §13.3)", 1)
    d.table(["Minutes", "Block"], [[m, t] for m, t in DA_AGENDA], widths=[2, 15])
    d.heading("Quorum", 1)
    if meeting is not None and meeting.participants:
        d.table(
            ["Role", "Name", "Present"],
            [
                [p.get("role"), p.get("name"), "Yes" if p.get("present") else "No"]
                for p in meeting.participants
            ],
            widths=[5, 8, 3],
        )
        if closed:
            d.para(f"Quorum {'met' if meeting.quorum_met else 'NOT met'}.", italic=True)
    else:
        d.table(
            ["Role", "Name", "Present"],
            [[r, "", ""] for r in DA_PARTICIPANTS],
            widths=[5, 8, 3],
            example=True,
        )

    d.heading("Decisions", 1)
    rows = []
    fills: dict[tuple[int, int], str] = {}
    if meeting is not None and ctx.session is not None:
        decisions = ctx.session.exec(
            select(MeetingDecision)
            .where(MeetingDecision.meeting_id == meeting.id)
            .order_by(col(MeetingDecision.order))
        ).all()
        for i, dec in enumerate(decisions):
            adr = ctx.session.get(ADR, dec.adr_id)
            rows.append(
                [
                    adr.code if adr else "",
                    adr.title if adr else "",
                    dec.outcome or "Pending",
                    dec.conditions,
                    dec.owner,
                    dec.due_date or "",
                ]
            )
            color = {"Approved": d.st.green, "Rejected": d.st.red, "Deferred": d.st.amber}.get(dec.outcome)
            if color:
                fills[(i, 2)] = color
    else:
        rows = [
            ["ADR-###", "<Decision>", "Approved / Rejected / Deferred", "<Conditions>", "<Owner>", "<Date>"]
        ]
    d.table(
        ["ADR", "Decision", "Outcome", "Conditions", "Owner", "Due"],
        rows,
        widths=[2, 5, 2.5, 4, 2.5, 2],
        example=meeting is None,
        fills=fills,
    )

    d.heading("Actions", 1)
    if meeting is not None and ctx.session is not None:
        from app.services.governance_ops import meeting_actions

        acts = meeting_actions(ctx.session, meeting)
        d.table(
            ["ID", "Action", "Owner", "Due"],
            [[a.code, a.title, a.owner, a.due_date or ""] for a in acts] or [["", "None", "", ""]],
            widths=[2, 10, 3, 2],
        )
    else:
        d.table(
            ["ID", "Action", "Owner", "Due"],
            [["AC-###", "<Action>", "<Owner>", "<Date>"]],
            widths=[2, 10, 3, 2],
            example=True,
        )
    d.heading("Communication", 2)
    d.para(
        "Decisions and actions are recorded in EA Delivery Hub (ADR log and RAID) and shared with the PM and the SteerCo."
    )
    return d.save()
