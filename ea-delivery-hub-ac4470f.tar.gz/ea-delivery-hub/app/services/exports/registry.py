"""Catálogo de las 17 plantillas (CLAUDE.md §8)."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from app.services.exports import (
    docx_templates,
    phase5_templates,
    pptx_slides,
    t03_t05_trace,
    t04_raid,
    t06_t12_xlsx,
    xlsx_phase4,
)
from app.services.exports.base import ExportContext

XLSX = "xlsx"
PPTX = "pptx"
DOCX = "docx"
MEDIA = {
    DOCX: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    XLSX: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    PPTX: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
}


@dataclass(frozen=True)
class Template:
    tid: str
    name: str
    fmt: str
    build: Callable[[ExportContext], bytes]
    artifact: str  # nombre en el fichero
    per_item: bool = False  # una exportación por elemento (?item=ADR-001, ?item=<id de reunión>)


def _t16(artifact: str) -> Callable[[ExportContext], bytes]:
    return lambda ctx: pptx_slides.build_t16(ctx, artifact)


TEMPLATES: dict[str, Template] = {
    t.tid: t
    for t in [
        Template("T01", "Architecture Brief", DOCX, docx_templates.build_t01, "Architecture-Brief"),
        Template(
            "T02", "Architecture Governance Charter", DOCX, docx_templates.build_t02, "Governance-Charter"
        ),
        Template(
            "T03", "Goals & Solution Dependency Map", XLSX, t03_t05_trace.build_t03, "Solution-Dependency-Map"
        ),
        Template("T04", "RAID Log", XLSX, t04_raid.build, "RAID-Log"),
        Template("T05", "Requirements Traceability Matrix", XLSX, t03_t05_trace.build_t05, "RTM"),
        Template("T06", "RACI Matrix", XLSX, t06_t12_xlsx.build_t06, "RACI"),
        Template(
            "T07", "Stakeholder Map & Comms Plan", XLSX, phase5_templates.build_t07, "Stakeholder-Comms-Plan"
        ),
        Template("T08", "Architecture Decision Record", DOCX, docx_templates.build_t08, "ADR", per_item=True),
        Template("T08-log", "Decision Log", XLSX, xlsx_phase4.build_t08_log, "Decision-Log"),
        Template(
            "T09",
            "Design Authority agenda & minutes",
            DOCX,
            docx_templates.build_t09,
            "Design-Authority",
            per_item=True,
        ),
        Template("T10", "HLD / LLD Review Checklist", XLSX, xlsx_phase4.build_t10, "Design-Review-Checklist"),
        Template("T11", "Architecture Roadmap", XLSX, xlsx_phase4.build_t11, "Architecture-Roadmap"),
        Template("T12", "Weekly Health Check", XLSX, t06_t12_xlsx.build_t12_xlsx, "Weekly-Health-Check"),
        Template(
            "T12-slide",
            "Weekly Health Check (slide)",
            PPTX,
            pptx_slides.build_t12_pptx,
            "Weekly-Health-Check",
        ),
        Template(
            "T13", "Operational Readiness Review", XLSX, phase5_templates.build_t13, "Operational-Readiness"
        ),
        Template(
            "T14", "As-built & Handover + EA DoD", DOCX, phase5_templates.build_t14, "As-built-Handover"
        ),
        Template("T15", "First 10 days · EA onboarding", XLSX, xlsx_phase4.build_t15, "First-10-Days"),
        Template("T16-raid", "Status slide · RAID", PPTX, _t16("raid"), "Slide-RAID"),
        Template(
            "T16-goals",
            "Status slide · Solution Dependency Map",
            PPTX,
            _t16("goals"),
            "Slide-Solution-Dependency-Map",
        ),
        Template("T16-rtm", "Status slide · RTM", PPTX, _t16("rtm"), "Slide-RTM"),
        Template("T16-raci", "Status slide · RACI", PPTX, _t16("raci"), "Slide-RACI"),
        Template("T17", "Lessons Learned", XLSX, phase5_templates.build_t17, "Lessons-Learned"),
    ]
}
