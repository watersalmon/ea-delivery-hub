"""T06 · RACI Matrix (XLSX) y T12 · Weekly Health Check (XLSX).

T06: actividades x roles con lista R/A/C/I/A/R/A/C y fórmula por fila que cuenta los A (rojo si ≠ 1).
T12: los 7 controles de la guía §11.1 con su RAG, criterios y motivo (reglas), más la hoja de hallazgos.
"""

from __future__ import annotations

from io import BytesIO
from typing import Any

from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter

from app.content.artifacts import ARTIFACTS
from app.models.enums import RACIValue
from app.rules.base import CONTROLS
from app.services.exports.base import (
    FIRST_DATA_ROW,
    HEADER_ROW,
    MAX_ROWS,
    ExportContext,
    Lists,
    XCol,
    add_banding,
    add_note,
    new_workbook,
    sheet_title,
    write_banner,
    write_cover,
    write_table,
)

# PDR-001: RACI de la guía §9 con un solo Accountable por actividad
GUIDE_ROLES = ["EA", "PM / Delivery Lead", "Tech / Domain Lead", "Customer"]


def _raci_matrix(ctx: ExportContext) -> tuple[list[str], list[tuple[str, list[tuple[str, str]]]]]:
    if ctx.filled and ctx.session is not None and ctx.program is not None and ctx.program.id is not None:
        from app.routers.stakeholders import raci_data

        data = raci_data(ctx.session, ctx.program.id)
        roles = [r.name for r in data["roles"]]
        acts = []
        for a in data["activities"]:
            cells = []
            for r in data["roles"]:
                c = data["cells"].get((a.id, r.id))
                cells.append((c.value, c.qualifier) if c else ("", ""))
            acts.append((a.name, cells))
        return roles, acts
    from app.services.seed import RACI_GUIDE

    return GUIDE_ROLES, RACI_GUIDE


def build_t06(ctx: ExportContext) -> bytes:
    wb, st = new_workbook()
    write_cover(wb, st, ctx, ctx.t("raci"), ARTIFACTS["raci"])
    lists = Lists(wb)
    lists.add("L_RACI", [v.value for v in RACIValue])
    roles, acts = _raci_matrix(ctx)

    ws = wb.create_sheet(sheet_title(ctx.t("raci")), index=len(wb.sheetnames) - 1)
    cols = [XCol("Activity", 44)] + [XCol(r, 15, list_name="L_RACI", center=True) for r in roles]
    cols += [XCol("A count", 7, center=True), XCol("R count", 7, center=True), XCol("Check", 30)]
    write_banner(ws, st, ctx.t("raci").upper(), len(cols))
    # La primera columna de la cabecera son nombres de rol (no claves i18n): write_table los deja tal cual
    rows = [[name, *(v for v, _q in cells)] for name, cells in acts]
    write_table(ws, st, ctx, cols, rows, lists, example=False)

    n = len(roles)
    first_role, last_role = get_column_letter(2), get_column_letter(1 + n)
    a_col, r_col, chk = (get_column_letter(2 + n + k) for k in range(3))
    first, last = FIRST_DATA_ROW, HEADER_ROW + MAX_ROWS
    ok, msg_a, msg_r = ctx.t("raci_ok"), ctx.t("raci_a"), ctx.t("raci_r")
    for r in range(first, last + 1):
        rng = f"{first_role}{r}:{last_role}{r}"
        ws[f"{a_col}{r}"] = f'=IF($A{r}="","",COUNTIF({rng},"A")+COUNTIF({rng},"A/R")+COUNTIF({rng},"A/C"))'
        ws[f"{r_col}{r}"] = f'=IF($A{r}="","",COUNTIF({rng},"R")+COUNTIF({rng},"A/R"))'
        ws[f"{chk}{r}"] = f'=IF($A{r}="","",IF({a_col}{r}<>1,"{msg_a}",IF({r_col}{r}<1,"{msg_r}","{ok}")))'
        for c in (a_col, r_col, chk):
            ws[f"{c}{r}"].font = st.font()
            ws[f"{c}{r}"].alignment = Alignment(horizontal="center" if c != chk else None)
    # Calificadores de la guía (técnico, dominio, coordinación) como nota de celda
    for i, (_name, cells) in enumerate(acts):
        for j, (_v, qualifier) in enumerate(cells):
            if qualifier:
                add_note(ws, f"{get_column_letter(2 + j)}{first + i}", f"R ({qualifier})")
    bad_a = f'AND($A{first}<>"",${a_col}{first}<>1)'
    ws.conditional_formatting.add(
        f"A{first}:{chk}{last}", FormulaRule(formula=[bad_a], fill=st.fill(st.tint(st.red, 0.2)))
    )
    ws.conditional_formatting.add(
        f"{a_col}{first}:{a_col}{last}",
        FormulaRule(formula=[bad_a], fill=st.fill(st.red), font=st.font(bold=True, color="FFFFFF")),
    )
    ws.conditional_formatting.add(
        f"{r_col}{first}:{r_col}{last}",
        FormulaRule(
            formula=[f'AND($A{first}<>"",${r_col}{first}<1)'], fill=st.fill(st.amber), font=st.font(bold=True)
        ),
    )
    ws.conditional_formatting.add(
        f"{chk}{first}:{chk}{last}",
        CellIsRule(operator="equal", formula=[f'"{ok}"'], font=st.font(bold=True, color=st.green)),
    )
    add_banding(ws, st, len(cols))
    wb.active = 1
    out = BytesIO()
    wb.save(out)
    return out.getvalue()


# ------------------------------------------------------------------ T12 Weekly Health Check

# Guía §11.1: criterios verde / ámbar / rojo de cada control
HEALTH_CRITERIA = {
    "outcomes_scope": ("Stable and traced", "Minor doubts", "Contradictions or uncontrolled changes"),
    "decisions": ("Up to date, owner and date", "Non-critical items pending", "Blocking the critical path"),
    "architecture": ("Baseline in force", "Pending updates", "Delivery deviates without approval"),
    "dependencies": ("Commitments confirmed", "One dependency at risk", "Blocked with no plan"),
    "raid": ("Mitigations active", "Incomplete owners/dates", "Critical risk without response"),
    "requirements": ("Coverage known", "Minor gaps", "Critical orphan requirements"),
    "operations": ("Readiness plan active", "Late work", "No owner or no acceptance"),
}
RAG_WORD = {"green": "Green", "amber": "Amber", "red": "Red"}


def health_rows(ctx: ExportContext) -> list[list[Any]]:
    rows = []
    health = {h.key: h for h in ctx.view.health} if (ctx.filled and ctx.view) else {}
    for key, label in CONTROLS:
        g, a, r = HEALTH_CRITERIA[key]
        h = health.get(key)
        if h is not None:
            reason = "\n".join(f"{x.rule_id} {x.entity_code}: {x.message}" for x in h.reasons) or ctx.t(
                "no_findings"
            )
            action = "\n".join(dict.fromkeys(x.suggested_action for x in h.reasons))
            rag = RAG_WORD.get(h.rag, "")
        else:
            reason, action, rag = "", "", ""
        rows.append([label, rag, g, a, r, reason, action])
    return rows


def build_t12_xlsx(ctx: ExportContext) -> bytes:
    wb, st = new_workbook()
    write_cover(wb, st, ctx, ctx.t("health"))
    lists = Lists(wb)
    lists.add("L_RAG", ["Green", "Amber", "Red"])
    ws = wb.create_sheet(sheet_title(ctx.t("health")), index=len(wb.sheetnames) - 1)
    cols = [
        XCol("Control", 20),
        XCol("RAG", 10, list_name="L_RAG", center=True),
        XCol("Green when", 22),
        XCol("Amber when", 22),
        XCol("Red when", 26),
        XCol("Reason", 60),
        XCol("Next action", 44),
    ]
    title = ctx.t("health").upper()
    if ctx.filled and ctx.program is not None:
        title += f" · {ctx.program.name} · {ctx.today:%d %b %Y}"
    write_banner(ws, st, title, len(cols))
    write_table(ws, st, ctx, cols, health_rows(ctx), lists, example=False)
    first, last = FIRST_DATA_ROW, FIRST_DATA_ROW + 6
    for word, color, font in (
        ("Green", st.green, "FFFFFF"),
        ("Amber", st.amber, "000000"),
        ("Red", st.red, "FFFFFF"),
    ):
        ws.conditional_formatting.add(
            f"B{first}:B{last}",
            CellIsRule(
                operator="equal",
                formula=[f'"{word}"'],
                fill=st.fill(color),
                font=st.font(bold=True, color=font),
            ),
        )
    for col, color in (("C", st.green), ("D", st.amber), ("E", st.red)):
        ws[f"{col}{HEADER_ROW}"].fill = st.fill(color)
    ws.auto_filter.ref = None

    # Hallazgos de las reglas
    fs = wb.create_sheet(sheet_title(ctx.t("Findings")), index=len(wb.sheetnames) - 1)
    fcols = [
        XCol("RAG", 9, center=True),
        XCol("Rule", 10, center=True),
        XCol("Item", 14),
        XCol("Control", 18),
        XCol("Finding", 60),
        XCol("Suggested action", 56),
    ]
    write_banner(fs, st, ctx.t("Findings").upper(), len(fcols))
    labels = dict(CONTROLS)
    frows = [
        [RAG_WORD[r.severity], r.rule_id, r.entity_code, labels[r.control], r.message, r.suggested_action]
        for r in (ctx.view.results if ctx.filled and ctx.view else [])
    ]
    write_table(fs, st, ctx, fcols, frows, lists)
    for word, color in (("Amber", st.amber), ("Red", st.red)):
        fs.conditional_formatting.add(
            f"A{FIRST_DATA_ROW}:A{HEADER_ROW + MAX_ROWS}",
            CellIsRule(operator="equal", formula=[f'"{word}"'], fill=st.fill(color), font=st.font(bold=True)),
        )
    add_banding(fs, st, len(fcols))
    wb.active = 1
    out = BytesIO()
    wb.save(out)
    return out.getvalue()
