"""Base de las plantillas Word (python-docx) con el estilo Dell Delivery de branding.yaml."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import date
from io import BytesIO
from typing import Any

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

from app.services.exports.base import ExportContext, Style, logo_path


def _rgb(hex6: str) -> RGBColor:
    return RGBColor.from_string(hex6)


def shade(element: Any, color: str) -> None:
    """Sombreado de celda (w:tcPr) o de párrafo (w:pPr)."""
    props = element.get_or_add_tcPr() if hasattr(element, "get_or_add_tcPr") else element.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), color)
    props.append(shd)


def _plain_font(style: Any, name: str) -> None:
    """Fija la fuente del estilo y quita las referencias a fuentes del tema (si no, Word usa Calibri Light)."""
    rfonts = style.element.rPr.rFonts
    for attr in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
        key = qn(attr)
        if key in rfonts.attrib:
            del rfonts.attrib[key]
    for attr in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
        rfonts.set(qn(attr), name)


class Doc:
    def __init__(self, ctx: ExportContext, landscape: bool = False) -> None:
        self.ctx = ctx
        self.st = Style()
        self.doc = Document()
        self.doc.core_properties.author = "EA Delivery Hub"
        section = self.doc.sections[0]
        section.page_height, section.page_width = Cm(29.7), Cm(21.0)
        if landscape:
            section.orientation = WD_ORIENT.LANDSCAPE
            section.page_width, section.page_height = section.page_height, section.page_width
        for side in ("left_margin", "right_margin"):
            setattr(section, side, Cm(2.0))
        section.top_margin, section.bottom_margin = Cm(1.8), Cm(1.8)
        normal = self.doc.styles["Normal"]
        normal.font.name = self.st.font_name
        normal.font.size = Pt(10)
        normal.element.rPr.rFonts.set(qn("w:eastAsia"), self.st.font_name)
        for lvl, size, color in (
            (1, 15, self.st.blue),
            (2, 12, self.st.header_dark),
            (3, 11, self.st.header_dark),
        ):
            h = self.doc.styles[f"Heading {lvl}"]
            h.font.name = self.st.font_name
            h.font.size = Pt(size)
            h.font.bold = True
            h.font.color.rgb = _rgb(color)
            _plain_font(h, self.st.font_name)
        self._header_footer()

    def _header_footer(self) -> None:
        section = self.doc.sections[0]
        hp = section.header.paragraphs[0]
        hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        run = hp.add_run(self.st.classification)
        run.font.size = Pt(8)
        run.font.italic = True
        run.font.color.rgb = _rgb(self.st.grey)
        fp = section.footer.paragraphs[0]
        fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = fp.add_run(f"{self.st.classification} · EA Delivery Hub · page ")
        r.font.size = Pt(8)
        self._field(fp, "PAGE")

    @staticmethod
    def _field(paragraph: Any, code: str) -> None:
        run = paragraph.add_run()
        for tag, text in (("begin", None), (None, code), ("end", None)):
            if tag:
                el = OxmlElement("w:fldChar")
                el.set(qn("w:fldCharType"), tag)
            else:
                el = OxmlElement("w:instrText")
                el.set(qn("xml:space"), "preserve")
                el.text = text
            run._r.append(el)
        run.font.size = Pt(8)

    # -------------------------------------------------------------- bloques

    def cover(self, title: str, subtitle: str = "", status: str | None = None) -> None:
        """Título en banda navy, banda negra de metodología y tabla de control del documento."""
        st, ctx = self.st, self.ctx
        logo = logo_path()
        if logo is not None:
            self.doc.add_picture(str(logo), height=Cm(1.2))
        t = self.doc.add_table(rows=1, cols=1)
        cell = t.cell(0, 0)
        shade(cell._tc, st.navy)
        p = cell.paragraphs[0]
        run = p.add_run(title)
        run.font.size = Pt(22)
        run.font.color.rgb = _rgb(st.title_on_dark)
        if subtitle:
            sp = cell.add_paragraph()
            sr = sp.add_run(subtitle)
            sr.font.size = Pt(11)
            sr.font.color.rgb = _rgb("FFFFFF")
        if st.methodology:
            band = self.doc.add_paragraph()
            band.alignment = WD_ALIGN_PARAGRAPH.CENTER
            shade(band._p, st.banner)
            br = band.add_run(st.methodology)
            br.font.size = Pt(8)
            br.font.italic = True
            br.font.bold = True
            br.font.color.rgb = _rgb("FFFFFF")
        prog = ctx.program if ctx.filled else None
        rows = [
            (ctx.t("program"), prog.name if prog else "<Program name>"),
            (ctx.t("customer"), prog.client if prog else "<Customer>"),
            (ctx.t("version"), ctx.version),
            (ctx.t("date"), f"{ctx.today:%d %b %Y}"),
            (ctx.t("owner"), (prog.ea or prog.pm) if prog else "<Enterprise Architect>"),
            (ctx.t("status"), status or ctx.t("draft")),
            (ctx.t("classification"), st.classification),
        ]
        self.kv_table(rows)
        self.doc.add_paragraph()

    def kv_table(self, rows: Sequence[tuple[str, Any]], key_width: float = 4.5) -> Any:
        t = self.doc.add_table(rows=0, cols=2)
        t.style = "Table Grid"
        t.alignment = WD_TABLE_ALIGNMENT.LEFT
        for k, v in rows:
            cells = t.add_row().cells
            shade(cells[0]._tc, self.st.blue)
            kr = cells[0].paragraphs[0].add_run(str(k))
            kr.font.bold = True
            kr.font.color.rgb = _rgb("FFFFFF")
            self._write(cells[1], v)
        for row in t.rows:
            row.cells[0].width = Cm(key_width)
            row.cells[1].width = Cm(17 - key_width)
        return t

    def table(
        self,
        header: Sequence[str],
        rows: Sequence[Sequence[Any]],
        widths: Sequence[float] | None = None,
        example: bool = False,
        fills: dict[tuple[int, int], str] | None = None,
    ) -> Any:
        """Cabecera azul Dell con texto blanco y filas alternas azul claro (patrón de las capturas)."""
        t = self.doc.add_table(rows=1, cols=len(header))
        t.style = "Table Grid"
        for j, h in enumerate(header):
            c = t.rows[0].cells[j]
            shade(c._tc, self.st.blue)
            r = c.paragraphs[0].add_run(str(h))
            r.font.bold = True
            r.font.size = Pt(9)
            r.font.color.rgb = _rgb("FFFFFF")
        self._repeat_header(t.rows[0])
        for i, values in enumerate(rows):
            cells = t.add_row().cells
            for j, v in enumerate(values):
                color = (fills or {}).get((i, j))
                if color:
                    shade(cells[j]._tc, color)
                elif i % 2 == 1:
                    shade(cells[j]._tc, self.st.row_alt)
                self._write(
                    cells[j],
                    v,
                    size=9,
                    italic=example,
                    color=self.st.grey if example else None,
                    bold=bool(color),
                )
        if widths:
            for row in t.rows:
                for j, w in enumerate(widths):
                    row.cells[j].width = Cm(w)
        self.doc.add_paragraph()
        return t

    @staticmethod
    def _repeat_header(row: Any) -> None:
        tr_pr = row._tr.get_or_add_trPr()
        el = OxmlElement("w:tblHeader")
        el.set(qn("w:val"), "true")
        tr_pr.append(el)

    def _write(
        self,
        cell: Any,
        value: Any,
        size: int = 10,
        italic: bool = False,
        color: str | None = None,
        bold: bool = False,
    ) -> None:
        text = (
            value.strftime("%d %b %Y") if isinstance(value, date) else ("" if value is None else str(value))
        )
        lines = text.split("\n")
        p = cell.paragraphs[0]
        for k, line in enumerate(lines):
            if k:
                p = cell.add_paragraph()
            r = p.add_run(line)
            r.font.size = Pt(size)
            r.font.italic = italic
            r.font.bold = bold
            if color:
                r.font.color.rgb = _rgb(color)

    def heading(self, text: str, level: int = 1) -> None:
        self.doc.add_heading(text, level=level)

    def para(self, text: str, italic: bool = False, size: int | None = None, color: str | None = None) -> Any:
        p = self.doc.add_paragraph()
        for k, line in enumerate((text or "").split("\n")):
            if k:
                p.add_run().add_break()
            r = p.add_run(line)
            r.font.italic = italic
            if size:
                r.font.size = Pt(size)
            if color:
                r.font.color.rgb = _rgb(color)
        return p

    def bullets(self, items: Sequence[str]) -> None:
        for it in items:
            self.doc.add_paragraph(it, style="List Bullet")

    def example(self, text: str) -> None:
        """Texto de ejemplo de la plantilla vacía (gris cursiva)."""
        self.para(text, italic=True, color=self.st.grey)

    def save(self) -> bytes:
        out = BytesIO()
        self.doc.save(out)
        return out.getvalue()
