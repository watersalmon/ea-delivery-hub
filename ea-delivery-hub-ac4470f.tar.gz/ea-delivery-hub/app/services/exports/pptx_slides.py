"""T16 · Diapositiva de artefacto para el status meeting y T12 · Weekly Health Check (1 slide), en PPTX.

Patrón de las capturas: fondo navy en degradado, título azul claro, bloque Purpose / Process /
Additional Information con borde blanco, banda negra de metodología y tabla resumen estilo hoja Dell.
"""

from __future__ import annotations

from io import BytesIO
from typing import Any

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

from app.content.artifacts import ARTIFACTS, ArtifactDefinition
from app.models.enums import RAIDType
from app.services.exports.base import ExportContext, Style, logo_path
from app.services.fields import rag_for_score, us_date

SLIDE_W, SLIDE_H = Inches(13.333), Inches(7.5)
MARGIN = Inches(0.45)


def rgb(hex6: str) -> RGBColor:
    return RGBColor.from_string(hex6)


class Deck:
    def __init__(self) -> None:
        self.st = Style()
        self.prs = Presentation()
        self.prs.slide_width, self.prs.slide_height = SLIDE_W, SLIDE_H
        self.prs.core_properties.author = "EA Delivery Hub"

    def slide(self, title: str, subtitle: str = "") -> Any:
        st = self.st
        s = self.prs.slides.add_slide(self.prs.slide_layouts[6])  # en blanco
        bg = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, SLIDE_W, SLIDE_H)
        bg.line.fill.background()
        bg.fill.gradient()
        bg.fill.gradient_angle = 90
        stops = bg.fill.gradient_stops
        stops[0].color.rgb, stops[0].position = rgb(st.navy), 0.0
        stops[1].color.rgb, stops[1].position = rgb(st.navy_700), 1.0
        self.text(s, title, MARGIN, Inches(0.25), Inches(10.5), Inches(0.7), size=30, color=st.title_on_dark)
        if subtitle:
            self.text(s, subtitle, MARGIN, Inches(0.85), Inches(10.5), Inches(0.35), size=12, color="FFFFFF")
        logo = logo_path()
        if logo is not None:
            s.shapes.add_picture(str(logo), SLIDE_W - Inches(1.9), Inches(0.3), height=Inches(0.5))
        self.text(
            s,
            st.classification,
            MARGIN,
            SLIDE_H - Inches(0.35),
            Inches(6),
            Inches(0.25),
            size=8,
            color=st.tint(st.title_on_dark, 0.6),
        )
        return s

    def text(
        self,
        slide: Any,
        text: str,
        x: int,
        y: int,
        w: int,
        h: int,
        size: int = 12,
        color: str = "FFFFFF",
        bold: bool = False,
        italic: bool = False,
        align: Any = PP_ALIGN.LEFT,
    ) -> Any:
        box = slide.shapes.add_textbox(x, y, w, h)
        tf = box.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.alignment = align
        run = p.add_run()
        run.text = text
        self._font(run.font, size, color, bold, italic)
        return box

    def _font(self, font: Any, size: int, color: str, bold: bool = False, italic: bool = False) -> None:
        font.name = self.st.font_name
        font.size = Pt(size)
        font.bold = bold
        font.italic = italic
        font.color.rgb = rgb(color)

    def definition_block(
        self, slide: Any, defn: ArtifactDefinition, ctx: ExportContext, y: int, h: int
    ) -> None:
        """Bloque Purpose / Process / Additional Information (patrón obligatorio §4.2.1)."""
        width = (SLIDE_W - 2 * MARGIN) / 3
        blocks = [
            (ctx.t("purpose"), [defn.purpose], False),
            (ctx.t("process"), defn.process, True),
            (ctx.t("additional"), defn.additional, False),
        ]
        for k, (heading, lines, numbered) in enumerate(blocks):
            box = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, int(MARGIN + k * width), y, int(width), h)
            box.fill.background()
            box.line.color.rgb = rgb("FFFFFF")
            box.line.width = Pt(1)
            tf = box.text_frame
            tf.word_wrap = True
            tf.vertical_anchor = MSO_ANCHOR.TOP
            tf.margin_left = tf.margin_right = Inches(0.12)
            p = tf.paragraphs[0]
            run = p.add_run()
            run.text = heading + ":"
            self._font(run.font, 14, "FFFFFF", bold=True)
            run.font.underline = True
            for n, line in enumerate(lines, start=1):
                para = tf.add_paragraph()
                r = para.add_run()
                prefix = f"{n}. " if numbered else ("• " if len(lines) > 1 else "")
                r.text = prefix + line
                self._font(r.font, 11, "FFFFFF")

    def banner(self, slide: Any, y: int) -> None:
        st = self.st
        if not st.methodology:
            return
        band = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, MARGIN, y, SLIDE_W - 2 * MARGIN, Inches(0.24))
        band.fill.solid()
        band.fill.fore_color.rgb = rgb(st.banner)
        band.line.fill.background()
        tf = band.text_frame
        tf.margin_top = tf.margin_bottom = 0
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        run = p.add_run()
        run.text = st.methodology
        self._font(run.font, 9, "FFFFFF", bold=True, italic=True)

    def table(
        self,
        slide: Any,
        header: list[str],
        rows: list[list[Any]],
        y: int,
        widths: list[float],
        example: bool = False,
        fills: dict[tuple[int, int], str] | None = None,
    ) -> None:
        st = self.st
        n_rows = max(len(rows), 1) + 1
        total = sum(widths)
        tbl_w = SLIDE_W - 2 * MARGIN
        shape = slide.shapes.add_table(n_rows, len(header), MARGIN, y, tbl_w, Inches(0.3) * n_rows)
        tbl = shape.table
        for j, w in enumerate(widths):
            tbl.columns[j].width = int(tbl_w * w / total)
        for j, label in enumerate(header):
            cell = tbl.cell(0, j)
            cell.fill.solid()
            cell.fill.fore_color.rgb = rgb(st.blue)
            self._cell_text(cell, label, 10, "FFFFFF", bold=True, align=PP_ALIGN.CENTER)
        for i, values in enumerate(rows or [[""] * len(header)], start=1):
            for j, value in enumerate(values):
                cell = tbl.cell(i, j)
                cell.fill.solid()
                color = (fills or {}).get((i - 1, j))
                cell.fill.fore_color.rgb = rgb(color or (st.row_alt if i % 2 == 0 else "FFFFFF"))
                txt_color = "FFFFFF" if color else (st.grey if example else "000000")
                self._cell_text(
                    cell, "" if value is None else str(value), 9, txt_color, italic=example, bold=bool(color)
                )

    def _cell_text(
        self,
        cell: Any,
        text: str,
        size: int,
        color: str,
        bold: bool = False,
        italic: bool = False,
        align: Any = PP_ALIGN.LEFT,
    ) -> None:
        cell.margin_left = cell.margin_right = Inches(0.05)
        cell.margin_top = cell.margin_bottom = Inches(0.02)
        tf = cell.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.alignment = align
        run = p.add_run()
        run.text = text
        self._font(run.font, size, color, bold, italic)

    def save(self) -> bytes:
        out = BytesIO()
        self.prs.save(out)
        return out.getvalue()


# ------------------------------------------------------------------ contenido por artefacto


def _rag_color(st: Style, rag: str) -> str | None:
    return {"red": st.red, "amber": st.amber, "green": st.green}.get(rag)


def _summary(
    ctx: ExportContext, st: Style, artifact: str
) -> tuple[list[str], list[list[Any]], list[float], dict[tuple[int, int], str]]:
    fills: dict[tuple[int, int], str] = {}
    rows: list[list[Any]]
    v = ctx.view if ctx.filled else None
    if artifact == "raid":
        header = ["ID", "Risk Title", "Owner", "P", "I", "Score", "Due Date", "Monitor Status"]
        widths = [0.8, 4.5, 1.8, 0.4, 0.4, 0.7, 1.1, 1.5]
        if v:
            risks = sorted(
                (r for r in v.ctx.raid_items if r.type == RAIDType.RISK and not r.is_closed),
                key=lambda r: -(r.score or 0),
            )[:8]
            rows = [
                [
                    r.code,
                    r.title,
                    r.owner or "— (no owner)",
                    r.probability,
                    r.impact,
                    r.score,
                    us_date(r.due_date),
                    r.monitor_status,
                ]
                for r in risks
            ]
            for i, r in enumerate(risks):
                color = _rag_color(st, rag_for_score(r.score, v.ctx.settings))
                if color:
                    fills[(i, 5)] = color
        else:
            rows = [
                [
                    "RK-001",
                    "Data centre power readiness",
                    "Facilities manager",
                    3,
                    3,
                    9,
                    "",
                    "Action Required",
                ],
                ["RK-002", "Extended hardware lead time", "Compute lead", 2, 2, 4, "", "Monitoring"],
            ]
        return header, rows, widths, fills
    if artifact == "goals":
        header = ["Goal ID", "Obj ID", "Objective", "Acceptance Criteria", "Completion Status", "Approver"]
        widths = [0.9, 0.8, 4.6, 3.0, 1.4, 1.5]
        from app.services.exports.t03_t05_trace import _sdm_data

        rows = [[g, o[0], o[1], o[2], o[3], o[4]] for g, _t, objs in _sdm_data(ctx) for o in objs][:10]
        return header, rows, widths, fills
    if artifact == "rtm":
        header = ["Measure", "Value", "Orphan requirements (RTM-01)"]
        widths = [3.0, 1.0, 7.0]
        if v and ctx.session is not None:
            from app.routers.traceability import build_trace, coverage

            trace = build_trace(ctx.session, v)
            cov = coverage(trace)
            orphans = [
                f"{r.req.code} {r.req.statement}"
                for r in trace
                if any(i.rule_id == "RTM-01" for i in r.issues)
            ]
            rows = [
                ["Requirements", cov["total"], orphans[0] if orphans else "None"],
                [
                    "Traced to outcome / objective",
                    f"{cov['upstream']}%",
                    orphans[1] if len(orphans) > 1 else "",
                ],
                ["Traced to architecture", f"{cov['design']}%", orphans[2] if len(orphans) > 2 else ""],
                ["With test / evidence", f"{cov['evidence']}%", ""],
                ["Traced end to end", f"{cov['e2e']}%", ""],
            ]
            e2e = cov["e2e"]
            fills[(4, 1)] = st.green if e2e >= 90 else (st.amber if e2e >= 60 else st.red)
        else:
            rows = [["Requirements", 0, ""], ["Traced end to end", "0%", ""]]
        return header, rows, widths, fills
    if artifact == "raci":
        from app.services.exports.t06_t12_xlsx import _raci_matrix

        roles, acts = _raci_matrix(ctx)
        header = ["Activity / deliverable", *roles]
        widths = [4.5] + [1.6] * len(roles)
        rows = [[name, *(f"{val} ({q})" if q else val for val, q in cells)] for name, cells in acts][:10]
        return header, rows, widths, fills
    raise KeyError(artifact)


T16_ARTIFACTS = {"raid": "raid", "goals": "goals", "rtm": "rtm", "raci": "raci"}


def build_t16(ctx: ExportContext, artifact: str) -> bytes:
    if artifact not in T16_ARTIFACTS:
        raise KeyError(artifact)
    deck = Deck()
    defn = ARTIFACTS[T16_ARTIFACTS[artifact]]
    subtitle = (
        f"{ctx.program.name} · {ctx.program.client} · {ctx.today:%d %b %Y}"
        if ctx.filled and ctx.program
        else "<Program> · <Customer> · <Date>"
    )
    s = deck.slide(defn.title, subtitle)
    deck.definition_block(s, defn, ctx, Inches(1.35), Inches(1.75))
    deck.banner(s, Inches(3.3))
    header, rows, widths, fills = _summary(ctx, deck.st, artifact)
    deck.table(s, header, rows, Inches(3.6), widths, example=not ctx.filled, fills=fills)
    return deck.save()


def build_t12_pptx(ctx: ExportContext) -> bytes:
    from app.services.exports.t06_t12_xlsx import health_rows

    deck = Deck()
    st = deck.st
    subtitle = (
        f"{ctx.program.name} · {ctx.today:%d %b %Y}" if ctx.filled and ctx.program else "<Program> · <Date>"
    )
    if ctx.filled and ctx.view is not None:
        phase = ctx.view.program.phase
        subtitle += (
            f" · {ctx.t('overall')}: {ctx.view.rag.upper()} · Phase {phase} · Gate {ctx.view.active_gate}"
        )
    s = deck.slide(ctx.t("health"), subtitle)
    rows = health_rows(ctx)
    table_rows, fills = [], {}
    for i, (label, rag, _g, _a, _r, reason, action) in enumerate(rows):
        first_reasons = "\n".join(reason.split("\n")[:2])
        table_rows.append([label, rag, first_reasons, action.split("\n")[0] if action else ""])
        color = _rag_color(st, rag.lower())
        if color:
            fills[(i, 1)] = color
    deck.banner(s, Inches(1.35))
    deck.table(
        s,
        [ctx.t("Control"), ctx.t("RAG"), ctx.t("Reason"), ctx.t("Next action")],
        table_rows,
        Inches(1.65),
        [1.8, 0.8, 6.2, 3.6],
        example=not ctx.filled,
        fills=fills,
    )
    return deck.save()
