"""`make export-all`: genera las plantillas disponibles, vacías y rellenas por programa, en EXPORTS_DIR."""

from __future__ import annotations

import sys
from pathlib import Path

from sqlmodel import Session, select

from app.config import get_settings
from app.db import get_engine, init_db
from app.models import Program
from app.services.exports.base import filename, make_context
from app.services.exports.registry import TEMPLATES


def export_all(session: Session, out_dir: Path, lang: str | None = None) -> list[Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    targets: list[tuple[Program | None, str]] = [(None, "blank")]
    targets += [(p, "filled") for p in session.exec(select(Program).order_by(Program.id)).all()]  # type: ignore[arg-type]
    for program, mode in targets:
        ctx = make_context(session, program, mode, lang)
        sub = out_dir / ("blank" if mode == "blank" else (program.code if program else "blank"))
        sub.mkdir(parents=True, exist_ok=True)
        for tpl in TEMPLATES.values():
            path = sub / filename(ctx, tpl.artifact, tpl.fmt)
            path.write_bytes(tpl.build(ctx))
            written.append(path)
    return written


def main() -> None:
    init_db()
    lang = sys.argv[1] if len(sys.argv) > 1 else None
    with Session(get_engine()) as session:
        files = export_all(session, get_settings().exports_dir, lang)
    for f in files:
        print(f)
    print(f"{len(files)} files written")


if __name__ == "__main__":
    main()
