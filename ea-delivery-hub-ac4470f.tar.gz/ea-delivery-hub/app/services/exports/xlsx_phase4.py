"""Plantillas Excel de la Fase 4: T08 Decision Log, T10 HLD/LLD Review Checklist, T11 Roadmap y T15 Primeros 10 días."""

from __future__ import annotations

from datetime import timedelta
from io import BytesIO
from typing import Any

from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter
from sqlmodel import col, select

from app.content.guide import (
    ESCALATION_LEVELS,
    HLD_QUESTIONS,
    LLD_QUESTIONS,
    REVIEW_ANSWERS,
    TEN_DAY_QUESTIONS,
    TEN_DAYS,
)
from app.models import ChecklistItem, DesignReview, ReviewItem, WorkPackage, Workstream
from app.models.enums import ADRStatus
from app.services.exports.base import (
    FIRST_DATA_ROW,
    HEADER_ROW,
    MAX_ROWS,
    ExportContext,
    Lists,
    XCol,
    add_banding,
    new_workbook,
    sheet_title,
    write_banner,
    write_cover,
    write_table,
)


def _save(wb: Any) -> bytes:
    out = BytesIO()
    wb.save(out)
    return out.getvalue()


# ------------------------------------------------------------------ T08 Decision Log


def build_t08_log(ctx: ExportContext) -> bytes:
    wb, st = new_workbook()
    write_cover(wb, st, ctx, "Decision Log (ADR)")
    lists = Lists(wb)
    lists.add("L_ADRStatus", [s.value for s in ADRStatus])
    lists.add("L_Level", [lv for lv, _e, _f in ESCALATION_LEVELS])
    lists.add("L_YesNo", ["Yes", "No"])
    ws = wb.create_sheet("Decision Log", index=len(wb.sheetnames) - 1)
    cols = [
        XCol("ID", 10, wrap=False, center=True),
        XCol("Decision", 40),
        XCol("Status", 13, list_name="L_ADRStatus", center=True),
        XCol("Level", 13, list_name="L_Level", center=True),
        XCol("Critical path", 9, list_name="L_YesNo", center=True),
        XCol("Owner", 18),
        XCol("Due Date", 12, number_format="m/d/yyyy", center=True),
        XCol("Submitted", 12, number_format="m/d/yyyy", center=True),
        XCol("Approved", 12, number_format="m/d/yyyy", center=True),
        XCol("Rationale", 40),
        XCol("Impacted artifacts", 30),
        XCol("Days open", 9, center=True),
    ]
    write_banner(ws, st, "DECISION LOG", len(cols))
    if ctx.filled and ctx.view is not None:
        rows: list[list[Any]] = [
            [
                a.code,
                a.title,
                a.status,
                a.escalation_level,
                "Yes" if a.critical_path else "No",
                a.owner,
                a.due_date,
                a.submitted_at,
                a.approved_at,
                a.rationale,
                a.impacted_artifacts,
                None,
            ]
            for a in sorted(ctx.view.ctx.adrs, key=lambda a: a.code)
        ]
    else:
        rows = [
            [
                "ADR-001",
                "Use immutable object storage as backup target",
                "Approved",
                "Architecture",
                "Yes",
                "Data protection lead",
                ctx.today,
                ctx.today - timedelta(days=14),
                ctx.today - timedelta(days=2),
                "Best balance of cost and immutability",
                "HLD §5, runbooks",
                None,
            ]
        ]
    write_table(ws, st, ctx, cols, rows, lists, example=not ctx.filled)
    first, last = FIRST_DATA_ROW, HEADER_ROW + MAX_ROWS
    sla = ctx.view.ctx.settings.decision_sla_days if (ctx.filled and ctx.view) else 10
    for r in range(first, last + 1):
        ws[f"L{r}"] = (
            f'=IF(OR($A{r}="",$H{r}=""),"",IF(OR($C{r}="Proposed",$C{r}="Under Review"),TODAY()-$H{r},""))'
        )
        ws[f"L{r}"].alignment = Alignment(horizontal="center")
        ws[f"L{r}"].font = st.font()
    # ADR-01: ruta crítica sin owner o sin fecha; ADR-02: fuera de SLA
    open_status = f'OR($C{first}="Proposed",$C{first}="Under Review",$C{first}="Deferred")'
    ws.conditional_formatting.add(
        f"F{first}:G{last}",
        FormulaRule(
            formula=[
                f'AND($A{first}<>"",$E{first}="Yes",{open_status},OR(LEN(TRIM($F{first}))=0,$G{first}=""))'
            ],
            fill=st.fill(st.red),
            font=st.font(bold=True, color="FFFFFF"),
        ),
    )
    ws.conditional_formatting.add(
        f"L{first}:L{last}",
        CellIsRule(
            operator="greaterThan", formula=[str(sla)], fill=st.fill(st.amber), font=st.font(bold=True)
        ),
    )
    colors = {"Approved": st.green, "Rejected": st.red, "Deferred": st.amber, "Superseded": st.grey}
    for status, color in colors.items():
        ws.conditional_formatting.add(
            f"C{first}:C{last}",
            CellIsRule(operator="equal", formula=[f'"{status}"'], font=st.font(bold=True, color=color)),
        )
    add_banding(ws, st, len(cols))
    wb.active = 1
    return _save(wb)


# ------------------------------------------------------------------ T10 HLD / LLD Review Checklist


def build_t10(ctx: ExportContext) -> bytes:
    wb, st = new_workbook()
    write_cover(wb, st, ctx, "HLD / LLD Review Checklist")
    lists = Lists(wb)
    lists.add("L_Answer", REVIEW_ANSWERS)
    lists.add("L_YesNo", ["Yes", "No"])
    reviews: list[tuple[DesignReview | None, str]] = [(None, "HLD"), (None, "LLD")]
    answers: dict[tuple[int, int], ReviewItem] = {}
    if ctx.filled and ctx.session is not None and ctx.program is not None:
        found = ctx.session.exec(
            select(DesignReview)
            .where(DesignReview.program_id == ctx.program.id)
            .order_by(col(DesignReview.id))
        ).all()
        if found:
            reviews = [(r, r.doc_type) for r in found]
            for found_item in ctx.session.exec(
                select(ReviewItem).where(ReviewItem.program_id == ctx.program.id)
            ).all():
                answers[(found_item.review_id, found_item.question_key)] = found_item
    used: set[str] = set()
    for review, doc_type in reviews:
        name = f"{doc_type} {review.title}" if review else f"{doc_type} review"
        title = sheet_title(name)
        while title in used:
            title = sheet_title(f"{title[:28]} {len(used)}")
        used.add(title)
        ws = wb.create_sheet(title, index=len(wb.sheetnames) - 1)
        cols = [
            XCol("#", 5, center=True),
            XCol("Question", 60),
            XCol("Answer", 12, list_name="L_Answer", center=True),
            XCol("Comment", 44),
            XCol("Deviation", 10, list_name="L_YesNo", center=True),
            XCol("ADR / Change", 14, center=True),
        ]
        header = f"{doc_type} REVIEW" + (f" · {review.title} v{review.doc_version}" if review else "")
        write_banner(ws, st, header, len(cols))
        qs = HLD_QUESTIONS if doc_type == "HLD" else LLD_QUESTIONS
        rows = []
        for i, q in enumerate(qs):
            it: ReviewItem | None = answers.get((review.id or 0, i)) if review else None
            rows.append(
                [
                    i + 1,
                    q,
                    it.answer if it else "",
                    it.comment if it else "",
                    ("Yes" if it.deviation else "No") if it else "",
                    "",
                ]
            )
        write_table(ws, st, ctx, cols, rows, lists)
        first, last = FIRST_DATA_ROW, FIRST_DATA_ROW + len(qs) - 1
        for word, color in (("Yes", st.green), ("Partial", st.amber), ("No", st.red)):
            ws.conditional_formatting.add(
                f"C{first}:C{last}",
                CellIsRule(
                    operator="equal",
                    formula=[f'"{word}"'],
                    fill=st.fill(color),
                    font=st.font(bold=True, color="FFFFFF"),
                ),
            )
        ws.conditional_formatting.add(
            f"E{first}:E{last}",
            CellIsRule(
                operator="equal",
                formula=['"Yes"'],
                fill=st.fill(st.red),
                font=st.font(bold=True, color="FFFFFF"),
            ),
        )
        # % de preguntas respondidas "Yes" (fórmula viva)
        ws.cell(row=last + 2, column=2, value="Compliance (Yes / answered)").font = st.font(bold=True)
        c = ws.cell(
            row=last + 2,
            column=3,
            value=f'=IF(COUNTA(C{first}:C{last})=0,"",COUNTIF(C{first}:C{last},"Yes")/COUNTA(C{first}:C{last}))',
        )
        c.number_format = "0%"
        c.font = st.font(bold=True)
        ws.auto_filter.ref = f"A{HEADER_ROW}:F{last}"
        add_banding(ws, st, len(cols))
    wb.active = 1
    return _save(wb)


# ------------------------------------------------------------------ T11 Architecture Roadmap


def build_t11(ctx: ExportContext) -> bytes:
    wb, st = new_workbook()
    write_cover(wb, st, ctx, "Architecture Roadmap")
    lists = Lists(wb)
    lists.add("L_WPStatus", ["Planned", "In Progress", "Done", "At Risk"])
    lists.add("L_YesNo", ["Yes", "No"])
    lists.add("L_Gate", [f"G{n}" for n in range(7)])
    ws = wb.create_sheet("Roadmap", index=len(wb.sheetnames) - 1)
    if ctx.filled and ctx.session is not None and ctx.program is not None:
        wps = list(
            ctx.session.exec(
                select(WorkPackage)
                .where(WorkPackage.program_id == ctx.program.id)
                .order_by(col(WorkPackage.start))
            ).all()
        )
        wsn = {
            w.id: w.name
            for w in ctx.session.exec(select(Workstream).where(Workstream.program_id == ctx.program.id)).all()
        }
        rows: list[list[Any]] = [
            [
                w.code,
                w.name,
                wsn.get(w.workstream_id, ""),
                w.start,
                w.end,
                "Yes" if w.milestone else "No",
                w.transition_state,
                w.depends_on,
                w.gate_code,
                w.status,
            ]
            for w in wps
        ]
        dates = [d for w in wps for d in (w.start, w.end) if d]
    else:
        s = ctx.today
        rows = [
            [
                "WP-001",
                "Landing zone and management cluster",
                "Compute & Storage",
                s,
                s + timedelta(days=45),
                "No",
                "TS1 · Foundation",
                "",
                "G4",
                "Planned",
            ],
            [
                "WP-002",
                "Go-live IaaS",
                "Compute & Storage",
                s + timedelta(days=60),
                s + timedelta(days=60),
                "Yes",
                "TS2 · IaaS live",
                "WP-001",
                "G5",
                "Planned",
            ],
        ]
        dates = [s, s + timedelta(days=60)]
    cols = [
        XCol("ID", 9, wrap=False, center=True),
        XCol("Work package", 36),
        XCol("Workstream", 20),
        XCol("Start", 11, number_format="m/d/yyyy", center=True),
        XCol("End", 11, number_format="m/d/yyyy", center=True),
        XCol("Milestone", 9, list_name="L_YesNo", center=True),
        XCol("Transition state", 20),
        XCol("Depends on", 12),
        XCol("Gate", 7, list_name="L_Gate", center=True),
        XCol("Status", 12, list_name="L_WPStatus", center=True),
    ]
    write_banner(ws, st, "ARCHITECTURE ROADMAP", len(cols) + 12)
    write_table(ws, st, ctx, cols, rows, lists, example=not ctx.filled)
    # Diagrama de Gantt por semanas con formato condicional (se recalcula al cambiar fechas)
    start = min(dates) - timedelta(days=min(dates).weekday()) if dates else ctx.today
    weeks = max(12, ((max(dates) - start).days // 7 + 2) if dates else 12)
    base_col = len(cols) + 1
    for k in range(weeks):
        c = ws.cell(row=HEADER_ROW, column=base_col + k, value=start + timedelta(weeks=k))
        c.number_format = "d-mmm"
        c.font = st.font(size=8, bold=True, color="FFFFFF")
        c.fill = st.fill(st.header_dark)
        c.alignment = Alignment(horizontal="center", text_rotation=90)
        ws.column_dimensions[get_column_letter(base_col + k)].width = 3.2
    first, last = FIRST_DATA_ROW, HEADER_ROW + MAX_ROWS
    g1, g2 = get_column_letter(base_col), get_column_letter(base_col + weeks - 1)
    rng = f"{g1}{first}:{g2}{last}"
    week = f"{g1}${HEADER_ROW}"
    ws.conditional_formatting.add(
        rng,
        FormulaRule(
            formula=[f'AND($F{first}="Yes",$D{first}>={week},$D{first}<{week}+7)'], fill=st.fill(st.navy)
        ),
    )
    ws.conditional_formatting.add(
        rng,
        FormulaRule(
            formula=[f'AND(ISNUMBER($D{first}),$J{first}="At Risk",$D{first}<{week}+7,$E{first}>={week})'],
            fill=st.fill(st.red),
        ),
    )
    ws.conditional_formatting.add(
        rng,
        FormulaRule(
            formula=[f'AND(ISNUMBER($D{first}),$J{first}="Done",$D{first}<{week}+7,$E{first}>={week})'],
            fill=st.fill(st.green),
        ),
    )
    ws.conditional_formatting.add(
        rng,
        FormulaRule(
            formula=[f"AND(ISNUMBER($D{first}),$D{first}<{week}+7,$E{first}>={week})"], fill=st.fill(st.blue)
        ),
    )
    add_banding(ws, st, len(cols))
    ws.print_area = f"A1:{g2}{HEADER_ROW + max(len(rows), 1) + 5}"  # incluye el Gantt
    wb.active = 1
    return _save(wb)


# ------------------------------------------------------------------ T15 Primeros 10 días


def build_t15(ctx: ExportContext) -> bytes:
    wb, st = new_workbook()
    write_cover(wb, st, ctx, "First 10 Days · EA Onboarding")
    lists = Lists(wb)
    lists.add("L_Done", ["Done", "In Progress", "Not Started"])
    done: dict[tuple[str, int], bool] = {}
    if ctx.filled and ctx.session is not None and ctx.program is not None:
        for c in ctx.session.exec(
            select(ChecklistItem).where(ChecklistItem.program_id == ctx.program.id)
        ).all():
            done[(c.checklist, c.item_key)] = c.checked

    ws = wb.create_sheet("Plan", index=len(wb.sheetnames) - 1)
    cols = [
        XCol("Stage", 16),
        XCol("EA action", 60),
        XCol("Exit evidence", 40),
        XCol("Status", 13, list_name="L_Done", center=True),
        XCol("Owner", 16),
        XCol("Due Date", 12, number_format="m/d/yyyy", center=True),
    ]
    write_banner(ws, st, "FIRST 10 DAYS · PLAN", len(cols))
    offsets = {"before": -3, "d1_2": 2, "d3_5": 5, "d6_7": 7, "d8_10": 10}
    start = ctx.program.start_date if (ctx.filled and ctx.program and ctx.program.start_date) else ctx.today
    rows: list[list[Any]] = []
    for si, (key, label, acts, evidence) in enumerate(TEN_DAYS):
        for ai, act in enumerate(acts):
            status = ("Done" if done.get(("ten_days", si * 10 + ai)) else "Not Started") if ctx.filled else ""
            rows.append(
                [
                    label,
                    act,
                    evidence if ai == 0 else "",
                    status,
                    ctx.program.ea if ctx.filled and ctx.program else "",
                    start + timedelta(days=offsets[key]),
                ]
            )
    write_table(ws, st, ctx, cols, rows, lists)
    first, last = FIRST_DATA_ROW, FIRST_DATA_ROW + len(rows) - 1
    for word, color in (("Done", st.green), ("In Progress", st.amber)):
        ws.conditional_formatting.add(
            f"D{first}:D{last}",
            CellIsRule(operator="equal", formula=[f'"{word}"'], fill=st.fill(color), font=st.font(bold=True)),
        )
    ws.cell(row=last + 2, column=2, value="Progress").font = st.font(bold=True)
    p = ws.cell(row=last + 2, column=4, value=f'=COUNTIF(D{first}:D{last},"Done")/ROWS(D{first}:D{last})')
    p.number_format = "0%"
    p.font = st.font(bold=True)
    add_banding(ws, st, len(cols))

    qs = wb.create_sheet("Questions", index=len(wb.sheetnames) - 1)
    qcols = [
        XCol("#", 5, center=True),
        XCol("Question (guide §3.1)", 70),
        XCol("Answered", 12, list_name="L_YesNo", center=True),
        XCol("Answer / evidence", 50),
    ]
    lists.add("L_YesNo", ["Yes", "No"])
    write_banner(qs, st, "QUESTIONS FOR DAY 10", len(qcols))
    qrows = [
        [i + 1, q, ("Yes" if done.get(("ten_days_q", i)) else "No") if ctx.filled else "", ""]
        for i, q in enumerate(TEN_DAY_QUESTIONS)
    ]
    write_table(qs, st, ctx, qcols, qrows, lists)
    f2, l2 = FIRST_DATA_ROW, FIRST_DATA_ROW + len(qrows) - 1
    qs.conditional_formatting.add(
        f"C{f2}:C{l2}",
        CellIsRule(
            operator="equal",
            formula=['"Yes"'],
            fill=st.fill(st.green),
            font=st.font(bold=True, color="FFFFFF"),
        ),
    )
    qs.conditional_formatting.add(
        f"C{f2}:C{l2}",
        CellIsRule(operator="equal", formula=['"No"'], fill=st.fill(st.amber), font=st.font(bold=True)),
    )
    add_banding(qs, st, len(qcols))
    wb.active = 1
    return _save(wb)
