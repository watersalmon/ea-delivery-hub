"""Vista calculada de un programa: reglas, salud semanal, badges y alertas (CLAUDE.md §4.3, §6)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any

from sqlmodel import Session

from app.models import RAIDItem
from app.models.enums import ADR_PENDING, PHASE_NAMES, RAG, RAIDType, Severity
from app.rules import (
    ControlHealth,
    ProgramContext,
    RuleResult,
    evaluate,
    gate_blockers,
    load_context,
    overall_rag,
    weekly_health,
)

# Pestaña del RAID Log por tipo (captura 1)
RAID_TABS: tuple[tuple[str, str, str | None], ...] = (
    ("cover", "Cover", None),
    ("risks", "Risks", RAIDType.RISK),
    ("actions", "Actions", RAIDType.ACTION),
    ("issues", "Issues", RAIDType.ISSUE),
    ("decisions", "Decisions", RAIDType.DECISION),
    ("escalation", "Escalation", RAIDType.ESCALATION),
    ("changes", "Changes", RAIDType.CHANGE),
    ("comms", "Comms", RAIDType.COMM),
    ("lessons", "Lessons Learned", RAIDType.LESSON),
)
TAB_BY_TYPE = {t: key for key, _, t in RAID_TABS if t}


def entity_url(entity_type: str, code: str, item: Any = None) -> str:
    """Enlace directo al elemento que provoca una alerta."""
    if entity_type == "raid":
        tab = TAB_BY_TYPE.get(getattr(item, "type", ""), "risks")
        return f"/raid?tab={tab}#{code}"
    if entity_type in {"requirement", "arch_element"}:
        return f"/rtm#{code}"
    if entity_type == "dependency":
        return f"/raid/dependencies#{code}"
    if entity_type == "raci_activity":
        return "/stakeholders?tab=raci"
    if entity_type == "adr":
        return f"/adr/{code}"
    if entity_type == "orr":
        return "/orr"
    return "/dashboard"


@dataclass
class Alert:
    result: RuleResult
    url: str


@dataclass
class ProgramView:
    ctx: ProgramContext
    results: list[RuleResult]
    health: list[ControlHealth]
    rag: RAG
    alerts: list[Alert] = field(default_factory=list)
    badges: dict[str, dict[str, Any]] = field(default_factory=dict)

    @property
    def program(self) -> Any:
        return self.ctx.program

    @property
    def phase_name(self) -> str:
        return PHASE_NAMES[self.ctx.program.phase]

    @property
    def active_gate(self) -> str:
        return f"G{self.ctx.program.phase}"

    @property
    def active_gate_blockers(self) -> list[RuleResult]:
        return gate_blockers(self.ctx, self.results, self.active_gate)

    def results_for(self, entity_type: str, entity_id: int | None) -> list[RuleResult]:
        return [r for r in self.results if r.entity_type == entity_type and r.entity_id == entity_id]

    def worst_for(self, entity_type: str, entity_id: int | None) -> str | None:
        found = self.results_for(entity_type, entity_id)
        if any(r.severity == Severity.RED for r in found):
            return "red"
        return "amber" if found else None

    def top_risks(self, n: int = 3) -> list[RAIDItem]:
        risks = [i for i in self.ctx.raid_items if i.type == RAIDType.RISK and not i.is_closed]
        return sorted(risks, key=lambda r: -(r.score or 0))[:n]

    @property
    def pending_adrs(self) -> int:
        return sum(1 for a in self.ctx.adrs if a.status in ADR_PENDING)

    @property
    def red_count(self) -> int:
        return sum(1 for r in self.results if r.severity == Severity.RED)


def _count(results: list[RuleResult], *rule_ids: str) -> int:
    return sum(1 for r in results if r.rule_id in rule_ids)


def build_view(session: Session, program_id: int, today: date | None = None) -> ProgramView:
    ctx = load_context(session, program_id, today=today)
    results = evaluate(ctx)
    health = weekly_health(results)
    view = ProgramView(ctx=ctx, results=results, health=health, rag=overall_rag(health))

    items = {("raid", i.id): i for i in ctx.raid_items}
    view.alerts = [
        Alert(r, entity_url(r.entity_type, r.entity_code, items.get((r.entity_type, r.entity_id))))
        for r in results
    ]

    # Badges calculados (nunca texto fijo). color = token Tailwind.
    def badge(value: int | str, color: str) -> dict[str, Any] | None:
        return {"value": value, "color": color} if value else None

    orphans = _count(results, "RTM-01")
    raci = _count(results, "RACI-01", "RACI-02")
    critical = _count(results, "RAID-01")
    blocked = bool(view.active_gate_blockers)
    candidates = {
        "rtm_orphans": badge(
            orphans,
            "rag-red"
            if any(r.rule_id == "RTM-01" and r.severity == Severity.RED for r in results)
            else "rag-amber",
        ),
        "adr_pending": badge(view.pending_adrs, "dell-blue"),
        "critical_risks_no_owner": badge(critical, "rag-red"),
        "raci_errors": badge(raci, "rag-red" if _count(results, "RACI-01") else "rag-amber"),
        "active_gate": badge(view.active_gate, "rag-red" if blocked else "dell-blue"),
        "alerts": badge(view.red_count, "rag-red"),
    }
    view.badges = {k: v for k, v in candidates.items() if v}
    return view
