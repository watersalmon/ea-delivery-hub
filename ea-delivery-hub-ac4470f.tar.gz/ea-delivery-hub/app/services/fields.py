"""Campos editables en línea (tablas tipo hoja de cálculo): tipo, opciones cerradas y formato de celda."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import date
from typing import Any

from markupsafe import Markup, escape
from sqlmodel import Session, SQLModel, select

from app.models import (
    ADR,
    ADROption,
    ArchitectureBrief,
    ArchitectureElement,
    Dependency,
    GateCriterion,
    Goal,
    HandoverItem,
    MeetingDecision,
    Objective,
    ORRCheck,
    Outcome,
    Program,
    ProgramSettings,
    RAIDItem,
    Requirement,
    ReviewItem,
    Stakeholder,
    WorkPackage,
    Workstream,
)
from app.models.enums import (
    ESCALATION_FORUM,
    ArchitectureView,
    CompletionStatus,
    MonitorStatus,
    MoSCoW,
    NFRCategory,
    Organization,
    Stance,
)

Options = list[tuple[str, str]]


@dataclass(frozen=True)
class FieldSpec:
    kind: str  # text | textarea | select | date | int | bool
    options: Callable[[Session, Any], Options] | None = None
    required: bool = False


def _static(values: list[str], blank: bool = False) -> Callable[[Session, Any], Options]:
    def opts(_s: Session, _o: Any) -> Options:
        base = [(v, v) for v in values]
        return [("", "—"), *base] if blank else base

    return opts


def _scale(_s: Session, obj: Any) -> Options:
    settings = _s.exec(select(ProgramSettings).where(ProgramSettings.program_id == obj.program_id)).first()
    n = settings.risk_scale if settings else 3
    return [("", "—")] + [(str(i), str(i)) for i in range(1, n + 1)]


def _source_risks(s: Session, obj: Any) -> Options:
    rows = s.exec(
        select(RAIDItem)
        .where(RAIDItem.program_id == obj.program_id, RAIDItem.type == "Risk", RAIDItem.id != obj.id)
        .order_by(RAIDItem.code)
    ).all()
    return [("", "—")] + [(str(r.id), f"{r.code} · {r.title[:50]}") for r in rows]


def _workstreams(s: Session, obj: Any) -> Options:
    rows = s.exec(
        select(Workstream).where(Workstream.program_id == obj.program_id).order_by(Workstream.name)
    ).all()
    return [("", "—")] + [(str(w.id), w.name) for w in rows]


FORUMS = [*ESCALATION_FORUM.values(), "SteerCo", "EA-PM alignment", "Customer architecture review"]
FORUMS = list(dict.fromkeys(FORUMS))
REQUIREMENT_STATUS = ["Proposed", "Approved", "Implemented", "Verified"]

TEXT, AREA, DATE, BOOL, INT = (FieldSpec(k) for k in ("text", "textarea", "date", "bool", "int"))
REQ_TEXT, REQ_AREA = FieldSpec("text", required=True), FieldSpec("textarea", required=True)
NUM = FieldSpec("number")

EDITABLE: dict[str, tuple[type[SQLModel], str, dict[str, FieldSpec]]] = {
    # kind -> (modelo, ámbito de re-render "row" | "cell", campos)
    "raid": (
        RAIDItem,
        "row",
        {
            "organization": FieldSpec("select", _static([o.value for o in Organization])),
            "date_added": DATE,
            "reported_by": TEXT,
            "title": REQ_AREA,
            "description": AREA,
            "workstream_id": FieldSpec("select", _workstreams),
            "owner": TEXT,
            "probability": FieldSpec("select", _scale),
            "impact": FieldSpec("select", _scale),
            "due_date": DATE,
            "monitor_status": FieldSpec("select", _static([m.value for m in MonitorStatus])),
            "contingency_plan": AREA,
            "response": AREA,
            "cause": AREA,
            "event": AREA,
            "consequence": AREA,
            "escalation_trigger": AREA,
            "escalation_forum": FieldSpec("select", _static(FORUMS, blank=True)),
            "trigger_met": BOOL,
            "source_risk_id": FieldSpec("select", _source_risks),
            "severity": FieldSpec("select", _static(["Low", "Medium", "High", "Critical"], blank=True)),
            "resolution": AREA,
            "scope_impact": AREA,
            "cost_impact": TEXT,
            "schedule_impact": TEXT,
            "change_control_decision": FieldSpec(
                "select", _static(["Pending", "Approved", "Rejected"], True)
            ),
            "context": AREA,
            "decision_taken": AREA,
            "result": AREA,
            "recommendation": AREA,
        },
    ),
    "goal": (Goal, "cell", {"title": REQ_AREA}),
    "objective": (
        Objective,
        "cell",
        {
            "objective": REQ_AREA,
            "acceptance_criteria": AREA,
            "completion_status": FieldSpec("select", _static([c.value for c in CompletionStatus])),
            "approver": TEXT,
        },
    ),
    "stakeholder": (
        Stakeholder,
        "cell",
        {
            "name": REQ_TEXT,
            "role": TEXT,
            "organization": FieldSpec("select", _static([o.value for o in Organization])),
            "influence": FieldSpec("select", _static(["1", "2", "3", "4", "5"])),
            "interest": FieldSpec("select", _static(["1", "2", "3", "4", "5"])),
            "stance": FieldSpec("select", _static([s.value for s in Stance])),
            "is_decision_maker": BOOL,
            "channel": TEXT,
            "cadence": TEXT,
            "key_message": AREA,
            "comms_owner": TEXT,
        },
    ),
    "dependency": (
        Dependency,
        "row",
        {
            "title": AREA,
            "source": TEXT,
            "target": TEXT,
            "dep_type": FieldSpec("select", _static(["Delivery", "Information", "Decision", "Resource"])),
            "external": BOOL,
            "commitment_verified": BOOL,
            "evidence": AREA,
            "need_date": DATE,
            "critical_path": BOOL,
            "status": FieldSpec("select", _static(["Open", "At Risk", "Closed"])),
            "owner": TEXT,
        },
    ),
    "requirement": (
        Requirement,
        "cell",
        {
            "statement": REQ_AREA,
            "priority": FieldSpec("select", _static([m.value for m in MoSCoW])),
            "nfr_category": FieldSpec("select", _static([c.value for c in NFRCategory], blank=True)),
            "measurable_criterion": AREA,
            "target_value": NUM,
            "achieved_value": NUM,
            "unit": TEXT,
            "source": TEXT,
            "status": FieldSpec("select", _static(REQUIREMENT_STATUS)),
            "workstream_id": FieldSpec("select", _workstreams),
        },
    ),
    "workstream": (Workstream, "cell", {"name": REQ_TEXT, "lead": TEXT, "scope": AREA}),
    "arch_element": (
        ArchitectureElement,
        "cell",
        {
            "name": REQ_AREA,
            "view": FieldSpec("select", _static([v.value for v in ArchitectureView])),
            "workstream_id": FieldSpec("select", _workstreams),
            "hld_ref": TEXT,
            "lld_ref": TEXT,
        },
    ),
    "outcome": (
        Outcome,
        "cell",
        {
            "description": REQ_AREA,
            "metric": TEXT,
            "baseline_value": TEXT,
            "target_value": TEXT,
            "target_date": DATE,
        },
    ),
    "adr": (
        ADR,
        "cell",
        {
            "title": AREA,
            "context": AREA,
            "decision": AREA,
            "conditions": AREA,
            "rationale": AREA,
            "consequences": AREA,
            "impacted_artifacts": AREA,
            "impacted_workstreams": AREA,
            "cost_impact": TEXT,
            "schedule_impact": TEXT,
            "operations_impact": TEXT,
            "escalation_level": FieldSpec(
                "select", _static(["Workstream", "Architecture", "Program", "Executive"])
            ),
            "critical_path": BOOL,
            "owner": TEXT,
            "due_date": DATE,
            "approvers": TEXT,
        },
    ),
    "adr_option": (
        ADROption,
        "cell",
        {"name": TEXT, "pros": AREA, "cons": AREA, "cost": TEXT, "risk": AREA},
    ),
    "gate_criterion": (
        GateCriterion,
        "cell",
        {
            "criterion": REQ_AREA,
            "status": FieldSpec("select", _static(["Open", "Met", "Not Met"])),
            "evidence_required": AREA,
            "approver": TEXT,
        },
    ),
    "workpackage": (
        WorkPackage,
        "cell",
        {
            "name": AREA,
            "workstream_id": FieldSpec("select", _workstreams),
            "start": DATE,
            "end": DATE,
            "milestone": BOOL,
            "transition_state": TEXT,
            "depends_on": TEXT,
            "gate_code": FieldSpec("select", _static([f"G{n}" for n in range(7)], blank=True)),
            "status": FieldSpec("select", _static(["Planned", "In Progress", "Done", "At Risk"])),
        },
    ),
    "review_item": (
        ReviewItem,
        "cell",
        {
            "answer": FieldSpec("select", _static(["Yes", "No", "Partial", "N/A"], blank=True)),
            "comment": AREA,
            "deviation": BOOL,
        },
    ),
    "brief": (
        ArchitectureBrief,
        "cell",
        {
            k: AREA
            for k in (
                "outcomes",
                "scope_in",
                "scope_out",
                "context",
                "principles",
                "workstreams",
                "risks_assumptions",
                "open_decisions",
                "governance",
            )
        },
    ),
    "meeting_decision": (
        MeetingDecision,
        "cell",
        {
            "outcome": FieldSpec("select", _static(["Approved", "Rejected", "Deferred"], blank=True)),
            "conditions": AREA,
            "owner": TEXT,
            "due_date": DATE,
            "notes": AREA,
        },
    ),
    "orr": (
        ORRCheck,
        "cell",
        {
            "criterion": AREA,
            "evidence": AREA,
            "status": FieldSpec("select", _static(["green", "amber", "red", "grey"])),
            "owner": TEXT,
        },
    ),
    "handover": (
        HandoverItem,
        "cell",
        {
            "kind": FieldSpec("select", _static(["TechDebt", "Deviation", "Transfer"])),
            "title": AREA,
            "impact": AREA,
            "estimated_cost": TEXT,
            "receiving_owner": TEXT,
            "review_date": DATE,
        },
    ),
    "lesson": (
        RAIDItem,
        "cell",
        {
            "title": AREA,
            "context": AREA,
            "decision_taken": AREA,
            "result": AREA,
            "recommendation": AREA,
            "owner": TEXT,
        },
    ),
    "program": (
        Program,
        "cell",
        {
            "name": TEXT,
            "client": TEXT,
            "sponsor": TEXT,
            "pm": TEXT,
            "ea": TEXT,
            "classification": TEXT,
            "export_language": FieldSpec("select", _static(["en", "es"])),
            "applicable_frameworks": AREA,
            "operations_owner": TEXT,
            "operations_engaged": BOOL,
        },
    ),
    "settings": (
        ProgramSettings,
        "cell",
        {
            "amber_from": FieldSpec("int"),
            "red_from": FieldSpec("int"),
            "decision_sla_days": FieldSpec("int"),
        },
    ),
}


class FieldError(ValueError):
    pass


INT_FIELDS = {
    "probability",
    "impact",
    "influence",
    "interest",
    "workstream_id",
    "source_risk_id",
    "amber_from",
    "red_from",
    "decision_sla_days",
}


def parse_value(field: str, spec: FieldSpec, raw: str | None, session: Session, obj: Any) -> Any:
    """Valida y convierte el valor enviado por el formulario de edición en línea."""
    raw = (raw or "").strip()
    if spec.required and not raw:
        raise FieldError("This field cannot be empty.")
    if spec.kind == "number":
        if not raw:
            return None
        try:
            return float(raw.replace(",", "."))
        except ValueError as exc:
            raise FieldError("Enter a number.") from exc
    if spec.kind == "bool":
        return raw.lower() in {"1", "true", "on", "yes"}
    if spec.kind == "date":
        if not raw:
            return None
        try:
            return date.fromisoformat(raw)
        except ValueError as exc:
            raise FieldError("Use the date picker (YYYY-MM-DD).") from exc
    if (
        spec.kind == "select"
        and spec.options is not None
        and raw not in {v for v, _ in spec.options(session, obj)}
    ):
        raise FieldError("Pick a value from the list.")
    if field in INT_FIELDS:
        if raw and not raw.isdigit():
            raise FieldError("Enter a whole number.")
        return int(raw) if raw else None
    return raw


# ------------------------------------------------------------------ formato de celdas


def us_date(d: date | None) -> str:
    """Formato de fecha de la captura del RAID Log (2/16/2024)."""
    return f"{d.month}/{d.day}/{d.year}" if d else ""


def rag_for_score(score: int | None, settings: ProgramSettings) -> str:
    if score is None:
        return "grey"
    if score >= settings.red_from:
        return "red"
    if score >= settings.amber_from:
        return "amber"
    return "green"


COMPLETION_RAG = {"Complete": "green", "In Progress": "blue", "At Risk": "red", "Not Started": "grey"}


def display(obj: Any, field: str, lookups: dict[str, Any] | None = None) -> Markup:
    lookups = lookups or {}
    value = getattr(obj, field, None)
    if field == "workstream_id":
        return escape(lookups.get("workstreams", {}).get(value, ""))
    if isinstance(value, bool):
        return (
            Markup('<span aria-label="yes">✓</span>')
            if value
            else Markup('<span class="text-ink-muted">—</span>')
        )
    if isinstance(value, date):
        return escape(us_date(value))
    if field == "status" and isinstance(obj, ORRCheck):
        dot = f'<span class="rag-dot bg-rag-{escape(value)}"></span>'
        word = {"green": "Green", "amber": "Amber", "red": "Red", "grey": "Not assessed"}.get(
            str(value), str(value)
        )
        return Markup(f'<span class="inline-flex items-center gap-1.5">{dot}{escape(word)}</span>')
    if field == "completion_status" and value:
        rag = COMPLETION_RAG.get(value, "grey")
        dot = f'<span class="rag-dot bg-rag-{rag}"></span>'
        return Markup(f'<span class="inline-flex items-center gap-1.5">{dot}{escape(value)}</span>')
    return escape("" if value is None else value)


def lookups_for(session: Session, program: Program) -> dict[str, Any]:
    ws = session.exec(select(Workstream).where(Workstream.program_id == program.id)).all()
    settings = session.exec(select(ProgramSettings).where(ProgramSettings.program_id == program.id)).first()
    return {
        "workstreams": {w.id: w.name for w in ws},
        "settings": settings or ProgramSettings(program_id=program.id or 0),
    }
