"""Dependencias comunes de las rutas."""

from __future__ import annotations

from fastapi import Depends, Request
from sqlmodel import Session

from app.db import get_session
from app.models import Program
from app.web import current_program


class NoProgramError(Exception):
    """No hay ningún programa todavía: se muestra un estado vacío en lugar de un error."""


def require_program(request: Request, session: Session = Depends(get_session)) -> Program:
    program = current_program(session, request)
    if program is None or program.id is None:
        raise NoProgramError
    return program
