"""Design Authority: preparación de sesión y meeting mode (guía §5.2 y §13.3)."""

from __future__ import annotations

from datetime import date, timedelta
from typing import Any
from urllib.parse import quote

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlmodel import Session, col, select

from app.content.guide import DA_AGENDA, DA_CRITERIA, DA_INPUT, DA_OUTPUT, DA_PARTICIPANTS, DA_SLA
from app.db import get_session
from app.models import ADR, Meeting, MeetingDecision, Program, RAIDItem, Stakeholder, utcnow
from app.models.enums import ADR_PENDING, ADRStatus, RAIDType
from app.routers.deps import require_program
from app.services.fields import lookups_for
from app.services.governance import build_view
from app.services.governance_ops import (
    GovernanceError,
    add_meeting_action,
    close_da,
    meeting_actions,
    schedule_da,
)
from app.web import page_context, render

router = APIRouter()
DA = "Architecture Design Authority"


def _meeting(session: Session, program: Program, meeting_id: int) -> Meeting:
    m = session.get(Meeting, meeting_id)
    if m is None or m.program_id != program.id or m.forum != DA:
        raise HTTPException(404)
    return m


def _default_participants(session: Session, program: Program) -> list[dict[str, object]]:
    """Quórum de la guía §5.2 con nombres del programa cuando se conocen."""
    people = session.exec(select(Stakeholder).where(Stakeholder.program_id == program.id)).all()
    customer = next((s.name for s in people if s.organization == "Customer" and s.is_decision_maker), "")
    return [
        {"role": "Enterprise Architect", "name": program.ea, "present": False},
        {"role": "Tech / Domain Leads", "name": "", "present": False},
        {"role": "Customer", "name": customer, "present": False},
        {"role": "SMEs as needed", "name": "", "present": False},
        {"role": "PM (informed)", "name": program.pm, "present": False},
    ]


@router.get("/design-authority", response_class=HTMLResponse)
def overview(
    request: Request, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    assert program.id is not None
    view = build_view(session, program.id)
    meetings = session.exec(
        select(Meeting)
        .where(Meeting.program_id == program.id, Meeting.forum == DA)
        .order_by(col(Meeting.meeting_date).desc())
    ).all()
    candidates = sorted(
        (a for a in view.ctx.adrs if a.status in ADR_PENDING or a.status == ADRStatus.DEFERRED),
        key=lambda a: (not a.critical_path, a.code),
    )
    attention = [
        a for a in view.alerts if a.result.control in ("raid", "dependencies") and a.result.severity == "red"
    ]
    open_actions = [
        i
        for i in view.ctx.raid_items
        if i.type == RAIDType.ACTION and not i.is_closed and i.reported_by == "Design Authority"
    ]
    ctx = page_context(
        request,
        "design-authority",
        session,
        view,
        meetings=meetings,
        candidates=candidates,
        attention=attention,
        open_actions=open_actions,
        agenda=DA_AGENDA,
        da_input=DA_INPUT,
        da_output=DA_OUTPUT,
        da_sla=DA_SLA,
        participants=DA_PARTICIPANTS,
        criteria=DA_CRITERIA,
        next_date=date.today() + timedelta(days=7),
    )
    return render(request, "pages/da_overview.html", ctx)


@router.post("/design-authority/new")
async def create_session(
    request: Request, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    form = await request.form()
    adr_ids = [int(str(v)) for v in form.getlist("adr_id") if str(v).isdigit()]
    raw_date = str(form.get("meeting_date") or "")
    when = date.fromisoformat(raw_date) if raw_date else date.today()
    assert program.id is not None
    meeting = schedule_da(session, program.id, when, adr_ids, _default_participants(session, program))
    meeting.agenda = "; ".join(f"{m} min · {t}" for m, t in DA_AGENDA)
    session.commit()
    return RedirectResponse(f"/design-authority/{meeting.id}", status_code=303)


def _decisions(session: Session, meeting: Meeting) -> list[tuple[MeetingDecision, ADR]]:
    rows = session.exec(
        select(MeetingDecision)
        .where(MeetingDecision.meeting_id == meeting.id)
        .order_by(col(MeetingDecision.order))
    ).all()
    out = []
    for d in rows:
        adr = session.get(ADR, d.adr_id)
        if adr is not None:
            out.append((d, adr))
    return out


@router.get("/design-authority/{meeting_id}", response_class=HTMLResponse)
def session_view(
    request: Request,
    meeting_id: int,
    error: str = "",
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    meeting = _meeting(session, program, meeting_id)
    assert program.id is not None
    view = build_view(session, program.id)
    attention = [
        a for a in view.alerts if a.result.control in ("raid", "dependencies") and a.result.severity == "red"
    ]
    ctx = page_context(
        request,
        "design-authority",
        session,
        view,
        meeting=meeting,
        decisions=_decisions(session, meeting),
        agenda=DA_AGENDA,
        actions=meeting_actions(session, meeting),
        attention=attention,
        lookups=lookups_for(session, program),
        error=error,
        today=date.today(),
    )
    return render(request, "pages/da_session.html", ctx)


@router.post("/design-authority/{meeting_id}/start")
def start(
    meeting_id: int, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    meeting = _meeting(session, program, meeting_id)
    if meeting.status == "Planned":
        meeting.status = "In Progress"
        meeting.started_at = utcnow()
        session.add(meeting)
        session.commit()
    return RedirectResponse(f"/design-authority/{meeting_id}", status_code=303)


@router.post("/design-authority/{meeting_id}/participant/{index}")
def toggle_participant(
    meeting_id: int,
    index: int,
    name: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    meeting = _meeting(session, program, meeting_id)
    people = [dict(p) for p in meeting.participants]
    if not 0 <= index < len(people) or meeting.status == "Closed":
        raise HTTPException(404)
    people[index]["present"] = not bool(people[index].get("present"))
    if name.strip():
        people[index]["name"] = name.strip()
    meeting.participants = people  # nueva lista: SQLAlchemy detecta el cambio del JSON
    session.add(meeting)
    session.commit()
    return RedirectResponse(f"/design-authority/{meeting_id}#quorum", status_code=303)


@router.post("/design-authority/{meeting_id}/action")
def add_action(
    meeting_id: int,
    title: str = Form(""),
    owner: str = Form(""),
    due_date: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    meeting = _meeting(session, program, meeting_id)
    try:
        due = date.fromisoformat(due_date) if due_date else date.today() + timedelta(days=7)
        add_meeting_action(session, meeting, title, owner, due)
        session.commit()
    except (GovernanceError, ValueError) as exc:
        return RedirectResponse(
            f"/design-authority/{meeting_id}?error={quote(str(exc))}#actions", status_code=303
        )
    return RedirectResponse(f"/design-authority/{meeting_id}#actions", status_code=303)


@router.post("/design-authority/{meeting_id}/close")
def close(
    meeting_id: int, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    meeting = _meeting(session, program, meeting_id)
    try:
        close_da(session, meeting)
        session.commit()
    except GovernanceError as exc:
        session.rollback()
        return RedirectResponse(f"/design-authority/{meeting_id}?error={quote(str(exc))}", status_code=303)
    return RedirectResponse(f"/design-authority/{meeting_id}?closed=1", status_code=303)


def raid_for_meeting(session: Session, meeting: Meeting) -> list[RAIDItem]:
    return meeting_actions(session, meeting)
