"""Goals & Solution Dependency Map (captura 2) y Requirements Traceability Matrix con cobertura."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from sqlmodel import Session, select

from app.db import get_session
from app.models import (
    ADR,
    ArchitectureElement,
    Gate,
    Goal,
    Objective,
    Outcome,
    Program,
    Requirement,
    TestEvidence,
    Workstream,
)
from app.models.enums import NFRCategory
from app.routers.deps import require_program
from app.rules import ProgramContext
from app.services.fields import EDITABLE, FieldError, lookups_for, parse_value
from app.services.governance import ProgramView, build_view
from app.services.ids import next_code
from app.services.trace_links import (
    GROUP_LABELS,
    GROUPS,
    LinkTargetError,
    candidates,
    parse_targets,
    set_links,
)
from app.web import page_context, render, templates

router = APIRouter()


# ------------------------------------------------------------------ Solution Dependency Map


@router.get("/goals", response_class=HTMLResponse)
def goals(
    request: Request, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    assert program.id is not None
    view = build_view(session, program.id)
    goal_rows = session.exec(select(Goal).where(Goal.program_id == program.id).order_by(Goal.code)).all()
    objs = session.exec(
        select(Objective).where(Objective.program_id == program.id).order_by(Objective.code)
    ).all()
    by_goal: dict[int, list[Objective]] = {}
    for o in objs:
        by_goal.setdefault(o.goal_id, []).append(o)
    groups = [(g, by_goal.get(g.id or -1, [])) for g in goal_rows]
    req_count = {o.id: len(view.ctx.linked_ids("objective", o.id, "requirement")) for o in objs}
    outcomes = session.exec(
        select(Outcome).where(Outcome.program_id == program.id).order_by(Outcome.code)
    ).all()
    done = sum(1 for o in objs if o.completion_status == "Complete")
    ctx = page_context(
        request,
        "goals",
        session,
        view,
        groups=groups,
        req_count=req_count,
        outcomes=outcomes,
        lookups=lookups_for(session, program),
        total=len(objs),
        done=done,
    )
    return render(request, "pages/goals.html", ctx)


# ------------------------------------------------------------------ RTM


@dataclass
class TraceRow:
    req: Requirement
    upstream: list[Any] = field(default_factory=list)  # objectives y outcomes
    elements: list[ArchitectureElement] = field(default_factory=list)
    adrs: list[ADR] = field(default_factory=list)
    evidence: list[TestEvidence] = field(default_factory=list)
    gates: list[Gate] = field(default_factory=list)
    direct_adr_ids: set[int] = field(default_factory=set)
    rag: str = "green"
    issues: list[Any] = field(default_factory=list)

    @property
    def end_to_end(self) -> bool:
        return bool(self.upstream and self.elements and self.evidence)


def build_trace(session: Session, view: ProgramView) -> list[TraceRow]:
    ctx: ProgramContext = view.ctx
    pid = ctx.program.id
    objectives = {o.id: o for o in session.exec(select(Objective).where(Objective.program_id == pid)).all()}
    outcomes = {o.id: o for o in session.exec(select(Outcome).where(Outcome.program_id == pid)).all()}
    elements = {a.id: a for a in ctx.arch_elements}
    adrs = {a.id: a for a in ctx.adrs}
    evidence = {e.id: e for e in ctx.test_evidence}
    gates = {g.id: g for g in ctx.gates}
    rows = []
    for req in sorted(ctx.requirements, key=lambda r: (r.kind, r.code)):
        row = TraceRow(req=req)
        row.upstream = [
            objectives[i] for i in ctx.linked_ids("requirement", req.id, "objective") if i in objectives
        ]
        row.upstream += [
            outcomes[i] for i in ctx.linked_ids("requirement", req.id, "outcome") if i in outcomes
        ]
        row.elements = [
            elements[i]
            for i in sorted(ctx.linked_ids("requirement", req.id, "arch_element"))
            if i in elements
        ]
        adr_ids = set(ctx.linked_ids("requirement", req.id, "adr"))
        row.direct_adr_ids = set(adr_ids)
        for el in row.elements:
            adr_ids |= ctx.linked_ids("arch_element", el.id, "adr")
        row.adrs = sorted((adrs[i] for i in adr_ids if i in adrs), key=lambda a: a.code)
        row.evidence = [
            evidence[i] for i in ctx.linked_ids("requirement", req.id, "test_evidence") if i in evidence
        ]
        row.gates = [gates[i] for i in ctx.linked_ids("requirement", req.id, "gate") if i in gates]
        row.issues = view.results_for("requirement", req.id)
        row.rag = view.worst_for("requirement", req.id) or "green"
        rows.append(row)
    return rows


def coverage(rows: list[TraceRow]) -> dict[str, Any]:
    n = len(rows) or 1
    return {
        "total": len(rows),
        "upstream": round(100 * sum(bool(r.upstream) for r in rows) / n),
        "design": round(100 * sum(bool(r.elements) for r in rows) / n),
        "evidence": round(100 * sum(bool(r.evidence) for r in rows) / n),
        "e2e": round(100 * sum(r.end_to_end for r in rows) / n),
        "orphans": sum(1 for r in rows if any(i.rule_id == "RTM-01" for i in r.issues)),
    }


@router.get("/rtm", response_class=HTMLResponse)
def rtm(
    request: Request,
    orphans: bool = False,
    gate: str = "",
    workstream: str = "",
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    assert program.id is not None
    view = build_view(session, program.id)
    rows = build_trace(session, view)
    cov = coverage(rows)
    if orphans:
        rows = [r for r in rows if any(i.rule_id == "RTM-01" for i in r.issues)]
    if gate:
        rows = [r for r in rows if any(g.code == gate for g in r.gates)]
    ws_id = int(workstream) if workstream.isdigit() else None
    if ws_id:
        rows = [r for r in rows if r.req.workstream_id == ws_id]
    workstreams = session.exec(
        select(Workstream).where(Workstream.program_id == program.id).order_by(Workstream.name)
    ).all()
    ctx = page_context(
        request,
        "rtm",
        session,
        view,
        rows=rows,
        cov=cov,
        workstreams=workstreams,
        f_orphans=orphans,
        f_gate=gate,
        f_ws=ws_id,
        lookups=lookups_for(session, program),
        nfr_categories=[c.value for c in NFRCategory],
    )
    return render(request, "pages/rtm.html", ctx)


# ------------------------------------------------------------------ editor de enlaces por celda


def _group_or_404(group: str) -> tuple[str, ...]:
    if group not in GROUPS:
        raise HTTPException(404)
    return GROUPS[group]


def _req_by_id_or_404(session: Session, program: Program, req_id: int) -> Requirement:
    req = session.get(Requirement, req_id)
    if req is None or req.program_id != program.id:
        raise HTTPException(404)
    return req


def _row_for(session: Session, program: Program, req: Requirement) -> TraceRow:
    assert program.id is not None
    view = build_view(session, program.id)
    return next(r for r in build_trace(session, view) if r.req.id == req.id)


def _current_values(row: TraceRow, group: str) -> set[str]:
    if group == "upstream":
        return {f"{'objective' if hasattr(u, 'objective') else 'outcome'}:{u.id}" for u in row.upstream}
    if group == "arch_element":
        return {f"arch_element:{e.id}" for e in row.elements}
    if group == "adr":
        return {f"adr:{i}" for i in row.direct_adr_ids}
    if group == "test_evidence":
        return {f"test_evidence:{e.id}" for e in row.evidence}
    return {f"gate:{g.id}" for g in row.gates}


@router.get("/rtm/{req_id}/links/{group}/edit", response_class=HTMLResponse)
def edit_links(
    request: Request,
    req_id: int,
    group: str,
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    """Contenido de la ventana emergente (modal) para elegir los enlaces de un tipo."""
    kinds = _group_or_404(group)
    req = _req_by_id_or_404(session, program, req_id)
    assert program.id is not None
    row = _row_for(session, program, req)
    inherited = [a for a in row.adrs if a.id not in row.direct_adr_ids] if group == "adr" else []
    inherited_values = {f"adr:{a.id}" for a in inherited}
    blocks = [
        (title, [(v, text) for v, text in items if v not in inherited_values])
        for title, items in candidates(session, program.id, kinds)
    ]
    ctx = {
        "title": f"{req.code} · {GROUP_LABELS[group].capitalize()} links",
        "subtitle": req.statement,
        "action": f"/rtm/{req.id}/links/{group}",
        "label": GROUP_LABELS[group],
        "blocks": blocks,
        "current": _current_values(row, group),
        "inherited": [(a.code, a.title) for a in inherited],
        "inherited_note": "Inherited via architecture elements (read-only)",
    }
    return templates.TemplateResponse(request, "partials/_link_picker.html", ctx)


@router.post("/rtm/{req_id}/links/{group}", status_code=204)
async def save_links(
    request: Request,
    req_id: int,
    group: str,
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Response:
    """Fija los enlaces de ese tipo exactamente al conjunto marcado (altas + bajas)."""
    kinds = _group_or_404(group)
    req = _req_by_id_or_404(session, program, req_id)
    assert program.id is not None and req.id is not None
    form = await request.form()
    try:
        wanted = parse_targets(session, program.id, kinds, [str(v) for v in form.getlist("target")])
    except LinkTargetError as exc:
        raise HTTPException(exc.status, str(exc) or None) from exc
    set_links(session, program.id, req.id, kinds, wanted)
    # app.js cierra el modal y refresca <main> (KPIs, RTM-01, filtros) sin recargar la página
    return Response(status_code=204, headers={"HX-Trigger": "ea:saved"})


# ------------------------------------------------------------------ ficha de edición del requisito

REQ_EDIT_FIELDS = [
    "statement",
    "priority",
    "status",
    "workstream_id",
    "source",
    "nfr_category",
    "measurable_criterion",
    "target_value",
    "achieved_value",
    "unit",
]


def _requirement_or_404(session: Session, program: Program, code: str) -> Requirement:
    req = session.exec(
        select(Requirement).where(Requirement.program_id == program.id, Requirement.code == code)
    ).first()
    if req is None:
        raise HTTPException(404)
    return req


def _edit_page(
    request: Request,
    session: Session,
    program: Program,
    req: Requirement,
    values: dict[str, str],
    errors: dict[str, str],
    status_code: int = 200,
) -> Any:
    _, _, specs = EDITABLE["requirement"]
    ctx = page_context(
        request,
        "rtm",
        session,
        req=req,
        values=values,
        errors=errors,
        options={f: opt(session, req) for f in REQ_EDIT_FIELDS if (opt := specs[f].options) is not None},
    )
    return render(request, "pages/requirement_edit.html", ctx, status_code=status_code)


@router.get("/requirements/{code}/edit", response_class=HTMLResponse)
def edit_requirement(
    request: Request,
    code: str,
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    req = _requirement_or_404(session, program, code)
    values = {"kind": req.kind}
    for f in REQ_EDIT_FIELDS:
        v = getattr(req, f)
        values[f] = "" if v is None else (f"{v:g}" if isinstance(v, float) else str(v))
    return _edit_page(request, session, program, req, values, {})


@router.post("/requirements/{code}/edit", response_class=HTMLResponse)
async def save_requirement(
    request: Request,
    code: str,
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    req = _requirement_or_404(session, program, code)
    form = await request.form()
    values = {k: str(v) for k, v in form.items()}
    _, _, specs = EDITABLE["requirement"]
    errors: dict[str, str] = {}
    parsed: dict[str, Any] = {}
    kind = values.get("kind", req.kind)
    if kind not in {"FR", "NFR"}:
        errors["kind"] = "Pick FR or NFR."
    for f in REQ_EDIT_FIELDS:
        try:
            parsed[f] = parse_value(f, specs[f], values.get(f, ""), session, req)
        except FieldError as exc:
            errors[f] = str(exc)
    if errors:
        return _edit_page(request, session, program, req, values, errors, status_code=422)
    if kind == "FR":
        parsed["nfr_category"] = ""
    assert program.id is not None
    if kind != req.kind:
        # El prefijo del código sigue al tipo (REQ-/NFR-); los enlaces de la RTM van por id y se conservan
        req.kind = kind
        req.code = next_code(session, program.id, "NFR" if kind == "NFR" else "REQ")
    for f, v in parsed.items():
        setattr(req, f, v)
    session.add(req)
    session.commit()
    return RedirectResponse(f"/rtm#{req.code}", status_code=303)
