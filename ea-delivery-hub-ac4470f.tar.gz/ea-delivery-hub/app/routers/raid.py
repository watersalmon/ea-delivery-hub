"""RAID Log con pestañas (captura 1), matriz PxI, alta de elementos y registro de dependencias."""

from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlmodel import Session, col, select

from app.config import get_settings
from app.content.raid_layout import Col, columns_for  # noqa: F401  (Col re-exportado)
from app.db import get_session
from app.models import Dependency, Program, RAIDItem, RAIDUpdate, Workstream
from app.models.enums import RAID_PREFIX, MonitorStatus, RAIDType
from app.routers.deps import require_program
from app.services.fields import FORUMS, lookups_for, rag_for_score
from app.services.governance import RAID_TABS, ProgramView, build_view
from app.services.ids import next_code
from app.web import page_context, render

router = APIRouter()


def risk_matrix(view: ProgramView) -> dict[tuple[int, int], dict[str, Any]]:
    settings = view.ctx.settings
    n = settings.risk_scale
    cells: dict[tuple[int, int], dict[str, Any]] = {
        (p, i): {"count": 0, "rag": rag_for_score(p * i, settings)}
        for p in range(1, n + 1)
        for i in range(1, n + 1)
    }
    for r in view.ctx.raid_items:
        if (
            r.type == RAIDType.RISK
            and not r.is_closed
            and r.probability
            and r.impact
            and (r.probability, r.impact) in cells
        ):
            cells[(r.probability, r.impact)]["count"] += 1
    return cells


def updates_by_item(session: Session, program_id: int) -> dict[int, list[RAIDUpdate]]:
    out: dict[int, list[RAIDUpdate]] = {}
    rows = session.exec(
        select(RAIDUpdate).where(RAIDUpdate.program_id == program_id).order_by(col(RAIDUpdate.update_date))
    ).all()
    for u in rows:
        out.setdefault(u.raid_item_id, []).append(u)
    return out


@router.get("/raid", response_class=HTMLResponse)
def raid_log(
    request: Request,
    tab: str = "risks",
    p: int | None = None,
    i: int | None = None,
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    tabs = {key: (label, t) for key, label, t in RAID_TABS}
    if tab not in tabs:
        raise HTTPException(404)
    assert program.id is not None
    view = build_view(session, program.id)
    raid_type = tabs[tab][1]
    items = [x for x in view.ctx.raid_items if x.type == raid_type] if raid_type else []
    if raid_type == RAIDType.RISK and p and i:
        items = [x for x in items if x.probability == p and x.impact == i]
    items.sort(key=lambda x: x.code)
    counts = {t: sum(1 for x in view.ctx.raid_items if x.type == t) for _, _, t in RAID_TABS if t}
    ctx = page_context(
        request,
        "raid",
        session,
        view,
        tab=tab,
        tabs=RAID_TABS,
        raid_type=raid_type,
        items=items,
        columns=columns_for(raid_type) if raid_type else [],
        lookups=lookups_for(session, program),
        updates=updates_by_item(session, program.id),
        matrix=risk_matrix(view),
        selected_p=p,
        selected_i=i,
        counts=counts,
        open_counts={
            t: sum(1 for x in view.ctx.raid_items if x.type == t and not x.is_closed) for t in counts
        },
        sheet_title={"cover": "RAID LOG", "lessons": "LESSONS LEARNED"}.get(
            tab, f"{tabs[tab][0].upper()} LOG"
        ),
    )
    return render(request, "pages/raid.html", ctx)


# ------------------------------------------------------------------ alta de elementos


NEW_FIELDS: dict[str, list[str]] = {
    RAIDType.RISK: [
        "title",
        "cause",
        "event",
        "consequence",
        "probability",
        "impact",
        "owner",
        "response",
        "contingency_plan",
        "escalation_trigger",
        "escalation_forum",
        "due_date",
    ],
    RAIDType.ACTION: ["title", "owner", "due_date", "description"],
    RAIDType.ISSUE: ["title", "owner", "severity", "due_date", "source_risk_id", "description"],
    RAIDType.DECISION: ["title", "owner", "description"],
    RAIDType.ESCALATION: ["title", "source_risk_id", "owner", "escalation_forum", "due_date", "description"],
    RAIDType.CHANGE: ["title", "owner", "scope_impact", "cost_impact", "schedule_impact", "description"],
    RAIDType.COMM: ["title", "owner", "due_date", "description"],
    RAIDType.LESSON: ["title", "context", "decision_taken", "result", "recommendation", "owner"],
}


def _type_or_404(raw: str) -> RAIDType:
    try:
        return RAIDType(raw)
    except ValueError as exc:
        raise HTTPException(404) from exc


@router.get("/raid/new", response_class=HTMLResponse)
def new_item(
    request: Request,
    type: str = "Risk",
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    raid_type = _type_or_404(type)
    workstreams = session.exec(select(Workstream).where(Workstream.program_id == program.id)).all()
    ctx = page_context(
        request,
        "raid",
        session,
        raid_type=raid_type,
        fields=NEW_FIELDS[raid_type],
        workstreams=workstreams,
        forums=FORUMS,
        errors={},
        values={},
    )
    return render(request, "pages/raid_new.html", ctx)


@router.post("/raid/new", response_class=HTMLResponse)
async def create_item(
    request: Request, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    form = await request.form()
    raid_type = _type_or_404(str(form.get("type", "")))
    values = {k: str(v).strip() for k, v in form.items() if k != "type"}
    errors: dict[str, str] = {}
    if not values.get("title"):
        errors["title"] = "A title is required."
    data: dict[str, Any] = {}
    for f in NEW_FIELDS[raid_type] + ["workstream_id"]:
        raw = values.get(f, "")
        if f in {"probability", "impact", "workstream_id"}:
            data[f] = int(raw) if raw.isdigit() else None
        elif f == "source_risk_id":
            risk = session.get(RAIDItem, int(raw)) if raw.isdigit() else None
            data[f] = (
                risk.id if risk and risk.program_id == program.id and risk.type == RAIDType.RISK else None
            )
        elif f == "due_date":
            try:
                data[f] = date.fromisoformat(raw) if raw else None
            except ValueError:
                errors[f] = "Invalid date."
        else:
            data[f] = raw
    if raid_type == RAIDType.RISK:
        for f in ("cause", "event", "consequence"):
            if not data.get(f):
                errors[f] = "Required: risks follow the cause-event-consequence format (guide §8)."
    if errors:
        workstreams = session.exec(select(Workstream).where(Workstream.program_id == program.id)).all()
        ctx = page_context(
            request,
            "raid",
            session,
            raid_type=raid_type,
            fields=NEW_FIELDS[raid_type],
            workstreams=workstreams,
            forums=FORUMS,
            errors=errors,
            values=values,
        )
        return render(request, "pages/raid_new.html", ctx, status_code=422)
    assert program.id is not None
    item = RAIDItem(
        program_id=program.id,
        type=raid_type,
        code=next_code(session, program.id, RAID_PREFIX[raid_type]),
        date_added=date.today(),
        reported_by=get_settings().current_user,
        monitor_status=MonitorStatus.OPEN,
        **data,
    )
    session.add(item)
    session.commit()
    tab = next(key for key, _, t in RAID_TABS if t == raid_type)
    return RedirectResponse(f"/raid?tab={tab}#{item.code}", status_code=303)


@router.post("/raid/{item_id}/escalate")
def escalate_risk(
    item_id: int, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    """Resuelve RAID-04: abre una Escalation enlazada al riesgo, dirigida al foro de escalación indicado."""
    risk = session.get(RAIDItem, item_id)
    if risk is None or risk.program_id != program.id or risk.type != RAIDType.RISK:
        raise HTTPException(404)
    assert program.id is not None
    existing = session.exec(
        select(RAIDItem).where(
            RAIDItem.program_id == program.id,
            RAIDItem.type == RAIDType.ESCALATION,
            RAIDItem.source_risk_id == risk.id,
        )
    ).first()
    if existing is None:
        existing = RAIDItem(
            program_id=program.id,
            type=RAIDType.ESCALATION,
            code=next_code(session, program.id, RAID_PREFIX[RAIDType.ESCALATION]),
            date_added=date.today(),
            reported_by=get_settings().current_user,
            monitor_status=MonitorStatus.OPEN,
            title=f"{risk.code}: {risk.title}",
            source_risk_id=risk.id,
            workstream_id=risk.workstream_id,
            owner=risk.owner,
            escalation_forum=risk.escalation_forum,
            due_date=date.today() + timedelta(days=7),
            description=f"Escalation trigger met: {risk.escalation_trigger}"
            if risk.escalation_trigger
            else "",
        )
        session.add(existing)
        session.commit()
    return RedirectResponse(f"/raid?tab=escalation#{existing.code}", status_code=303)


# ------------------------------------------------------------------ dependencias


@router.get("/raid/dependencies", response_class=HTMLResponse)
def dependencies(
    request: Request, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    assert program.id is not None
    view = build_view(session, program.id)
    deps = sorted(view.ctx.dependencies, key=lambda d: d.code)
    ctx = page_context(
        request,
        "raid",
        session,
        view,
        deps=deps,
        lookups=lookups_for(session, program),
        graph=dependency_graph(view, deps),
    )
    return render(request, "pages/dependencies.html", ctx)


def dependency_graph(view: ProgramView, deps: list[Dependency]) -> dict[str, Any]:
    """Grafo SVG simple: nodos en elipse (workstreams, terceros, cliente) y aristas coloreadas por RAG."""
    import math

    names: list[str] = []
    for d in deps:
        for n in (d.source, d.target):
            if n not in names:
                names.append(n)
    w, h, r = 760, 380, 150
    cx, cy = w / 2, h / 2
    nodes = []
    for k, n in enumerate(names):
        a = 2 * math.pi * k / max(len(names), 1) - math.pi / 2
        nodes.append(
            {
                "name": n,
                "x": cx + r * 1.9 * math.cos(a),
                "y": cy + r * math.sin(a),
                "external": any(d.external and d.target == n for d in deps),
            }
        )
    pos = {n["name"]: n for n in nodes}
    edges = []
    for d in deps:
        rag = view.worst_for("dependency", d.id) or (
            "green" if d.commitment_verified or not d.external else "amber"
        )
        s, t = pos[d.source], pos[d.target]
        edges.append(
            {
                "x1": s["x"],
                "y1": s["y"],
                "x2": t["x"],
                "y2": t["y"],
                "rag": rag,
                "code": d.code,
                "title": d.title,
            }
        )
    return {"w": w, "h": h, "nodes": nodes, "edges": edges}


@router.get("/raid/dependencies/new", response_class=HTMLResponse)
def new_dependency(
    request: Request, session: Session = Depends(get_session), program: Program = Depends(require_program)
) -> Any:
    return render(
        request, "pages/dependency_new.html", page_context(request, "raid", session, errors={}, values={})
    )


@router.post("/raid/dependencies/new", response_class=HTMLResponse)
async def create_dependency(
    request: Request, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    form = {k: str(v).strip() for k, v in (await request.form()).items()}
    errors = {f: "Required." for f in ("title", "source", "target") if not form.get(f)}
    if errors:
        ctx = page_context(request, "raid", session, errors=errors, values=form)
        return render(request, "pages/dependency_new.html", ctx, status_code=422)
    assert program.id is not None
    dep = Dependency(
        program_id=program.id,
        code=next_code(session, program.id, "DEP"),
        title=form["title"],
        source=form["source"],
        target=form["target"],
        dep_type=form.get("dep_type", "Delivery"),
        external=form.get("external") == "on",
        commitment_verified=form.get("commitment_verified") == "on",
        critical_path=form.get("critical_path") == "on",
        evidence=form.get("evidence", ""),
        need_date=date.fromisoformat(form["need_date"]) if form.get("need_date") else None,
        owner=form.get("owner", ""),
    )
    session.add(dep)
    session.commit()
    return RedirectResponse(f"/raid/dependencies#{dep.code}", status_code=303)
