"""Administración (§7.18): programas, escalas de riesgo, SLA, branding e import/export JSON del programa."""

from __future__ import annotations

import json
import re
from datetime import date
from typing import Any
from urllib.parse import quote

import yaml
from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from sqlmodel import Session, col, select

from app.config import BRANDING_OVERRIDABLE, branding_override_path, get_branding
from app.db import get_session
from app.models import Program, ProgramSettings, Workstream
from app.services.fields import lookups_for
from app.services.program_io import ImportError_, export_program, import_program
from app.web import PROGRAM_COOKIE, current_program, page_context, render

router = APIRouter()
MAX_IMPORT = 20 * 1024 * 1024


def _err(msg: str, anchor: str = "") -> RedirectResponse:
    return RedirectResponse(f"/admin?error={quote(msg)}{anchor}", status_code=303)


@router.get("/admin", response_class=HTMLResponse)
def admin(request: Request, session: Session = Depends(get_session)) -> Any:
    programs = list(session.exec(select(Program).order_by(col(Program.id))).all())
    settings = {s.program_id: s for s in session.exec(select(ProgramSettings)).all()}
    active = current_program(session, request)
    lookups = lookups_for(session, active or programs[0]) if programs else {}
    workstreams = (
        session.exec(
            select(Workstream).where(Workstream.program_id == active.id).order_by(Workstream.name)
        ).all()
        if active
        else []
    )
    ctx = page_context(
        request,
        "admin",
        session,
        all_programs=programs,
        settings=settings,
        lookups=lookups,
        workstreams=workstreams,
        brand=get_branding(),
        overridable=BRANDING_OVERRIDABLE,
    )
    return render(request, "pages/admin.html", ctx)


@router.post("/admin/program/new")
def new_program(
    code: str = Form(""),
    name: str = Form(""),
    client: str = Form(""),
    sponsor: str = Form(""),
    pm: str = Form(""),
    ea: str = Form(""),
    phase: str = Form("0"),
    risk_scale: str = Form("3"),
    session: Session = Depends(get_session),
) -> Any:
    code = code.strip().upper()
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9-]{1,38}", code) or not name.strip() or not client.strip():
        return _err("A program needs a code (letters, digits, dashes), a name and a customer.", "#programs")
    if session.exec(select(Program).where(Program.code == code)).first():
        return _err(f"The code {code} is already in use.", "#programs")
    phase_n = int(phase) if phase.isdigit() and 0 <= int(phase) <= 6 else 0
    program = Program(
        code=code,
        name=name.strip(),
        client=client.strip(),
        sponsor=sponsor.strip(),
        pm=pm.strip(),
        ea=ea.strip(),
        phase=phase_n,
        start_date=date.today(),
    )
    session.add(program)
    session.flush()
    from app.services.seed import Builder

    b = Builder(session, program, date.today())
    b.settings(**ProgramSettings.defaults_for_scale(5 if risk_scale == "5" else 3))
    b.gates(passed_through=phase_n)
    b.raci()
    session.commit()
    response = RedirectResponse("/dashboard", status_code=303)
    response.set_cookie(
        PROGRAM_COOKIE, str(program.id), httponly=True, samesite="lax", max_age=60 * 60 * 24 * 365
    )
    return response


@router.post("/admin/settings/{program_id}/scale")
def set_scale(program_id: int, risk_scale: str = Form("3"), session: Session = Depends(get_session)) -> Any:
    """Cambiar la escala reajusta los umbrales RAG por defecto (PDR-003 #5)."""
    s = session.exec(select(ProgramSettings).where(ProgramSettings.program_id == program_id)).first()
    if s is None:
        raise HTTPException(404)
    for k, v in ProgramSettings.defaults_for_scale(5 if risk_scale == "5" else 3).items():
        setattr(s, k, v)
    session.add(s)
    session.commit()
    return RedirectResponse("/admin#settings", status_code=303)


@router.post("/admin/branding")
async def save_branding(request: Request) -> Any:
    form = await request.form()
    values = {k: str(form.get(k, "")).strip() for k in BRANDING_OVERRIDABLE}
    if values.get("export_language") not in {"en", "es"}:
        values["export_language"] = "en"
    if not values.get("classification"):
        return _err("The classification text cannot be empty.", "#branding")
    branding_override_path().write_text(yaml.safe_dump(values, allow_unicode=True), encoding="utf-8")
    get_branding.cache_clear()
    return RedirectResponse("/admin#branding", status_code=303)


@router.get("/admin/export/{program_id}")
def export_json(program_id: int, session: Session = Depends(get_session)) -> Any:
    try:
        data = export_program(session, program_id)
    except LookupError as exc:
        raise HTTPException(404) from exc
    code = data["program"]["code"]
    body = json.dumps(data, ensure_ascii=False, indent=1)
    return Response(
        body,
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{code}_program_{date.today():%Y%m%d}.json"'},
    )


@router.post("/admin/import")
async def import_json(
    file: UploadFile = File(...), name: str = Form(""), session: Session = Depends(get_session)
) -> Any:
    raw = await file.read(MAX_IMPORT + 1)
    if len(raw) > MAX_IMPORT:
        return _err("The file is larger than 20 MB.", "#import")
    try:
        payload = json.loads(raw.decode("utf-8"))
        program = import_program(session, payload, name=name.strip() or None)
        session.commit()
    except (ValueError, ImportError_, TypeError, KeyError) as exc:
        session.rollback()
        msg = str(exc) if isinstance(exc, ImportError_) else "The file is not a valid EA Delivery Hub export."
        return _err(msg, "#import")
    response = RedirectResponse("/dashboard", status_code=303)
    response.set_cookie(
        PROGRAM_COOKIE, str(program.id), httponly=True, samesite="lax", max_age=60 * 60 * 24 * 365
    )
    return response
