"""Decisiones (ADR): catálogo con filtros, ficha §13.2, matriz de trade-offs y ciclo de vida."""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from sqlmodel import Session, col, select

from app.content.guide import DA_CRITERIA, ESCALATION_LEVELS
from app.db import get_session
from app.models import ADR, ADROption, ADRStatusChange, Program, TraceLink
from app.models.enums import ADRStatus
from app.routers.deps import require_program
from app.services.fields import lookups_for
from app.services.governance import build_view
from app.services.governance_ops import ADR_TRANSITIONS, GovernanceError, change_adr_status, create_adr
from app.services.trace_links import LinkTargetError, candidates, parse_targets, sync_links
from app.web import page_context, render, templates

router = APIRouter()


def _adr(session: Session, program: Program, code: str) -> ADR:
    adr = session.exec(select(ADR).where(ADR.program_id == program.id, ADR.code == code)).first()
    if adr is None:
        raise HTTPException(404)
    return adr


@router.get("/adr", response_class=HTMLResponse)
def catalogue(
    request: Request,
    status: str = "",
    level: str = "",
    critical: bool = False,
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    assert program.id is not None
    view = build_view(session, program.id)
    adrs = sorted(view.ctx.adrs, key=lambda a: a.code)
    if status:
        adrs = [a for a in adrs if a.status == status]
    if level:
        adrs = [a for a in adrs if a.escalation_level == level]
    if critical:
        adrs = [a for a in adrs if a.critical_path]
    counts = {s.value: sum(1 for a in view.ctx.adrs if a.status == s) for s in ADRStatus}
    ctx = page_context(
        request,
        "adr",
        session,
        view,
        adrs=adrs,
        counts=counts,
        f_status=status,
        f_level=level,
        f_critical=critical,
        statuses=[s.value for s in ADRStatus],
        levels=[lv for lv, _, _ in ESCALATION_LEVELS],
    )
    return render(request, "pages/adr_list.html", ctx)


@router.get("/adr/new", response_class=HTMLResponse)
def new_adr(
    request: Request, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    ctx = page_context(request, "adr", session, levels=ESCALATION_LEVELS, errors={}, values={})
    return render(request, "pages/adr_new.html", ctx)


@router.post("/adr/new", response_class=HTMLResponse)
async def create(
    request: Request, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    form = {k: str(v).strip() for k, v in (await request.form()).items()}
    errors = {f: "Required." for f in ("title", "context") if not form.get(f)}
    if form.get("critical_path") == "on" and not (form.get("owner") and form.get("due_date")):
        errors["owner"] = "Critical-path decisions need an owner and a due date (ADR-01)."
    if errors:
        ctx = page_context(request, "adr", session, levels=ESCALATION_LEVELS, errors=errors, values=form)
        return render(request, "pages/adr_new.html", ctx, status_code=422)
    from datetime import date

    assert program.id is not None
    adr = create_adr(
        session,
        program.id,
        form["title"],
        context=form["context"],
        escalation_level=form.get("escalation_level", "Architecture"),
        critical_path=form.get("critical_path") == "on",
        owner=form.get("owner", ""),
        due_date=date.fromisoformat(form["due_date"]) if form.get("due_date") else None,
    )
    for name in (form.get("option_1", ""), form.get("option_2", "")):
        if name:
            session.add(ADROption(program_id=program.id, adr_id=adr.id or 0, name=name))
    session.commit()
    return RedirectResponse(f"/adr/{adr.code}", status_code=303)


@router.get("/adr/{code}", response_class=HTMLResponse)
def detail(
    request: Request,
    code: str,
    error: str = "",
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    adr = _adr(session, program, code)
    assert program.id is not None
    view = build_view(session, program.id)
    options = session.exec(
        select(ADROption).where(ADROption.adr_id == adr.id).order_by(col(ADROption.id))
    ).all()
    history = session.exec(
        select(ADRStatusChange).where(ADRStatusChange.adr_id == adr.id).order_by(col(ADRStatusChange.id))
    ).all()
    elements = [
        e for e in view.ctx.arch_elements if adr.id in view.ctx.linked_ids("arch_element", e.id, "adr")
    ]
    reqs = [
        r
        for r in view.ctx.requirements
        if any(e.id in view.ctx.linked_ids("requirement", r.id, "arch_element") for e in elements)
    ]
    element_links: dict[int, int] = {}
    for link in session.exec(select(TraceLink).where(TraceLink.program_id == program.id)).all():
        ends = {(link.src_type, link.src_id), (link.dst_type, link.dst_id)}
        if ("adr", adr.id) in ends:
            for kind, other_id in ends:
                if kind == "arch_element" and link.id is not None:
                    element_links[other_id] = link.id
    others = [a for a in view.ctx.adrs if a.id != adr.id]
    superseded_by = next((a for a in others if a.supersedes_id == adr.id), None)
    ctx = page_context(
        request,
        "adr",
        session,
        view,
        adr=adr,
        options=list(options),
        history=list(history),
        criteria=DA_CRITERIA,
        transitions=sorted(ADR_TRANSITIONS.get(adr.status, set())),
        elements=elements,
        element_links=element_links,
        reqs=reqs,
        alerts=view.results_for("adr", adr.id),
        lookups=lookups_for(session, program),
        others=others,
        superseded_by=superseded_by,
        supersedes=next((a for a in others if a.id == adr.supersedes_id), None),
        error=error,
        totals=_totals(list(options)),
    )
    return render(request, "pages/adr_detail.html", ctx)


@router.get("/adr/{code}/links/arch_element/edit", response_class=HTMLResponse)
def edit_element_links(
    request: Request,
    code: str,
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    """Ventana emergente para elegir los elementos de arquitectura que impacta la ADR."""
    adr = _adr(session, program, code)
    assert program.id is not None
    view = build_view(session, program.id)
    current = {
        f"arch_element:{e.id}"
        for e in view.ctx.arch_elements
        if adr.id in view.ctx.linked_ids("arch_element", e.id, "adr")
    }
    ctx = {
        "title": f"{adr.code} · Architecture element links",
        "subtitle": adr.title,
        "action": f"/adr/{adr.code}/links/arch_element",
        "label": "architecture element",
        "blocks": candidates(session, program.id, ("arch_element",)),
        "current": current,
        "inherited": [],
    }
    return templates.TemplateResponse(request, "partials/_link_picker.html", ctx)


@router.post("/adr/{code}/links/arch_element", status_code=204)
async def save_element_links(
    request: Request,
    code: str,
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Response:
    adr = _adr(session, program, code)
    assert program.id is not None and adr.id is not None
    form = await request.form()
    try:
        wanted = parse_targets(
            session, program.id, ("arch_element",), [str(v) for v in form.getlist("target")]
        )
    except LinkTargetError as exc:
        raise HTTPException(exc.status, str(exc) or None) from exc
    sync_links(session, program.id, ("adr", adr.id), ("arch_element",), wanted, frozenset({"arch_element"}))
    return Response(status_code=204, headers={"HX-Trigger": "ea:saved"})


def _totals(options: list[ADROption]) -> dict[int, int]:
    return {o.id or 0: sum(int(v) for v in (o.scores or {}).values()) for o in options}


@router.post("/adr/{code}/status")
def set_status(
    code: str,
    to: str = Form(...),
    note: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    adr = _adr(session, program, code)
    try:
        change_adr_status(session, adr, to, note)
        session.commit()
    except GovernanceError as exc:
        session.rollback()
        return RedirectResponse(f"/adr/{code}?error={quote(str(exc))}", status_code=303)
    return RedirectResponse(f"/adr/{code}", status_code=303)


@router.post("/adr/{code}/supersedes")
def set_supersedes(
    code: str,
    supersedes_code: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    adr = _adr(session, program, code)
    old = _adr(session, program, supersedes_code) if supersedes_code else None
    if old is not None and old.id == adr.id:
        return RedirectResponse(
            f"/adr/{code}?error={quote('An ADR cannot supersede itself.')}", status_code=303
        )
    adr.supersedes_id = old.id if old else None
    session.add(adr)
    session.commit()
    return RedirectResponse(f"/adr/{code}", status_code=303)


@router.post("/adr/{code}/options")
def add_option(
    code: str,
    name: str = Form(...),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    adr = _adr(session, program, code)
    if name.strip():
        session.add(ADROption(program_id=adr.program_id, adr_id=adr.id or 0, name=name.strip()))
        session.commit()
    return RedirectResponse(f"/adr/{code}#options", status_code=303)


@router.post("/adr/option/{option_id}/score/{criterion}", response_class=HTMLResponse)
def score(
    request: Request,
    option_id: int,
    criterion: str,
    value: str = Form(""),
    session: Session = Depends(get_session),
) -> Any:
    """Puntuación 1-5 de una opción contra un criterio de la Design Authority (guía §5.2)."""
    opt = session.get(ADROption, option_id)
    if opt is None or criterion not in dict(DA_CRITERIA):
        raise HTTPException(404)
    scores = dict(opt.scores or {})
    if value.isdigit() and 1 <= int(value) <= 5:
        scores[criterion] = int(value)
    elif value == "":
        scores.pop(criterion, None)
    else:
        raise HTTPException(422, "Score must be 1-5")
    opt.scores = scores
    session.add(opt)
    session.commit()
    session.refresh(opt)
    options = session.exec(
        select(ADROption).where(ADROption.adr_id == opt.adr_id).order_by(col(ADROption.id))
    ).all()
    return templates.TemplateResponse(
        request,
        "partials/tradeoff_matrix.html",
        {
            "options": list(options),
            "criteria": DA_CRITERIA,
            "totals": _totals(list(options)),
        },
    )


@router.post("/adr/option/{option_id}/choose")
def choose(option_id: int, session: Session = Depends(get_session)) -> Any:
    opt = session.get(ADROption, option_id)
    if opt is None:
        raise HTTPException(404)
    for o in session.exec(select(ADROption).where(ADROption.adr_id == opt.adr_id)).all():
        o.chosen = o.id == opt.id
        session.add(o)
    adr = session.get(ADR, opt.adr_id)
    session.commit()
    assert adr is not None
    return RedirectResponse(f"/adr/{adr.code}#options", status_code=303)
