"""Entregar y cerrar: Operational Readiness (§10), As-built y handover (Anexo A) y Lessons learned."""

from __future__ import annotations

import json
from datetime import date
from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlmodel import Session, col, select

from app.config import get_settings
from app.content.guide import EA_DOD
from app.db import get_session
from app.models import Baseline, ChecklistItem, HandoverItem, ORRCheck, Program, RAIDItem
from app.models.enums import ADR_OPEN, MonitorStatus, RAIDType
from app.routers.deps import require_program
from app.services.baselines import diff_payloads, snapshot_payload
from app.services.fields import lookups_for
from app.services.governance import build_view
from app.services.ids import next_code
from app.web import page_context, render, templates

router = APIRouter()

ORR_CORE = ["Monitoring", "Backup", "Support", "Access", "Capacity", "Runbooks", "Skills"]  # guía §10


# ------------------------------------------------------------------ Operational Readiness


@router.get("/orr", response_class=HTMLResponse)
def orr(
    request: Request, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    assert program.id is not None
    view = build_view(session, program.id)
    checks = sorted(
        view.ctx.orr_checks,
        key=lambda c: (
            c.dimension not in ORR_CORE,
            ORR_CORE.index(c.dimension) if c.dimension in ORR_CORE else 0,
            c.id or 0,
        ),
    )
    counts = {r: sum(1 for c in checks if c.status == r) for r in ("green", "amber", "red", "grey")}
    blockers = [r for r in view.results if "G5" in r.blocks_gates]
    ctx = page_context(
        request,
        "orr",
        session,
        view,
        checks=checks,
        counts=counts,
        blockers=blockers,
        lookups=lookups_for(session, program),
        core=ORR_CORE,
    )
    return render(request, "pages/orr.html", ctx)


@router.post("/orr/new")
def orr_new(
    dimension: str = Form(""),
    criterion: str = Form(""),
    owner: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if not dimension.strip() or not criterion.strip():
        return RedirectResponse(
            "/orr?error=A%20check%20needs%20a%20dimension%20and%20a%20criterion.", status_code=303
        )
    session.add(
        ORRCheck(
            program_id=program.id or 0,
            dimension=dimension.strip(),
            criterion=criterion.strip(),
            owner=owner.strip(),
            status="grey",
        )
    )
    session.commit()
    return RedirectResponse("/orr", status_code=303)


# ------------------------------------------------------------------ As-built y handover


def _baseline_options(session: Session, program_id: int) -> list[Baseline]:
    return list(
        session.exec(
            select(Baseline).where(Baseline.program_id == program_id).order_by(col(Baseline.version))
        ).all()
    )


@router.get("/handover", response_class=HTMLResponse)
def handover(
    request: Request,
    a: str = "",
    b: str = "current",
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    """Conciliación baseline vs implantado: diff entre baselines o con el estado actual."""
    assert program.id is not None
    view = build_view(session, program.id)
    baselines = _baseline_options(session, program.id)
    by_version = {str(bl.version): bl for bl in baselines}
    left = by_version.get(a) or (baselines[0] if baselines else None)
    current = snapshot_payload(session, program.id)
    right_payload = current if b == "current" or b not in by_version else json.loads(by_version[b].payload)
    diff = diff_payloads(json.loads(left.payload), right_payload) if left else None
    items = session.exec(
        select(HandoverItem).where(HandoverItem.program_id == program.id).order_by(col(HandoverItem.id))
    ).all()
    open_adrs = [x for x in view.ctx.adrs if x.status in ADR_OPEN]
    open_raid = [
        i for i in view.ctx.raid_items if i.type in (RAIDType.RISK, RAIDType.ISSUE) and not i.is_closed
    ]
    dod = {
        c.item_key: c.checked
        for c in session.exec(
            select(ChecklistItem).where(
                ChecklistItem.program_id == program.id, ChecklistItem.checklist == "ea_dod"
            )
        ).all()
    }
    changes = [i for i in view.ctx.raid_items if i.type == RAIDType.CHANGE]
    ctx = page_context(
        request,
        "handover",
        session,
        view,
        baselines=baselines,
        left=left,
        b=b if b in by_version else "current",
        diff=diff,
        items=list(items),
        open_adrs=open_adrs,
        open_raid=open_raid,
        changes=changes,
        dod=[{"key": k, "text": t, "checked": dod.get(k, False)} for k, t in enumerate(EA_DOD)],
        lookups=lookups_for(session, program),
    )
    return render(request, "pages/handover.html", ctx)


@router.post("/handover/item")
def handover_item(
    kind: str = Form("TechDebt"),
    title: str = Form(""),
    impact: str = Form(""),
    estimated_cost: str = Form(""),
    receiving_owner: str = Form(""),
    review_date: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if kind not in {"TechDebt", "Deviation", "Transfer"} or not title.strip():
        return RedirectResponse("/handover?error=Choose%20a%20type%20and%20a%20title.#items", status_code=303)
    try:
        review = date.fromisoformat(review_date) if review_date else None
    except ValueError:
        review = None
    session.add(
        HandoverItem(
            program_id=program.id or 0,
            kind=kind,
            title=title.strip(),
            impact=impact.strip(),
            estimated_cost=estimated_cost.strip(),
            receiving_owner=receiving_owner.strip(),
            review_date=review,
        )
    )
    session.commit()
    return RedirectResponse("/handover#items", status_code=303)


@router.post("/handover/dod/{key}", response_class=HTMLResponse)
def toggle_dod(
    request: Request,
    key: int,
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if not 0 <= key < len(EA_DOD):
        raise HTTPException(404)
    item = session.exec(
        select(ChecklistItem).where(
            ChecklistItem.program_id == program.id,
            ChecklistItem.checklist == "ea_dod",
            ChecklistItem.item_key == key,
        )
    ).first()
    if item is None:
        item = ChecklistItem(program_id=program.id or 0, checklist="ea_dod", item_key=key)
    item.checked = not item.checked
    session.add(item)
    session.commit()
    done = len(
        session.exec(
            select(ChecklistItem).where(
                ChecklistItem.program_id == program.id,
                ChecklistItem.checklist == "ea_dod",
                ChecklistItem.checked == True,  # noqa: E712
                col(ChecklistItem.item_key) < len(EA_DOD),
            )
        ).all()
    )
    ctx = {"c": {"key": key, "text": EA_DOD[key], "checked": item.checked}, "checklist": "ea_dod"}
    body = templates.get_template("partials/_dod_item.html").render(ctx)
    counter = templates.get_template("partials/_dod_count.html").render(
        done=done, total=len(EA_DOD), oob=True
    )
    return HTMLResponse(body + counter)


# ------------------------------------------------------------------ Lessons learned


@router.get("/lessons", response_class=HTMLResponse)
def lessons(
    request: Request,
    q: str = "",
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    mine = session.exec(
        select(RAIDItem)
        .where(RAIDItem.program_id == program.id, RAIDItem.type == RAIDType.LESSON)
        .order_by(col(RAIDItem.code))
    ).all()
    others_q = select(RAIDItem).where(RAIDItem.program_id != program.id, RAIDItem.type == RAIDType.LESSON)
    others = list(session.exec(others_q.order_by(col(RAIDItem.id))).all())
    if q:
        ql = q.lower()
        others = [o for o in others if ql in " ".join((o.title, o.context, o.recommendation)).lower()]
    names = {p.id: p.name for p in session.exec(select(Program)).all()}
    ctx = page_context(
        request,
        "lessons",
        session,
        mine=list(mine),
        others=others,
        names=names,
        q=q,
        lookups=lookups_for(session, program),
    )
    return render(request, "pages/lessons.html", ctx)


@router.post("/lessons/new")
def lesson_new(
    title: str = Form(""),
    context: str = Form(""),
    decision_taken: str = Form(""),
    result: str = Form(""),
    recommendation: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if not title.strip():
        return RedirectResponse("/lessons?error=A%20lesson%20needs%20a%20title.", status_code=303)
    assert program.id is not None
    session.add(
        RAIDItem(
            program_id=program.id,
            type=RAIDType.LESSON,
            code=next_code(session, program.id, "LL"),
            title=title.strip(),
            context=context.strip(),
            decision_taken=decision_taken.strip(),
            result=result.strip(),
            recommendation=recommendation.strip(),
            owner=get_settings().current_user,
            date_added=date.today(),
            monitor_status=MonitorStatus.CLOSED,
        )
    )
    session.commit()
    return RedirectResponse("/lessons", status_code=303)


@router.post("/lessons/{item_id}/reuse")
def lesson_reuse(
    item_id: int, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    """Reutilizar una lección de otro programa: se copia en este como punto de partida."""
    src = session.get(RAIDItem, item_id)
    if src is None or src.type != RAIDType.LESSON or src.program_id == program.id:
        raise HTTPException(404)
    origin = session.get(Program, src.program_id)
    assert program.id is not None
    session.add(
        RAIDItem(
            program_id=program.id,
            type=RAIDType.LESSON,
            code=next_code(session, program.id, "LL"),
            title=src.title,
            context=f"[Reused from {origin.name if origin else 'another program'}] {src.context}",
            decision_taken=src.decision_taken,
            result=src.result,
            recommendation=src.recommendation,
            owner=get_settings().current_user,
            date_added=date.today(),
            monitor_status=MonitorStatus.OPEN,
        )
    )
    session.commit()
    return RedirectResponse("/lessons", status_code=303)
