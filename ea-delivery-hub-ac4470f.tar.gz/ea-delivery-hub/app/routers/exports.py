"""Descarga de plantillas: GET /export/{tid}?mode=filled|blank&lang=en|es."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import Response
from sqlmodel import Session

from app.db import get_session
from app.services.exports.base import filename, make_context
from app.services.exports.registry import MEDIA, TEMPLATES
from app.web import current_program

router = APIRouter()


@router.get("/export/{tid}")
def export(request: Request, tid: str, mode: str = "filled", lang: str = "", item: str = "",
           session: Session = Depends(get_session)) -> Any:  # fmt: skip
    tpl = TEMPLATES.get(tid)
    if tpl is None or mode not in {"filled", "blank"} or lang not in {"", "en", "es"}:
        raise HTTPException(404)
    program = current_program(session, request) if mode == "filled" else None
    if mode == "filled" and program is None:
        raise HTTPException(404, "No program to export")
    ctx = make_context(session, program, mode, lang or None)
    ctx.item = item or None
    artifact = tpl.artifact
    if item and tpl.per_item:
        artifact = item if item.upper().startswith(tpl.artifact.upper()) else f"{tpl.artifact}-{item}"
    try:
        data = tpl.build(ctx)
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc
    name = filename(ctx, artifact, tpl.fmt)
    return Response(
        data,
        media_type=MEDIA[tpl.fmt],
        headers={"Content-Disposition": f'attachment; filename="{name}"'},
    )
