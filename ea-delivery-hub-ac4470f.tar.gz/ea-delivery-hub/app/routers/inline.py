"""Edición en línea (htmx) de celdas de las tablas tipo hoja de cálculo.

GET  /edit/{kind}/{id}/{field} -> editor de la celda
GET  /edit/{kind}/{id}/{field}/cancel -> la celda/fila original, sin guardar ni recargar la página
POST /edit/{kind}/{id}/{field} -> valida, guarda (AuditLog) y devuelve la fila o la celda
re-renderizada + badges/alertas recalculados (hx-swap-oob).
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse
from sqlmodel import Session

from app.db import get_session
from app.models import Program
from app.services.fields import EDITABLE, FieldError, FieldSpec, display, lookups_for, parse_value
from app.services.governance import build_view
from app.web import templates

router = APIRouter()


def _load(session: Session, kind: str, obj_id: int, field: str) -> tuple[Any, FieldSpec, str]:
    if kind not in EDITABLE:
        raise HTTPException(404)
    model, scope, fields = EDITABLE[kind]
    if field not in fields:
        raise HTTPException(404)
    obj = session.get(model, obj_id)
    if obj is None:
        raise HTTPException(404)
    return obj, fields[field], scope


def _editor(
    request: Request,
    session: Session,
    kind: str,
    obj: Any,
    field: str,
    spec: FieldSpec,
    error: str = "",
    raw: str | None = None,
) -> HTMLResponse:
    _, scope, _ = EDITABLE[kind]
    value = getattr(obj, field)
    ctx = {
        "kind": kind,
        "obj": obj,
        "field": field,
        "spec": spec,
        "value": raw if raw is not None else ("" if value is None else value),
        "options": spec.options(session, obj) if spec.options else [],
        "target": "closest tr" if scope == "row" else "closest td",
        "error": error,
    }
    return templates.TemplateResponse(request, "partials/_cell_editor.html", ctx)


@router.get("/edit/{kind}/{obj_id}/{field}", response_class=HTMLResponse)
def edit_cell(
    request: Request, kind: str, obj_id: int, field: str, session: Session = Depends(get_session)
) -> HTMLResponse:
    obj, spec, _ = _load(session, kind, obj_id, field)
    return _editor(request, session, kind, obj, field, spec)


@router.get("/edit/{kind}/{obj_id}/{field}/cancel", response_class=HTMLResponse)
def cancel_edit(
    request: Request, kind: str, obj_id: int, field: str, session: Session = Depends(get_session)
) -> HTMLResponse:
    obj, _, scope = _load(session, kind, obj_id, field)
    return render_saved(request, session, kind, obj, field, scope)


@router.post("/edit/{kind}/{obj_id}/{field}", response_class=HTMLResponse)
def save_cell(
    request: Request,
    kind: str,
    obj_id: int,
    field: str,
    value: str = Form(""),
    session: Session = Depends(get_session),
) -> HTMLResponse:
    obj, spec, scope = _load(session, kind, obj_id, field)
    if kind == "meeting_decision":
        from app.models import Meeting

        meeting = session.get(Meeting, obj.meeting_id)
        if meeting is not None and meeting.status == "Closed":
            raise HTTPException(409, "The Design Authority session is closed.")
    try:
        parsed = parse_value(field, spec, value, session, obj)
    except FieldError as exc:
        return _editor(request, session, kind, obj, field, spec, error=str(exc), raw=value)
    setattr(obj, field, parsed)
    session.add(obj)
    session.commit()
    session.refresh(obj)
    response = render_saved(request, session, kind, obj, field, scope)
    # app.js escucha este evento y refresca el contenido principal sin recargar la página
    response.headers["HX-Trigger"] = "ea:saved"
    return response


def render_saved(
    request: Request, session: Session, kind: str, obj: Any, field: str, scope: str
) -> HTMLResponse:
    program = session.get(Program, obj.id if isinstance(obj, Program) else obj.program_id)
    assert program is not None and program.id is not None
    view = build_view(session, program.id)
    lookups = lookups_for(session, program)
    ctx: dict[str, Any] = {
        "view": view,
        "lookups": lookups,
        "badges": view.badges,
        "obj": obj,
        "kind": kind,
        "field": field,
        "content": display(obj, field, lookups),
    }
    if scope == "row":
        template = {"raid": "partials/raid_row.html", "dependency": "partials/dependency_row.html"}[kind]
        if kind == "raid":
            from app.routers.raid import columns_for, updates_by_item

            ctx["item"] = obj
            ctx["columns"] = columns_for(obj.type)
            ctx["updates"] = updates_by_item(session, program.id)
        else:
            ctx["dep"] = obj
    else:
        template = "partials/_cell_saved.html"
    body = templates.get_template(template).render(ctx)
    oob = templates.get_template("partials/_badges_oob.html").render(ctx)
    return HTMLResponse(body + oob)
