"""Stakeholders, mapa poder/interés, matriz RACI con validación en vivo y plan de comunicación."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlmodel import Session, col, select

from app.db import get_session
from app.models import Program, RACIActivity, RACIAssignment, RACIRole
from app.models.enums import RACIValue
from app.routers.deps import require_program
from app.services.fields import lookups_for
from app.services.governance import ProgramView, build_view
from app.web import page_context, render, templates

router = APIRouter()

TABS = (
    ("directory", "Directory"),
    ("map", "Power / Interest"),
    ("raci", "RACI Matrix"),
    ("comms", "Comms Plan"),
)
RACI_CHOICES = ["", *[v.value for v in RACIValue]]


def raci_data(session: Session, program_id: int) -> dict[str, Any]:
    roles = session.exec(
        select(RACIRole).where(RACIRole.program_id == program_id).order_by(col(RACIRole.order))
    ).all()
    acts = session.exec(
        select(RACIActivity).where(RACIActivity.program_id == program_id).order_by(col(RACIActivity.order))
    ).all()
    asg = session.exec(select(RACIAssignment).where(RACIAssignment.program_id == program_id)).all()
    return {
        "roles": list(roles),
        "activities": list(acts),
        "cells": {(a.activity_id, a.role_id): a for a in asg},
    }


@router.get("/stakeholders", response_class=HTMLResponse)
def stakeholders(
    request: Request,
    tab: str = "directory",
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if tab not in dict(TABS):
        raise HTTPException(404)
    assert program.id is not None
    view = build_view(session, program.id)
    people = sorted(view.ctx.stakeholders, key=lambda s: (-s.influence, s.name))
    ctx = page_context(
        request,
        "stakeholders",
        session,
        view,
        tab=tab,
        tabs=TABS,
        people=people,
        lookups=lookups_for(session, program),
        raci=raci_data(session, program.id),
        choices=RACI_CHOICES,
        stk_alerts=[a for a in view.alerts if a.result.rule_id == "STK-01"],
    )
    return render(request, "pages/stakeholders.html", ctx)


def _raci_row_response(
    request: Request, session: Session, view: ProgramView, act: RACIActivity
) -> HTMLResponse:
    assert act.program_id is not None
    ctx = {"view": view, "badges": view.badges, "act": act, "raci": raci_data(session, act.program_id)}
    body = templates.get_template("partials/raci_row.html").render(ctx)
    oob = templates.get_template("partials/_badges_oob.html").render(ctx)
    return HTMLResponse(body + oob)


@router.get("/raci/{activity_id}/{role_id}", response_class=HTMLResponse)
def raci_editor(
    request: Request, activity_id: int, role_id: int, session: Session = Depends(get_session)
) -> Any:
    cell = session.exec(
        select(RACIAssignment).where(
            RACIAssignment.activity_id == activity_id, RACIAssignment.role_id == role_id
        )
    ).first()
    return templates.TemplateResponse(
        request,
        "partials/_raci_editor.html",
        {
            "activity_id": activity_id,
            "role_id": role_id,
            "value": cell.value if cell else "",
            "qualifier": cell.qualifier if cell else "",
            "choices": RACI_CHOICES,
        },
    )


@router.post("/raci/{activity_id}/{role_id}", response_class=HTMLResponse)
def raci_save(
    request: Request,
    activity_id: int,
    role_id: int,
    value: str = Form(""),
    qualifier: str = Form(""),
    session: Session = Depends(get_session),
) -> Any:
    act = session.get(RACIActivity, activity_id)
    role = session.get(RACIRole, role_id)
    if act is None or role is None or act.program_id != role.program_id:
        raise HTTPException(404)
    if value not in RACI_CHOICES:
        raise HTTPException(422, "Invalid RACI value")
    cell = session.exec(
        select(RACIAssignment).where(
            RACIAssignment.activity_id == activity_id, RACIAssignment.role_id == role_id
        )
    ).first()
    if not value:
        if cell is not None:
            session.delete(cell)
    elif cell is None:
        session.add(
            RACIAssignment(
                program_id=act.program_id,
                activity_id=activity_id,
                role_id=role_id,
                value=value,
                qualifier=qualifier.strip(),
            )
        )
    else:
        cell.value = value
        cell.qualifier = qualifier.strip()
        session.add(cell)
    session.commit()
    return _raci_row_response(request, session, build_view(session, act.program_id), act)


@router.post("/raci/activity")
def raci_add_activity(
    name: str = Form(...),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if name.strip():
        count = len(session.exec(select(RACIActivity).where(RACIActivity.program_id == program.id)).all())
        session.add(RACIActivity(program_id=program.id or 0, name=name.strip(), order=count))
        session.commit()
    return RedirectResponse("/stakeholders?tab=raci", status_code=303)
