"""Placeholders de las pantallas que aún no existen, con la fase en la que llegan."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from sqlmodel import Session

from app.db import get_session
from app.navigation import find_item
from app.web import active_features, page_context, templates

router = APIRouter()


@router.get("/{slug}", response_class=HTMLResponse)
def placeholder(request: Request, slug: str, session: Session = Depends(get_session)) -> HTMLResponse:
    item = find_item(slug)
    if item is None or (item.feature and item.feature not in active_features()):
        raise HTTPException(status_code=404)
    return templates.TemplateResponse(
        request, "pages/placeholder.html", page_context(request, slug, session, item=item)
    )
