"""Acciones del shell: selector de programa activo y buscador global (Ctrl+K)."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import or_
from sqlmodel import Session, col, select

from app.db import get_session
from app.models import ADR, Dependency, Goal, Objective, Program, RAIDItem, Requirement
from app.services.governance import entity_url
from app.web import PROGRAM_COOKIE, current_program, templates

router = APIRouter()


@router.post("/program/select")
def select_program(
    request: Request, program_id: int = Form(...), session: Session = Depends(get_session)
) -> Any:
    nxt = request.query_params.get("next", "")
    target = (
        nxt if nxt.startswith("/") and not nxt.startswith("//") else (request.headers.get("referer") or "/")
    )
    response = RedirectResponse(target, status_code=303)
    if session.get(Program, program_id) is not None:
        response.set_cookie(
            PROGRAM_COOKIE, str(program_id), httponly=True, samesite="lax", max_age=60 * 60 * 24 * 365
        )
    return response


@router.get("/search", response_class=HTMLResponse)
def search(request: Request, q: str = "", session: Session = Depends(get_session)) -> Any:
    program = current_program(session, request)
    q = q.strip()
    hits: list[dict[str, str]] = []
    if program is not None and len(q) >= 2:
        like = f"%{q}%"
        pid = program.id

        def run(model: Any, kind: str, title_attr: str, url_type: str) -> None:
            title = getattr(model, title_attr)
            stmt = select(model).where(
                model.program_id == pid, or_(col(model.code).ilike(like), col(title).ilike(like))
            )
            for obj in session.exec(stmt.limit(8)).all():
                hits.append(
                    {
                        "code": obj.code,
                        "title": getattr(obj, title_attr),
                        "kind": kind,
                        "url": entity_url(url_type, obj.code, obj),
                    }
                )

        run(RAIDItem, "RAID", "title", "raid")
        run(Requirement, "Requirement", "statement", "requirement")
        run(ADR, "ADR", "title", "adr")
        run(Dependency, "Dependency", "title", "dependency")
        goal_models: tuple[tuple[Any, str], ...] = ((Goal, "title"), (Objective, "objective"))
        for model, attr in goal_models:
            for obj in session.exec(
                select(model)
                .where(
                    model.program_id == pid,
                    or_(col(model.code).ilike(like), col(getattr(model, attr)).ilike(like)),
                )
                .limit(5)
            ).all():
                hits.append(
                    {
                        "code": obj.code,
                        "title": getattr(obj, attr),
                        "kind": "Goal map",
                        "url": f"/goals#{obj.code}",
                    }
                )
    return templates.TemplateResponse(request, "partials/_search_results.html", {"hits": hits[:20], "q": q})
