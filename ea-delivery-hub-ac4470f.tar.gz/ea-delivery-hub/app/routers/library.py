"""Biblioteca de plantillas (§7.16) y Playbook del EA (§7.17, Markdown editable en app/content/playbook)."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from sqlmodel import Session

from app.config import APP_DIR
from app.content.template_catalog import CATALOG
from app.db import get_session
from app.models.enums import PHASE_NAMES
from app.services.exports.registry import TEMPLATES
from app.services.markdown import render as render_md
from app.web import page_context, render

router = APIRouter()
PLAYBOOK_DIR = APP_DIR / "content" / "playbook"


@router.get("/templates", response_class=HTMLResponse)
def library(
    request: Request, phase: str = "", forum: str = "", fmt: str = "", session: Session = Depends(get_session)
) -> Any:
    entries = list(CATALOG)
    if phase.isdigit():
        entries = [e for e in entries if int(phase) in e.phases]
    if forum:
        entries = [e for e in entries if e.forum == forum]
    if fmt:
        entries = [e for e in entries if fmt.upper() in e.formats]
    forums = sorted({e.forum for e in CATALOG})
    ctx = page_context(
        request,
        "templates",
        session,
        entries=entries,
        forums=forums,
        f_phase=phase,
        f_forum=forum,
        f_fmt=fmt,
        phase_names=PHASE_NAMES,
        registry=TEMPLATES,
    )
    return render(request, "pages/library.html", ctx)


def _pages() -> list[dict[str, Any]]:
    pages = []
    for path in sorted(PLAYBOOK_DIR.glob("*.md")):
        text = path.read_text(encoding="utf-8")
        meta: dict[str, str] = {}
        m = re.match(r"^---\n(.*?)\n---\n", text, re.S)
        if m:
            for line in m.group(1).splitlines():
                k, _, v = line.partition(":")
                meta[k.strip()] = v.strip()
            text = text[m.end() :]
        pages.append({"slug": path.stem, "title": meta.get("title", path.stem), "body": text, "path": path})
    return pages


@router.get("/playbook", response_class=HTMLResponse)
@router.get("/playbook/{slug}", response_class=HTMLResponse)
def playbook(request: Request, slug: str = "", session: Session = Depends(get_session)) -> Any:
    pages = _pages()
    if not pages:
        raise HTTPException(404)
    page = next((p for p in pages if p["slug"] == slug), None) if slug else pages[0]
    if page is None:
        raise HTTPException(404)
    toc = re.findall(r"^#\s+(.+)$", page["body"], re.M)
    ctx = page_context(
        request,
        "playbook",
        session,
        pages=pages,
        page=page,
        html=render_md(page["body"]),
        toc=[(t, re.sub(r"[^a-z0-9]+", "-", t.lower()).strip("-")) for t in toc],
        source=Path(page["path"]).relative_to(APP_DIR.parent).as_posix(),
    )
    return render(request, "pages/playbook.html", ctx)
