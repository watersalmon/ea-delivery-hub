"""Gates G0-G6 (guía §4) con bloqueo por reglas rojas y waiver, y Roadmap por work packages."""

from __future__ import annotations

from datetime import date, timedelta
from typing import Any
from urllib.parse import quote

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlmodel import Session, col, select

from app.config import get_settings
from app.db import get_session
from app.models import GateCriterion, Program, WorkPackage, Workstream
from app.models.enums import ADRStatus
from app.routers.deps import require_program
from app.rules import gate_blockers
from app.services.fields import lookups_for
from app.services.governance import build_view
from app.services.governance_ops import GovernanceError, pass_gate, set_waiver
from app.services.ids import next_code
from app.web import page_context, render

router = APIRouter()


def roadmap_chart(wps: list[WorkPackage], today: date) -> dict[str, Any]:
    """Gantt sencillo en SVG por meses (servidor, sin dependencias)."""
    dated = [w for w in wps if w.start and w.end]
    if not dated:
        return {"rows": [], "months": [], "w": 0, "h": 0}
    start = min(w.start for w in dated if w.start is not None).replace(day=1)
    end = max(w.end for w in dated if w.end is not None)
    months = []
    cur = start
    while cur <= end:
        months.append(cur)
        cur = (cur.replace(day=28) + timedelta(days=4)).replace(day=1)
    total_days = max(
        (months[-1].replace(day=28) + timedelta(days=4)).replace(day=1) - start, timedelta(days=1)
    ).days
    label_w, width, row_h = 260, 760, 26

    def x(d: date) -> float:
        return label_w + width * (d - start).days / total_days

    rows = []
    for i, w in enumerate(dated):
        assert w.start is not None and w.end is not None
        rows.append({"wp": w, "y": 30 + i * row_h, "x1": x(w.start), "x2": max(x(w.end), x(w.start) + 4)})
    return {
        "rows": rows,
        "months": [{"x": x(m), "label": m.strftime("%b %y")} for m in months],
        "today": x(today) if start <= today <= end else None,
        "w": label_w + width + 10,
        "h": 40 + len(rows) * row_h,
        "label_w": label_w,
    }


@router.get("/gates", response_class=HTMLResponse)
def gates(
    request: Request,
    error: str = "",
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    assert program.id is not None
    view = build_view(session, program.id)
    gate_list = sorted(view.ctx.gates, key=lambda g: g.phase)
    criteria = session.exec(select(GateCriterion).where(GateCriterion.program_id == program.id)).all()
    by_gate: dict[int, list[GateCriterion]] = {}
    for c in criteria:
        by_gate.setdefault(c.gate_id, []).append(c)
    raw = {
        g.code: [r for r in view.results if r.severity == "red" and g.code in r.blocks_gates]
        for g in gate_list
    }
    blockers = {g.code: gate_blockers(view.ctx, view.results, g.code) for g in gate_list}
    approved = [a for a in view.ctx.adrs if a.status == ADRStatus.APPROVED]
    wps = list(
        session.exec(
            select(WorkPackage).where(WorkPackage.program_id == program.id).order_by(col(WorkPackage.start))
        ).all()
    )
    workstreams = session.exec(select(Workstream).where(Workstream.program_id == program.id)).all()
    ctx = page_context(
        request,
        "gates",
        session,
        view,
        gate_list=gate_list,
        by_gate=by_gate,
        raw=raw,
        blockers=blockers,
        approved=approved,
        wps=wps,
        chart=roadmap_chart(wps, date.today()),
        workstreams=workstreams,
        lookups=lookups_for(session, program),
        error=error,
        adr_codes={a.id: a.code for a in view.ctx.adrs},
    )
    return render(request, "pages/gates.html", ctx)


@router.post("/gates/{code}/pass")
def do_pass(
    code: str, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    assert program.id is not None
    try:
        pass_gate(session, program.id, code, approver=get_settings().current_user)
        session.commit()
    except GovernanceError as exc:
        session.rollback()
        return RedirectResponse(f"/gates?error={quote(str(exc))}#{code}", status_code=303)
    return RedirectResponse(f"/gates#{code}", status_code=303)


@router.post("/gates/{code}/waiver")
def do_waiver(
    code: str,
    adr_id: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    assert program.id is not None
    try:
        set_waiver(session, program.id, code, int(adr_id) if adr_id.isdigit() else None)
        session.commit()
    except GovernanceError as exc:
        session.rollback()
        return RedirectResponse(f"/gates?error={quote(str(exc))}#{code}", status_code=303)
    return RedirectResponse(f"/gates#{code}", status_code=303)


@router.post("/roadmap/new")
def new_wp(
    name: str = Form(""),
    start: str = Form(""),
    end: str = Form(""),
    workstream_id: str = Form(""),
    milestone: str = Form(""),
    transition_state: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    assert program.id is not None
    if not name.strip():
        return RedirectResponse(
            f"/gates?error={quote('A work package needs a name.')}#roadmap", status_code=303
        )
    try:
        s = date.fromisoformat(start) if start else None
        e = date.fromisoformat(end) if end else s
    except ValueError:
        return RedirectResponse(f"/gates?error={quote('Invalid date.')}#roadmap", status_code=303)
    if s and e and e < s:
        return RedirectResponse(
            f"/gates?error={quote('The end date is before the start date.')}#roadmap", status_code=303
        )
    session.add(
        WorkPackage(
            program_id=program.id,
            code=next_code(session, program.id, "WP"),
            name=name.strip(),
            start=s,
            end=e,
            milestone=milestone == "on",
            transition_state=transition_state.strip(),
            workstream_id=int(workstream_id) if workstream_id.isdigit() else None,
        )
    )
    session.commit()
    return RedirectResponse("/gates#roadmap", status_code=303)
