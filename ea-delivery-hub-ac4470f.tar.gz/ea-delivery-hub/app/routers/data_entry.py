"""Altas que completan la captura de datos: workstreams, outcomes, stakeholders, goals/objectives, requisitos,
elementos de arquitectura, evidencias, enlaces de trazabilidad, updates del RAID y roles de la RACI."""

from __future__ import annotations

from datetime import date
from typing import Any
from urllib.parse import quote

from fastapi import APIRouter, Depends, Form, HTTPException
from fastapi.responses import RedirectResponse
from sqlmodel import Session, col, select

from app.db import get_session
from app.models import (
    ArchitectureElement,
    Goal,
    Objective,
    Outcome,
    Program,
    RACIRole,
    RAIDItem,
    RAIDUpdate,
    Requirement,
    Stakeholder,
    TestEvidence,
    TraceLink,
    Workstream,
)
from app.models.enums import ArchitectureView, MoSCoW, NFRCategory, Organization, Stance
from app.routers.deps import require_program
from app.services.ids import next_code

router = APIRouter()


def _back(url: str, error: str = "") -> RedirectResponse:
    sep = "&" if "?" in url else "?"
    return RedirectResponse(f"{url}{sep}error={quote(error)}" if error else url, status_code=303)


def _int(raw: str, lo: int, hi: int, default: int) -> int:
    return int(raw) if raw.isdigit() and lo <= int(raw) <= hi else default


@router.post("/workstreams/new")
def new_workstream(
    name: str = Form(""),
    lead: str = Form(""),
    scope: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    name = name.strip()
    if not name:
        return _back("/admin#workstreams", "A workstream needs a name.")
    exists = session.exec(
        select(Workstream).where(Workstream.program_id == program.id, Workstream.name == name)
    ).first()
    if exists:
        return _back("/admin#workstreams", f"The workstream '{name}' already exists.")
    session.add(Workstream(program_id=program.id or 0, name=name, lead=lead.strip(), scope=scope.strip()))
    session.commit()
    return _back("/admin#workstreams")


@router.post("/outcomes/new")
def new_outcome(
    description: str = Form(""),
    metric: str = Form(""),
    baseline_value: str = Form(""),
    target_value: str = Form(""),
    target_date: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if not description.strip():
        return _back("/goals", "An outcome needs a description.")
    try:
        when = date.fromisoformat(target_date) if target_date else None
    except ValueError:
        return _back("/goals", "Invalid target date.")
    assert program.id is not None
    out = Outcome(
        program_id=program.id,
        code=next_code(session, program.id, "OUT"),
        description=description.strip(),
        metric=metric.strip(),
        baseline_value=baseline_value.strip(),
        target_value=target_value.strip(),
        target_date=when,
    )
    session.add(out)
    session.commit()
    return _back(f"/goals#{out.code}")


@router.post("/stakeholders/new")
def new_stakeholder(
    name: str = Form(""),
    organization: str = Form("Customer"),
    role: str = Form(""),
    influence: str = Form("3"),
    interest: str = Form("3"),
    stance: str = Form("Neutral"),
    is_decision_maker: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if not name.strip():
        return _back("/stakeholders", "A stakeholder needs a name.")
    if organization not in {o.value for o in Organization} or stance not in {s.value for s in Stance}:
        raise HTTPException(422)
    session.add(
        Stakeholder(
            program_id=program.id or 0,
            name=name.strip(),
            organization=organization,
            role=role.strip(),
            influence=_int(influence, 1, 5, 3),
            interest=_int(interest, 1, 5, 3),
            stance=stance,
            is_decision_maker=is_decision_maker == "on",
        )
    )
    session.commit()
    return _back("/stakeholders")


@router.post("/goals/new")
def new_goal(
    title: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if not title.strip():
        return _back("/goals", "A goal needs a title.")
    assert program.id is not None
    session.add(Goal(program_id=program.id, code=next_code(session, program.id, "GOAL"), title=title.strip()))
    session.commit()
    return _back("/goals")


@router.post("/objectives/new")
def new_objective(
    goal_id: str = Form(""),
    objective: str = Form(""),
    acceptance_criteria: str = Form(""),
    approver: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    goal = session.get(Goal, int(goal_id)) if goal_id.isdigit() else None
    if goal is None or goal.program_id != program.id or not objective.strip():
        return _back("/goals", "Choose a goal and describe the objective.")
    assert program.id is not None
    session.add(
        Objective(
            program_id=program.id,
            goal_id=goal.id or 0,
            code=next_code(session, program.id, "OBJ"),
            objective=objective.strip(),
            acceptance_criteria=acceptance_criteria.strip(),
            approver=approver.strip(),
        )
    )
    session.commit()
    return _back("/goals")


@router.post("/requirements/new")
def new_requirement(
    kind: str = Form("FR"),
    statement: str = Form(""),
    priority: str = Form("Must"),
    nfr_category: str = Form(""),
    measurable_criterion: str = Form(""),
    source: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if kind not in {"FR", "NFR"} or priority not in {m.value for m in MoSCoW} or not statement.strip():
        return _back("/rtm", "A requirement needs a type, a priority and a statement.")
    if nfr_category and nfr_category not in {c.value for c in NFRCategory}:
        raise HTTPException(422)
    assert program.id is not None
    req = Requirement(
        program_id=program.id,
        kind=kind,
        code=next_code(session, program.id, "NFR" if kind == "NFR" else "REQ"),
        statement=statement.strip(),
        priority=priority,
        nfr_category=nfr_category if kind == "NFR" else "",
        measurable_criterion=measurable_criterion.strip(),
        source=source.strip(),
        status="Proposed",
    )
    session.add(req)
    session.commit()
    return _back(f"/rtm#{req.code}")


@router.post("/architecture/element/new")
def new_element(
    name: str = Form(""),
    view: str = Form("Technology"),
    hld_ref: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if not name.strip() or view not in {v.value for v in ArchitectureView}:
        return _back("/architecture", "An architecture element needs a name and a view.")
    assert program.id is not None
    session.add(
        ArchitectureElement(
            program_id=program.id,
            code=next_code(session, program.id, "AE"),
            name=name.strip(),
            view=view,
            hld_ref=hld_ref.strip(),
        )
    )
    session.commit()
    return _back("/architecture#elements")


@router.post("/evidence/new")
def new_evidence(
    title: str = Form(""),
    kind: str = Form("Manual test"),
    result: str = Form("Pending"),
    link: str = Form(""),
    requirement_id: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if not title.strip() or result not in {"Pass", "Fail", "Pending"}:
        return _back("/rtm", "Evidence needs a title and a result.")
    assert program.id is not None
    te = TestEvidence(
        program_id=program.id,
        code=next_code(session, program.id, "TE"),
        title=title.strip(),
        kind=kind,
        result=result,
        link=link.strip(),
        evidence_date=date.today(),
    )
    session.add(te)
    session.flush()
    req = session.get(Requirement, int(requirement_id)) if requirement_id.isdigit() else None
    if req is not None and req.program_id == program.id:
        session.add(
            TraceLink(
                program_id=program.id,
                src_type="requirement",
                src_id=req.id or 0,
                dst_type="test_evidence",
                dst_id=te.id or 0,
            )
        )
    session.commit()
    return _back(f"/rtm#{req.code}" if req else "/rtm")


@router.post("/raid/{item_id}/update")
def add_update(
    item_id: int,
    text: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    """Log fechado de la columna Risk Mitigation & Updates (formato '2/21: …' de la captura 1)."""
    item = session.get(RAIDItem, item_id)
    if item is None or item.program_id != program.id:
        raise HTTPException(404)
    if text.strip():
        session.add(
            RAIDUpdate(
                program_id=program.id or 0, raid_item_id=item_id, update_date=date.today(), text=text.strip()
            )
        )
        session.commit()
    from app.services.governance import TAB_BY_TYPE

    return _back(f"/raid?tab={TAB_BY_TYPE.get(item.type, 'risks')}#{item.code}")


@router.post("/raci/role")
def add_role(
    name: str = Form(""), program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    if name.strip():
        roles = session.exec(
            select(RACIRole).where(RACIRole.program_id == program.id).order_by(col(RACIRole.order))
        ).all()
        session.add(RACIRole(program_id=program.id or 0, name=name.strip()[:80], order=len(roles)))
        session.commit()
    return _back("/stakeholders?tab=raci")
