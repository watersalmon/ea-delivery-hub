"""Borrado de registros con confirmación (PDR-011) y baja de enlaces sueltos de la trazabilidad.

GET  /delete/{kind}/{id}  -> qué se borra con el registro, qué relaciones se quitan y qué lo impide
POST /delete/{kind}/{id}  -> vuelve a comprobar y borra; si algo lo impide, vuelve a la confirmación
POST /links/{id}/delete   -> quita un enlace entre dos registros (RTM, ADR, foros)
"""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlmodel import Session

from app.db import get_session
from app.models import Program, TraceLink
from app.routers.deps import require_program
from app.services.deletion import DELETABLE, build_plan, execute
from app.web import PROGRAM_COOKIE, page_context, render

router = APIRouter()


def _safe_next(raw: str, default: str) -> str:
    """Solo rutas internas: evita redirecciones abiertas a otros sitios."""
    return raw if raw.startswith("/") and not raw.startswith("//") else default


def _load(session: Session, program: Program, kind: str, obj_id: int) -> Any:
    spec = DELETABLE.get(kind)
    if spec is None:
        raise HTTPException(404)
    obj = session.get(spec.model, obj_id)
    if obj is None:
        raise HTTPException(404)
    if kind != "program" and obj.program_id != program.id:
        raise HTTPException(404)  # solo registros del programa activo
    return obj


@router.get("/delete/{kind}/{obj_id}", response_class=HTMLResponse)
def confirm_delete(
    request: Request,
    kind: str,
    obj_id: int,
    next: str = "",
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    obj = _load(session, program, kind, obj_id)
    plan = build_plan(session, kind, obj)
    ctx = page_context(
        request, "", session, plan=plan, kind=kind, obj=obj, next=_safe_next(next, plan.back), error=""
    )
    return render(request, "pages/delete_confirm.html", ctx)


@router.post("/delete/{kind}/{obj_id}", response_class=HTMLResponse)
def do_delete(
    request: Request,
    kind: str,
    obj_id: int,
    next: str = Form(""),
    confirm_code: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    obj = _load(session, program, kind, obj_id)
    back = _safe_next(next, DELETABLE[kind].back(obj))
    if kind == "program" and confirm_code.strip() != obj.code:
        plan = build_plan(session, kind, obj)
        ctx = page_context(
            request,
            "",
            session,
            plan=plan,
            kind=kind,
            obj=obj,
            next=back,
            error="Type the program code exactly to confirm.",
        )
        return render(request, "pages/delete_confirm.html", ctx, status_code=422)
    label = DELETABLE[kind].noun
    plan = execute(session, kind, obj)
    if not plan.allowed:
        ctx = page_context(request, "", session, plan=plan, kind=kind, obj=obj, next=back, error="")
        return render(request, "pages/delete_confirm.html", ctx, status_code=409)
    if kind == "program":
        back = "/admin"
    path, _, anchor = back.partition("#")
    sep = "&" if "?" in path else "?"
    url = f"{path}{sep}deleted={quote(f'{label.capitalize()} {plan.label} deleted.')}"
    response = RedirectResponse(url + (f"#{anchor}" if anchor else ""), status_code=303)
    if kind == "program" and request.cookies.get(PROGRAM_COOKIE) == str(obj_id):
        response.delete_cookie(PROGRAM_COOKIE)
    return response


@router.post("/links/{link_id}/delete")
def delete_link(
    link_id: int,
    next: str = Form("/rtm"),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    link = session.get(TraceLink, link_id)
    if link is None or link.program_id != program.id:
        raise HTTPException(404)
    session.delete(link)
    session.commit()
    return RedirectResponse(_safe_next(next, "/rtm"), status_code=303)
