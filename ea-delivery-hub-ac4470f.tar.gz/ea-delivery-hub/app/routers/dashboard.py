"""Dashboard del programa (salud semanal §11.1, gates, riesgos, NFR, checklist §11.2) y portfolio."""

from __future__ import annotations

from datetime import date
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from sqlmodel import Session, col, select

from app.db import get_session
from app.models import ADR, ChecklistItem, Meeting, Program
from app.models.enums import RAIDType, RequirementKind
from app.routers.deps import NoProgramError, require_program
from app.routers.raid import risk_matrix
from app.routers.traceability import build_trace, coverage
from app.services.governance import ProgramView, build_view
from app.web import list_programs, page_context, render, templates

router = APIRouter()

IN_CHARGE = [  # guía §11.2
    "I can explain the project and its architecture in five minutes.",
    "I know the five most important decisions and risks.",
    "Every workstream understands its interfaces and dependencies.",
    "Documents reflect the real decisions, not an old snapshot.",
    "Exceptions have approval and a review date.",
    "The PM and I share the same view of impact and priority.",
    "The customer knows what to decide and when.",
    "Operations is involved before the end.",
]
LOWER_IS_BETTER = {"RTO/RPO", "Performance"}


def nfr_radar(view: ProgramView) -> dict[str, Any]:
    """% de cumplimiento de cada NFR medible frente a su objetivo (100 = objetivo alcanzado)."""
    labels, achieved = [], []
    for r in sorted(view.ctx.requirements, key=lambda x: x.code):
        if r.kind != RequirementKind.NON_FUNCTIONAL or not r.target_value or r.achieved_value is None:
            continue
        if r.nfr_category in LOWER_IS_BETTER:
            pct = 100 * r.target_value / r.achieved_value if r.achieved_value else 0
        else:
            pct = 100 * r.achieved_value / r.target_value
        labels.append(f"{r.code} {r.nfr_category}")
        achieved.append(round(min(pct, 120), 1))
    return {"labels": labels, "achieved": achieved, "target": [100] * len(labels)}


def checklist(session: Session, program_id: int) -> list[dict[str, Any]]:
    saved = {
        c.item_key: c
        for c in session.exec(
            select(ChecklistItem).where(
                ChecklistItem.program_id == program_id, ChecklistItem.checklist == "in_charge"
            )
        ).all()
    }
    return [
        {"key": k, "text": t, "checked": bool(saved.get(k) and saved[k].checked)}
        for k, t in enumerate(IN_CHARGE)
    ]


@router.get("/dashboard", response_class=HTMLResponse)
def dashboard(
    request: Request, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    assert program.id is not None
    view = build_view(session, program.id)
    cov = coverage(build_trace(session, view))
    adrs = sorted(view.ctx.adrs, key=lambda a: a.updated_at, reverse=True)[:5]
    issues = sorted(
        (i for i in view.ctx.raid_items if i.type == RAIDType.ISSUE and not i.is_closed),
        key=lambda i: {"Critical": 0, "High": 1, "Medium": 2}.get(i.severity, 3),
    )
    ctx = page_context(
        request,
        "dashboard",
        session,
        view,
        cov=cov,
        adrs=adrs,
        issues=issues,
        matrix=risk_matrix(view),
        radar=nfr_radar(view),
        checklist=checklist(session, program.id),
        open_risks=sum(1 for i in view.ctx.raid_items if i.type == RAIDType.RISK and not i.is_closed),
    )
    return render(request, "pages/dashboard.html", ctx)


@router.post("/dashboard/checklist/{key}", response_class=HTMLResponse)
def toggle_checklist(
    request: Request,
    key: int,
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if not 0 <= key < len(IN_CHARGE):
        raise HTTPException(404)
    item = session.exec(
        select(ChecklistItem).where(
            ChecklistItem.program_id == program.id,
            ChecklistItem.checklist == "in_charge",
            ChecklistItem.item_key == key,
        )
    ).first()
    if item is None:
        item = ChecklistItem(program_id=program.id or 0, checklist="in_charge", item_key=key, checked=False)
    item.checked = not item.checked
    session.add(item)
    session.commit()
    return templates.TemplateResponse(
        request,
        "partials/_checklist_item.html",
        {"c": {"key": key, "text": IN_CHARGE[key], "checked": item.checked}},
    )


# ------------------------------------------------------------------ portfolio


@router.get("/", response_class=HTMLResponse)
def portfolio(request: Request, sort: str = "rag", session: Session = Depends(get_session)) -> Any:
    programs = list_programs(session)
    if not programs:
        raise NoProgramError
    views = [build_view(session, p.id) for p in programs if p.id is not None]
    today = date.today()
    forums: dict[int, Meeting | None] = {}
    for v in views:
        upcoming = session.exec(
            select(Meeting)
            .where(Meeting.program_id == v.program.id, Meeting.meeting_date >= today)
            .order_by(col(Meeting.meeting_date))
        ).first()
        forums[v.program.id] = upcoming
    order = {"red": 0, "amber": 1, "green": 2}
    keys = {
        "rag": lambda v: (order.get(v.rag, 3), v.program.name),
        "name": lambda v: v.program.name,
        "phase": lambda v: -v.program.phase,
        "alerts": lambda v: -v.red_count,
    }
    views.sort(key=keys.get(sort, keys["rag"]))
    pending_total = sum(v.pending_adrs for v in views)
    critical_total = sum(1 for v in views for r in v.results if r.rule_id == "RAID-01")
    ctx = page_context(
        request,
        "portfolio",
        session,
        views=views,
        forums=forums,
        sort=sort,
        pending_total=pending_total,
        critical_total=critical_total,
        adr_titles={a.id: a.title for a in session.exec(select(ADR)).all()},
    )
    return render(request, "pages/portfolio.html", ctx)
