"""Architecture Brief (§13.1), wizard de los primeros 10 días (§3) y revisión de HLD/LLD (§7.1, §7.2)."""

from __future__ import annotations

import re
import uuid
from datetime import date
from typing import Any
from urllib.parse import quote

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from sqlmodel import Session, col, select

from app.config import get_settings
from app.content.guide import (
    BRIEF_MAX_WORDS,
    BRIEF_SECTIONS,
    FORUMS,
    HLD_QUESTIONS,
    LLD_QUESTIONS,
    REVIEW_ANSWERS,
    TEN_DAY_QUESTIONS,
    TEN_DAYS,
)
from app.db import get_session
from app.models import (
    ArchitectureBrief,
    ArchitectureDiagram,
    Baseline,
    ChecklistItem,
    DesignReview,
    Program,
    RAIDItem,
    ReviewItem,
    Workstream,
)
from app.models.enums import ADR_OPEN, ArchitectureView, MonitorStatus, RAIDType
from app.routers.deps import require_program
from app.services.fields import lookups_for
from app.services.governance import build_view
from app.services.governance_ops import create_adr, create_baseline
from app.services.ids import next_code
from app.web import page_context, render, templates

router = APIRouter()


# ------------------------------------------------------------------ Architecture Brief


def get_brief(session: Session, program_id: int) -> ArchitectureBrief:
    brief = session.exec(select(ArchitectureBrief).where(ArchitectureBrief.program_id == program_id)).first()
    if brief is None:
        brief = ArchitectureBrief(program_id=program_id)
        session.add(brief)
        session.commit()
        session.refresh(brief)
    return brief


def brief_words(brief: ArchitectureBrief) -> int:
    return sum(len(re.findall(r"\w+", getattr(brief, s.key) or "")) for s in BRIEF_SECTIONS)


def brief_suggestions(session: Session, program: Program) -> dict[str, list[str]]:
    """Lo que la app ya sabe del programa, como apoyo para redactar cada sección del Brief."""
    assert program.id is not None
    view = build_view(session, program.id)
    from app.models import Outcome

    outcomes = session.exec(select(Outcome).where(Outcome.program_id == program.id)).all()
    ws = session.exec(select(Workstream).where(Workstream.program_id == program.id)).all()
    return {
        "outcomes": [
            f"{o.description}: {o.metric} from {o.baseline_value} to {o.target_value}" for o in outcomes
        ],
        "workstreams": [f"{w.name} (lead {w.lead or 'tbd'})" for w in ws]
        + [f"{d.code}: {d.source} needs {d.target}" for d in view.ctx.dependencies],
        "risks_assumptions": [f"{r.code} {r.title} (score {r.score})" for r in view.top_risks(5)],
        "open_decisions": [
            f"{a.code} {a.title} · {a.owner or 'no owner'} · {a.due_date or 'no date'}"
            for a in view.ctx.adrs
            if a.status in ADR_OPEN
        ],
        "governance": [f"{f} ({freq})" for f, freq, _p, _o in FORUMS]
        + [f"{s.name} ({s.role}, {s.stance})" for s in view.ctx.stakeholders if s.is_decision_maker],
    }


@router.get("/brief", response_class=HTMLResponse)
def brief(
    request: Request, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    assert program.id is not None
    b = get_brief(session, program.id)
    words = brief_words(b)
    ctx = page_context(
        request,
        "brief",
        session,
        brief=b,
        sections=BRIEF_SECTIONS,
        words=words,
        max_words=BRIEF_MAX_WORDS,
        suggestions=brief_suggestions(session, program),
        lookups=lookups_for(session, program),
    )
    return render(request, "pages/brief.html", ctx)


# ------------------------------------------------------------------ Primeros 10 días


def _checks(session: Session, program_id: int, checklist: str) -> dict[int, ChecklistItem]:
    rows = session.exec(
        select(ChecklistItem).where(
            ChecklistItem.program_id == program_id, ChecklistItem.checklist == checklist
        )
    ).all()
    return {c.item_key: c for c in rows}


def _stages(session: Session, program_id: int) -> list[dict[str, Any]]:
    actions = _checks(session, program_id, "ten_days")
    stages = []
    for si, (key, label, acts, evidence) in enumerate(TEN_DAYS):
        items = [
            {
                "key": si * 10 + ai,
                "text": t,
                "checked": bool(actions.get(si * 10 + ai) and actions[si * 10 + ai].checked),
            }
            for ai, t in enumerate(acts)
        ]
        done = all(i["checked"] for i in items)
        stages.append({"key": key, "label": label, "items": items, "evidence": evidence, "done": done})
    return stages


@router.get("/onboarding", response_class=HTMLResponse)
def onboarding(
    request: Request, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    assert program.id is not None
    questions = _checks(session, program.id, "ten_days_q")
    stages = _stages(session, program.id)
    b = get_brief(session, program.id)
    baseline = session.exec(
        select(Baseline).where(Baseline.program_id == program.id).order_by(col(Baseline.version).desc())
    ).first()
    q = [
        {"key": i, "text": t, "checked": bool(questions.get(i) and questions[i].checked)}
        for i, t in enumerate(TEN_DAY_QUESTIONS)
    ]
    current = next((i for i, s in enumerate(stages) if not s["done"]), len(stages) - 1)
    ctx = page_context(
        request,
        "onboarding",
        session,
        stages=stages,
        questions=q,
        current=current,
        brief_words=brief_words(b),
        baseline=baseline,
    )
    return render(request, "pages/onboarding.html", ctx)


@router.post("/onboarding/check/{checklist}/{key}", response_class=HTMLResponse)
def toggle(
    request: Request,
    checklist: str,
    key: int,
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if checklist not in {"ten_days", "ten_days_q"}:
        raise HTTPException(404)
    texts = (
        {si * 10 + ai: t for si, (_k, _l, acts, _e) in enumerate(TEN_DAYS) for ai, t in enumerate(acts)}
        if checklist == "ten_days"
        else dict(enumerate(TEN_DAY_QUESTIONS))
    )
    if key not in texts:
        raise HTTPException(404)
    assert program.id is not None
    item = _checks(session, program.id, checklist).get(key) or ChecklistItem(
        program_id=program.id, checklist=checklist, item_key=key
    )
    item.checked = not item.checked
    session.add(item)
    session.commit()
    ctx = {"c": {"key": key, "text": texts[key], "checked": item.checked}, "checklist": checklist}
    body = templates.get_template("partials/_onboarding_item.html").render(ctx)
    if checklist == "ten_days":
        progress = templates.get_template("partials/_onboarding_progress.html")
        body += progress.render(stages=_stages(session, program.id), oob=True)
    return HTMLResponse(body)


@router.post("/baseline/new")
def new_baseline(program: Program = Depends(require_program), session: Session = Depends(get_session)) -> Any:
    assert program.id is not None
    b = create_baseline(session, program.id, get_settings().current_user)
    session.commit()
    return RedirectResponse(f"/onboarding?baseline={b.version}#result", status_code=303)


# ------------------------------------------------------------------ HLD / LLD


def questions_for(doc_type: str) -> list[str]:
    return HLD_QUESTIONS if doc_type == "HLD" else LLD_QUESTIONS


@router.get("/architecture", response_class=HTMLResponse)
def architecture(
    request: Request,
    error: str = "",
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    reviews = session.exec(
        select(DesignReview).where(DesignReview.program_id == program.id).order_by(col(DesignReview.id))
    ).all()
    items = session.exec(select(ReviewItem).where(ReviewItem.program_id == program.id)).all()
    progress = {}
    for r in reviews:
        mine = [i for i in items if i.review_id == r.id]
        progress[r.id] = {
            "answered": sum(1 for i in mine if i.answer),
            "total": len(questions_for(r.doc_type)),
            "deviations": sum(1 for i in mine if i.deviation),
        }
    diagrams = session.exec(
        select(ArchitectureDiagram).where(ArchitectureDiagram.program_id == program.id)
    ).all()
    by_view: dict[str, list[ArchitectureDiagram]] = {}
    for d in diagrams:
        by_view.setdefault(d.view, []).append(d)
    workstreams = session.exec(select(Workstream).where(Workstream.program_id == program.id)).all()
    from app.models import ArchitectureElement

    elements = session.exec(
        select(ArchitectureElement)
        .where(ArchitectureElement.program_id == program.id)
        .order_by(col(ArchitectureElement.code))
    ).all()
    ctx = page_context(
        request,
        "architecture",
        session,
        elements=elements,
        reviews=reviews,
        progress=progress,
        by_view=by_view,
        views=[v.value for v in ArchitectureView],
        workstreams=workstreams,
        error=error,
        lookups=lookups_for(session, program),
    )
    return render(request, "pages/architecture.html", ctx)


@router.post("/architecture/review/new")
def new_review(
    doc_type: str = Form("HLD"),
    title: str = Form(""),
    doc_version: str = Form(""),
    workstream_id: str = Form(""),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    if doc_type not in {"HLD", "LLD"} or not title.strip():
        return RedirectResponse(
            f"/architecture?error={quote('Choose HLD or LLD and give the document a title.')}",
            status_code=303,
        )
    assert program.id is not None
    review = DesignReview(
        program_id=program.id,
        doc_type=doc_type,
        title=title.strip(),
        doc_version=doc_version.strip(),
        workstream_id=int(workstream_id) if workstream_id.isdigit() else None,
        reviewer=get_settings().current_user,
        review_date=date.today(),
    )
    session.add(review)
    session.flush()
    for i in range(len(questions_for(doc_type))):
        session.add(ReviewItem(program_id=program.id, review_id=review.id or 0, question_key=i))
    session.commit()
    return RedirectResponse(f"/architecture/review/{review.id}", status_code=303)


def _review(session: Session, program: Program, review_id: int) -> DesignReview:
    r = session.get(DesignReview, review_id)
    if r is None or r.program_id != program.id:
        raise HTTPException(404)
    return r


@router.get("/architecture/review/{review_id}", response_class=HTMLResponse)
def review(
    request: Request,
    review_id: int,
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    r = _review(session, program, review_id)
    items = session.exec(
        select(ReviewItem).where(ReviewItem.review_id == r.id).order_by(col(ReviewItem.question_key))
    ).all()
    view = build_view(session, program.id or 0)
    codes = {("adr", a.id): a.code for a in view.ctx.adrs} | {
        ("raid", i.id): i.code for i in view.ctx.raid_items
    }
    ctx = page_context(
        request,
        "architecture",
        session,
        view,
        review=r,
        items=items,
        questions=questions_for(r.doc_type),
        answers=REVIEW_ANSWERS,
        codes=codes,
        lookups=lookups_for(session, program),
    )
    return render(request, "pages/review.html", ctx)


@router.post("/architecture/review/{review_id}/status")
def review_status(
    review_id: int,
    status: str = Form(...),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    r = _review(session, program, review_id)
    if status not in {"In Review", "Approved", "Changes Requested"}:
        raise HTTPException(422)
    r.status = status
    session.add(r)
    session.commit()
    return RedirectResponse(f"/architecture/review/{review_id}", status_code=303)


@router.post("/architecture/item/{item_id}/deviation")
def deviation_to(
    item_id: int,
    target: str = Form(...),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    """Desviación detectada en la revisión -> ADR (decisión) o Change (control de cambios) (guía §7.2)."""
    item = session.get(ReviewItem, item_id)
    if item is None or item.program_id != program.id:
        raise HTTPException(404)
    r = _review(session, program, item.review_id)
    question = questions_for(r.doc_type)[item.question_key]
    title = f"Deviation in {r.doc_type} '{r.title}': {question}"
    context = (
        f"Raised from the {r.doc_type} review of {r.review_date}. Reviewer comment: {item.comment or '—'}"
    )
    assert program.id is not None
    if target == "adr":
        adr = create_adr(session, program.id, title[:250], context=context, escalation_level="Architecture")
        item.adr_id = adr.id
        dest = f"/adr/{adr.code}"
    elif target == "change":
        change = RAIDItem(
            program_id=program.id,
            type=RAIDType.CHANGE,
            code=next_code(session, program.id, "CH"),
            title=title[:250],
            description=context,
            date_added=date.today(),
            owner=r.reviewer,
            change_control_decision="Pending",
            monitor_status=MonitorStatus.OPEN,
            reported_by=get_settings().current_user,
        )
        session.add(change)
        session.flush()
        item.raid_item_id = change.id
        dest = f"/raid?tab=changes#{change.code}"
    else:
        raise HTTPException(422)
    item.deviation = True
    session.add(item)
    session.commit()
    return RedirectResponse(dest, status_code=303)


ALLOWED = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".svg": "image/svg+xml",
    ".drawio": "application/xml",
    ".xml": "application/xml",
}
MAX_UPLOAD = 10 * 1024 * 1024


def uploads_dir() -> Any:
    from app.config import data_dir

    d = data_dir() / "uploads"
    d.mkdir(parents=True, exist_ok=True)
    return d


@router.post("/architecture/diagram")
async def upload_diagram(
    view: str = Form(...),
    title: str = Form(""),
    file: UploadFile = File(...),
    program: Program = Depends(require_program),
    session: Session = Depends(get_session),
) -> Any:
    from pathlib import Path

    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED or view not in {v.value for v in ArchitectureView}:
        return RedirectResponse(
            f"/architecture?error={quote('Upload a PNG, JPG, SVG or draw.io export for a valid view.')}",
            status_code=303,
        )
    data = await file.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD:
        return RedirectResponse(
            f"/architecture?error={quote('The file is larger than 10 MB.')}", status_code=303
        )
    stored = f"{uuid.uuid4().hex}{ext}"
    (uploads_dir() / stored).write_bytes(data)
    assert program.id is not None
    session.add(
        ArchitectureDiagram(
            program_id=program.id,
            view=view,
            title=title.strip() or (file.filename or stored),
            filename=file.filename or stored,
            stored_as=stored,
            content_type=ALLOWED[ext],
        )
    )
    session.commit()
    return RedirectResponse("/architecture#diagrams", status_code=303)


@router.get("/architecture/diagram/{diagram_id}")
def get_diagram(
    diagram_id: int, program: Program = Depends(require_program), session: Session = Depends(get_session)
) -> Any:
    d = session.get(ArchitectureDiagram, diagram_id)
    if d is None or d.program_id != program.id:
        raise HTTPException(404)
    path = uploads_dir() / d.stored_as
    if not path.exists():
        raise HTTPException(404)
    # Un SVG subido no debe poder ejecutar scripts si se abre directamente
    headers = {
        "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox",
        "X-Content-Type-Options": "nosniff",
    }
    return FileResponse(
        path,
        media_type=d.content_type,
        headers=headers,
        filename=d.filename,
        content_disposition_type="inline",
    )
