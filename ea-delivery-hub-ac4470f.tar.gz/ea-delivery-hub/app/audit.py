"""AuditLog append-only: registra altas, cambios por campo y bajas de toda entidad del programa."""

from __future__ import annotations

from contextvars import ContextVar
from datetime import date, datetime
from typing import Any

from sqlalchemy import event, inspect
from sqlalchemy.orm import Session as OrmSession

from app.models import AuditLog, Program, ProgramScoped, Timestamped, current_user, utcnow

# El seed desactiva la auditoría: recrear datos demo no es un cambio de negocio.
audit_enabled: ContextVar[bool] = ContextVar("audit_enabled", default=True)

_SKIP_FIELDS = {"created_at", "created_by", "updated_at", "updated_by"}


class AuditLogImmutableError(RuntimeError):
    pass


def _fmt(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, datetime | date):
        return value.isoformat()
    return str(value)


def _program_id(obj: Any) -> int | None:
    if isinstance(obj, Program):
        return obj.id
    return getattr(obj, "program_id", None)


def _audited(obj: Any) -> bool:
    return isinstance(obj, ProgramScoped | Program) and not isinstance(obj, AuditLog)


def _before_flush(session: OrmSession, _ctx: Any, _instances: Any) -> None:
    for obj in list(session.dirty) + list(session.deleted):
        if isinstance(obj, AuditLog):
            raise AuditLogImmutableError("AuditLog is append-only")

    user = current_user.get()
    for obj in session.dirty:
        if isinstance(obj, Timestamped) and session.is_modified(obj, include_collections=False):
            obj.updated_at = utcnow()
            obj.updated_by = user

    if not audit_enabled.get():
        return

    for obj in session.dirty:
        if not _audited(obj) or not session.is_modified(obj, include_collections=False):
            continue
        state = inspect(obj)
        for attr in state.mapper.column_attrs:
            if attr.key in _SKIP_FIELDS:
                continue
            hist = state.attrs[attr.key].history
            if not hist.has_changes():
                continue
            old = hist.deleted[0] if hist.deleted else None
            new = hist.added[0] if hist.added else None
            session.add(
                AuditLog(
                    program_id=_program_id(obj) or 0,
                    entity=type(obj).__name__,
                    entity_id=obj.id,
                    action="update",
                    field_name=attr.key,
                    old_value=_fmt(old),
                    new_value=_fmt(new),
                    user=user,
                )
            )

    for obj in session.deleted:
        if _audited(obj):
            session.add(
                AuditLog(
                    program_id=_program_id(obj) or 0,
                    entity=type(obj).__name__,
                    entity_id=obj.id,
                    action="delete",
                    user=user,
                )
            )

    session.info.setdefault("_audit_new", []).extend(o for o in session.new if _audited(o))


def _after_flush_postexec(session: OrmSession, _ctx: Any) -> None:
    created = session.info.pop("_audit_new", [])
    if not created or not audit_enabled.get():
        return
    user = current_user.get()
    for obj in created:
        session.add(
            AuditLog(
                program_id=_program_id(obj) or 0,
                entity=type(obj).__name__,
                entity_id=obj.id,
                action="create",
                user=user,
            )
        )


def install() -> None:
    if not event.contains(OrmSession, "before_flush", _before_flush):
        event.listen(OrmSession, "before_flush", _before_flush)
        event.listen(OrmSession, "after_flush_postexec", _after_flush_postexec)
