"""Jinja2 y contexto común de todas las pantallas (shell, branding, navegación, programa activo)."""

from __future__ import annotations

import json
from datetime import date
from typing import Any

from fastapi import Request
from fastapi.templating import Jinja2Templates
from markupsafe import Markup
from sqlmodel import Session, select

from app.config import APP_DIR, VERSION, get_branding, get_settings
from app.content.artifacts import ARTIFACTS
from app.models import Program
from app.models.enums import PHASE_NAMES
from app.navigation import group_of, visible_navigation
from app.services.fields import display, rag_for_score
from app.services.governance import ProgramView, build_view

PROGRAM_COOKIE = "ea_program"

templates = Jinja2Templates(directory=str(APP_DIR / "templates"))


def _fmt_date(value: date | None, fmt: str = "%d %b %Y") -> str:
    return value.strftime(fmt) if value else ""


def _tojson_attr(value: Any) -> Markup:
    return Markup(json.dumps(value))


templates.env.filters["d"] = _fmt_date
templates.env.filters["jsonattr"] = _tojson_attr


def asset(path: str) -> str:
    """URL de un fichero estático con su fecha de modificación: el navegador no reutiliza una versión
    antigua tras una actualización (p. ej. el sprite de iconos o el CSS compilado)."""
    try:
        stamp = int((APP_DIR / "static" / path).stat().st_mtime)
    except OSError:
        stamp = 0
    return f"/static/{path}?v={stamp}"


templates.env.globals["asset"] = asset
templates.env.globals["PHASE_NAMES"] = PHASE_NAMES
templates.env.globals["ARTIFACTS"] = ARTIFACTS
templates.env.globals["display"] = display
templates.env.globals["rag_for_score"] = rag_for_score


def active_features() -> set[str]:
    features: set[str] = set()
    if get_settings().copilot_enabled:
        features.add("copilot")
    return features


def list_programs(session: Session) -> list[Program]:
    return list(session.exec(select(Program).order_by(Program.id)).all())  # type: ignore[arg-type]


def current_program(session: Session, request: Request) -> Program | None:
    """Programa activo: cookie del selector de la top bar; si no, el primero creado."""
    raw = request.cookies.get(PROGRAM_COOKIE)
    if raw and raw.isdigit():
        program = session.get(Program, int(raw))
        if program is not None:
            return program
    return session.exec(select(Program).order_by(Program.id)).first()  # type: ignore[arg-type]


def page_context(
    request: Request, active: str, session: Session, view: ProgramView | None = None, **extra: Any
) -> dict[str, Any]:
    """Contexto base: shell, navegación, programa activo y badges calculados por el motor de reglas."""
    program = view.program if view else current_program(session, request)
    if view is None and program is not None and program.id is not None:
        view = build_view(session, program.id)
    ctx: dict[str, Any] = {
        "request": request,
        "branding": get_branding(),
        "version": VERSION,
        "nav": visible_navigation(active_features()),
        "active": active,
        "active_group": group_of(active),
        "programs": list_programs(session),
        "current_program": program,
        "view": view,
        "badges": view.badges if view else {},
        "current_user": get_settings().current_user,
    }
    ctx.update(extra)
    return ctx


def render(request: Request, template: str, ctx: dict[str, Any], status_code: int = 200) -> Any:
    return templates.TemplateResponse(request, template, ctx, status_code=status_code)
