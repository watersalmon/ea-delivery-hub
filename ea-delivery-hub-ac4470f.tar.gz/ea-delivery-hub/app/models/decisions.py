"""Architecture Decision Records (guía §13.2 y §5.2)."""

from __future__ import annotations

from datetime import date, datetime

from sqlmodel import JSON, Column, Field

from app.models.base import ProgramScoped


class ADR(ProgramScoped, table=True):
    code: str = Field(max_length=20, index=True)  # ADR-###
    title: str
    status: str = "Proposed"  # ADRStatus
    context: str = ""
    decision: str = ""
    conditions: str = ""
    rationale: str = ""
    consequences: str = ""
    impacted_artifacts: str = ""  # ADR-03
    impacted_workstreams: str = ""
    cost_impact: str = ""
    schedule_impact: str = ""
    operations_impact: str = ""
    escalation_level: str = "Architecture"  # EscalationLevel
    critical_path: bool = False
    owner: str = ""
    due_date: date | None = None
    approvers: str = ""
    submitted_at: date | None = None  # entrada en Proposed: base del SLA (ADR-02)
    approved_at: date | None = None
    supersedes_id: int | None = Field(default=None, foreign_key="adr.id")


class ADROption(ProgramScoped, table=True):
    adr_id: int = Field(foreign_key="adr.id", index=True)
    name: str
    pros: str = ""
    cons: str = ""
    cost: str = ""
    risk: str = ""
    # Puntuación 1-5 por criterio de la Design Authority (alineación, seguridad, operabilidad, coste,
    # plazo, reversibilidad, compliance)
    scores: dict[str, int] = Field(default_factory=dict, sa_column=Column(JSON))
    chosen: bool = False


class ADRStatusChange(ProgramScoped, table=True):
    adr_id: int = Field(foreign_key="adr.id", index=True)
    from_status: str = ""
    to_status: str
    changed_at: datetime | None = None
    note: str = ""
