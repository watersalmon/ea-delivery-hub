"""Base común de las entidades: program_id + metadatos de auditoría (CLAUDE.md §5)."""

from __future__ import annotations

from contextvars import ContextVar
from datetime import UTC, datetime

from sqlmodel import Field, SQLModel

# Usuario de la petición en curso (sin login en v1: viene de EA_USER). Lo usan los metadatos y el AuditLog.
current_user: ContextVar[str] = ContextVar("current_user", default="system")


def utcnow() -> datetime:
    return datetime.now(UTC)


def _user() -> str:
    return current_user.get()


class Timestamped(SQLModel):
    created_at: datetime = Field(default_factory=utcnow)
    created_by: str = Field(default_factory=_user, max_length=120)
    updated_at: datetime = Field(default_factory=utcnow)
    updated_by: str = Field(default_factory=_user, max_length=120)


class ProgramScoped(Timestamped):
    id: int | None = Field(default=None, primary_key=True)
    program_id: int = Field(foreign_key="program.id", index=True)
