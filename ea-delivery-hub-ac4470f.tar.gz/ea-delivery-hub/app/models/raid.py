"""RAID Log (captura 1 + guía §8) y dependencias (§8.1)."""

from __future__ import annotations

from datetime import date

from sqlmodel import Field

from app.models.base import ProgramScoped


class RAIDItem(ProgramScoped, table=True):
    type: str = Field(max_length=20, index=True)  # RAIDType
    code: str = Field(max_length=20, index=True)  # RK-### / AC-### / ...
    organization: str = ""
    date_added: date | None = None
    reported_by: str = ""
    title: str
    description: str = ""
    workstream_id: int | None = Field(default=None, foreign_key="workstream.id")
    owner: str = ""
    due_date: date | None = None
    monitor_status: str = "Open"  # MonitorStatus

    # Risk (guía §8: causa, evento, consecuencia)
    cause: str = ""
    event: str = ""
    consequence: str = ""
    probability: int | None = None
    impact: int | None = None
    response: str = ""  # respuesta / mitigación
    contingency_plan: str = ""
    escalation_trigger: str = ""
    escalation_forum: str = ""
    trigger_met: bool = False  # el EA marca que se cumple el trigger (RAID-04)

    # Issue
    severity: str = ""
    resolution: str = ""

    # Issue / Escalation: riesgo origen
    source_risk_id: int | None = Field(default=None, foreign_key="raiditem.id")

    # Change
    scope_impact: str = ""
    cost_impact: str = ""
    schedule_impact: str = ""
    change_control_decision: str = ""

    # Lesson learned (guía §10)
    context: str = ""
    decision_taken: str = ""
    result: str = ""
    recommendation: str = ""

    @property
    def score(self) -> int | None:
        if self.probability is None or self.impact is None:
            return None
        return self.probability * self.impact

    @property
    def is_closed(self) -> bool:
        return self.monitor_status == "Closed"


class RAIDUpdate(ProgramScoped, table=True):
    """Log fechado de updates ("2/21: …" en la captura)."""

    raid_item_id: int = Field(foreign_key="raiditem.id", index=True)
    update_date: date
    text: str


class Dependency(ProgramScoped, table=True):
    code: str = Field(max_length=20)  # DEP-###
    title: str
    source: str  # workstream, tercero o cliente que depende
    target: str  # de quién depende
    dep_type: str = "Delivery"  # Delivery | Information | Decision | Resource
    external: bool = False
    commitment_verified: bool = False  # DEP-01
    evidence: str = ""
    need_date: date | None = None
    status: str = "Open"
    critical_path: bool = False
    owner: str = ""
