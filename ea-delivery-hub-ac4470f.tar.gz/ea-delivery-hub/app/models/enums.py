"""Vocabularios cerrados. Se guardan como texto (portable SQLite/Postgres) y se validan en servicio."""

from __future__ import annotations

from enum import StrEnum

# Fases de la guía §4 (0-6). G<n> es el gate de salida de la fase n.
PHASE_NAMES = (
    "Qualify / Presales",
    "Discover",
    "Define target",
    "Plan transition",
    "Govern delivery",
    "Validate / Transition",
    "Close / Evolve",
)


class Organization(StrEnum):
    CUSTOMER = "Customer"
    DELL = "Dell"
    PARTNER = "Partner"


class Stance(StrEnum):
    SPONSOR = "Sponsor"
    NEUTRAL = "Neutral"
    DETRACTOR = "Detractor"


class MoSCoW(StrEnum):
    MUST = "Must"
    SHOULD = "Should"
    COULD = "Could"
    WONT = "Won't"


class RequirementKind(StrEnum):
    FUNCTIONAL = "FR"
    NON_FUNCTIONAL = "NFR"


class NFRCategory(StrEnum):
    AVAILABILITY = "Availability"
    RECOVERY = "RTO/RPO"
    PERFORMANCE = "Performance"
    CAPACITY = "Capacity"
    SECURITY = "Security"
    RETENTION = "Retention"


class ArchitectureView(StrEnum):
    CONTEXT = "Context"
    APPLICATION = "Application"
    DATA = "Data"
    TECHNOLOGY = "Technology"
    SECURITY = "Security"
    OPERATIONS = "Operations"


class ADRStatus(StrEnum):
    PROPOSED = "Proposed"
    UNDER_REVIEW = "Under Review"
    APPROVED = "Approved"
    REJECTED = "Rejected"
    DEFERRED = "Deferred"
    SUPERSEDED = "Superseded"


ADR_OPEN = {ADRStatus.PROPOSED, ADRStatus.UNDER_REVIEW, ADRStatus.DEFERRED}
ADR_PENDING = {ADRStatus.PROPOSED, ADRStatus.UNDER_REVIEW}


class EscalationLevel(StrEnum):
    """Guía §7.3."""

    WORKSTREAM = "Workstream"
    ARCHITECTURE = "Architecture"
    PROGRAM = "Program"
    EXECUTIVE = "Executive"


ESCALATION_FORUM = {
    EscalationLevel.WORKSTREAM: "Tech Lead / design sync",
    EscalationLevel.ARCHITECTURE: "Design Authority",
    EscalationLevel.PROGRAM: "PM / Change Control",
    EscalationLevel.EXECUTIVE: "SteerCo / sponsor",
}


class RAIDType(StrEnum):
    RISK = "Risk"
    ACTION = "Action"
    ISSUE = "Issue"
    DECISION = "Decision"
    ESCALATION = "Escalation"
    CHANGE = "Change"
    COMM = "Comm"
    LESSON = "LessonLearned"


RAID_PREFIX = {
    RAIDType.RISK: "RK",
    RAIDType.ACTION: "AC",
    RAIDType.ISSUE: "IS",
    RAIDType.DECISION: "DC",
    RAIDType.ESCALATION: "ES",
    RAIDType.CHANGE: "CH",
    RAIDType.COMM: "CM",
    RAIDType.LESSON: "LL",
}


class MonitorStatus(StrEnum):
    OPEN = "Open"
    ACTION_REQUIRED = "Action Required"
    IN_PROGRESS = "In Progress"
    MONITORING = "Monitoring"
    CLOSED = "Closed"


class Severity(StrEnum):
    RED = "red"
    AMBER = "amber"


class RAG(StrEnum):
    GREEN = "green"
    AMBER = "amber"
    RED = "red"
    BLUE = "blue"
    GREY = "grey"


class RACIValue(StrEnum):
    R = "R"
    A = "A"
    C = "C"
    I = "I"  # noqa: E741
    AR = "A/R"
    AC = "A/C"


ACCOUNTABLE_VALUES = {RACIValue.A, RACIValue.AR, RACIValue.AC}
RESPONSIBLE_VALUES = {RACIValue.R, RACIValue.AR}


class CompletionStatus(StrEnum):
    NOT_STARTED = "Not Started"
    IN_PROGRESS = "In Progress"
    COMPLETE = "Complete"
    AT_RISK = "At Risk"


class EvidenceResult(StrEnum):
    PASS = "Pass"
    FAIL = "Fail"
    PENDING = "Pending"


class GateStatus(StrEnum):
    NOT_STARTED = "Not Started"
    IN_PROGRESS = "In Progress"
    PASSED = "Passed"
    BLOCKED = "Blocked"


class TraceType(StrEnum):
    """Extremos admitidos en TraceLink (RTM y enlaces de foros)."""

    OUTCOME = "outcome"
    OBJECTIVE = "objective"
    REQUIREMENT = "requirement"
    ARCH_ELEMENT = "arch_element"
    ADR = "adr"
    TEST_EVIDENCE = "test_evidence"
    GATE = "gate"
    RAID = "raid"
    MEETING = "meeting"
