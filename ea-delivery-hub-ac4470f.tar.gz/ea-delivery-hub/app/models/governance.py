"""Gates, RACI, foros, operational readiness, handover, baselines y auditoría."""

from __future__ import annotations

from datetime import date, datetime

from sqlmodel import JSON, Column, Field

from app.models.base import ProgramScoped, Timestamped, utcnow


class Gate(ProgramScoped, table=True):
    code: str = Field(max_length=4)  # G0..G6 = gate de salida de la fase n (guía §4)
    phase: int = Field(ge=0, le=6)
    name: str
    key_question: str = ""
    exit_criteria: str = ""
    status: str = "Not Started"  # GateStatus
    approver: str = ""
    passed_at: date | None = None
    waiver_adr_id: int | None = Field(default=None, foreign_key="adr.id")


class GateCriterion(ProgramScoped, table=True):
    gate_id: int = Field(foreign_key="gate.id", index=True)
    criterion: str
    evidence_required: str = ""
    status: str = "Open"  # Open | Met | Not Met
    approver: str = ""


class RACIRole(ProgramScoped, table=True):
    name: str = Field(max_length=80)
    order: int = 0


class RACIActivity(ProgramScoped, table=True):
    name: str
    order: int = 0


class RACIAssignment(ProgramScoped, table=True):
    activity_id: int = Field(foreign_key="raciactivity.id", index=True)
    role_id: int = Field(foreign_key="racirole.id", index=True)
    value: str = Field(max_length=4)  # RACIValue
    qualifier: str = ""  # "técnico", "dominio", "coordinación" (guía §9)


class Meeting(ProgramScoped, table=True):
    """Foros de la guía §5.1. Decisiones y acciones se enlazan vía TraceLink (meeting -> adr / raid)."""

    forum: str  # Workstream design sync | Architecture Design Authority | ...
    meeting_date: date
    quorum_met: bool = False
    attendees: str = ""
    agenda: str = ""
    notes: str = ""
    status: str = "Planned"  # Planned | In Progress | Closed
    # Participantes del quórum (guía §5.2): [{"role": "...", "name": "...", "present": true}]
    participants: list[dict[str, object]] = Field(default_factory=list, sa_column=Column(JSON))
    started_at: datetime | None = None
    closed_at: datetime | None = None


class MeetingDecision(ProgramScoped, table=True):
    """Resultado de la deliberación de un ADR en una Design Authority (guía §5.2, §13.3)."""

    meeting_id: int = Field(foreign_key="meeting.id", index=True)
    adr_id: int = Field(foreign_key="adr.id", index=True)
    order: int = 0
    outcome: str = ""  # Approved | Rejected | Deferred ("" = pendiente)
    conditions: str = ""
    owner: str = ""
    due_date: date | None = None
    notes: str = ""


class WorkPackage(ProgramScoped, table=True):
    """Roadmap: work packages, milestones y transition states (guía §6)."""

    code: str = Field(max_length=20)  # WP-###
    name: str
    workstream_id: int | None = Field(default=None, foreign_key="workstream.id")
    start: date | None = None
    end: date | None = None
    milestone: bool = False
    transition_state: str = ""  # p. ej. "TS1 · Landing zone"
    depends_on: str = ""  # códigos WP separados por coma
    gate_code: str = ""  # gate al que contribuye
    status: str = "Planned"  # Planned | In Progress | Done | At Risk


class DesignReview(ProgramScoped, table=True):
    """Revisión de un HLD o LLD con el checklist de la guía §7.1 / §7.2."""

    doc_type: str = "HLD"  # HLD | LLD
    title: str
    doc_version: str = ""
    workstream_id: int | None = Field(default=None, foreign_key="workstream.id")
    reviewer: str = ""
    review_date: date | None = None
    status: str = "In Review"  # In Review | Approved | Changes Requested


class ReviewItem(ProgramScoped, table=True):
    review_id: int = Field(foreign_key="designreview.id", index=True)
    question_key: int
    answer: str = ""  # Yes | No | Partial | N/A
    comment: str = ""
    deviation: bool = False
    adr_id: int | None = Field(default=None, foreign_key="adr.id")
    raid_item_id: int | None = Field(default=None, foreign_key="raiditem.id")


class ArchitectureDiagram(ProgramScoped, table=True):
    view: str = "Context"  # ArchitectureView
    title: str
    filename: str  # nombre original
    stored_as: str  # nombre en el volumen de datos
    content_type: str = ""


class ArchitectureBrief(ProgramScoped, table=True):
    """Architecture Brief de 1-2 páginas (guía §13.1). Una fila por programa."""

    outcomes: str = ""
    scope_in: str = ""
    scope_out: str = ""
    context: str = ""
    principles: str = ""
    workstreams: str = ""
    risks_assumptions: str = ""
    open_decisions: str = ""
    governance: str = ""


class ORRCheck(ProgramScoped, table=True):
    dimension: str  # monitoring, backup, support, access, capacity, runbooks, skills + configurables
    criterion: str
    evidence: str = ""
    status: str = "grey"  # RAG
    owner: str = ""


class HandoverItem(ProgramScoped, table=True):
    kind: str = "TechDebt"  # TechDebt | Deviation | Transfer
    title: str
    impact: str = ""
    estimated_cost: str = ""
    receiving_owner: str = ""
    review_date: date | None = None


class Baseline(ProgramScoped, table=True):
    """Snapshot versionado. `element_hashes` permite detectar cambios por elemento (BASE-01)."""

    version: int
    approved_by: str = ""
    approved_at: datetime = Field(default_factory=utcnow)
    sha256: str = Field(max_length=64)
    payload: str  # JSON serializado (requisitos + arquitectura + RAID + roadmap)
    element_hashes: str = "{}"  # JSON {"requirement:12": "<sha>", "arch_element:3": "<sha>"}


class AuditLog(Timestamped, table=True):
    """Append-only: no hay endpoints de update/delete y el listener rechaza modificarlo.
    program_id sin FK: el historial sobrevive aunque el programa se borre (p. ej. al recrear la demo)."""

    id: int | None = Field(default=None, primary_key=True)
    program_id: int = Field(index=True)
    entity: str = Field(max_length=40, index=True)
    entity_id: int | None = Field(default=None, index=True)
    action: str = Field(max_length=10)  # create | update | delete
    field_name: str = ""
    old_value: str | None = None
    new_value: str | None = None
    user: str = ""
    at: datetime = Field(default_factory=utcnow)


class ChecklistItem(ProgramScoped, table=True):
    """Respuestas a checklists de la guía (p. ej. §11.2 "¿Estoy realmente al mando?")."""

    checklist: str = Field(max_length=40, index=True)
    item_key: int
    checked: bool = False
    note: str = ""


class IdSequence(ProgramScoped, table=True):
    prefix: str = Field(max_length=10)
    last: int = 0
