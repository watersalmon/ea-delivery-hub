"""Goals/Objectives, outcomes, requisitos, elementos de arquitectura, evidencias y enlaces de trazabilidad."""

from __future__ import annotations

from datetime import date

from sqlmodel import Field

from app.models.base import ProgramScoped


class Goal(ProgramScoped, table=True):
    code: str = Field(max_length=20)  # Goal-###
    title: str


class Objective(ProgramScoped, table=True):
    code: str = Field(max_length=20)  # Obj-###
    goal_id: int = Field(foreign_key="goal.id", index=True)
    objective: str
    acceptance_criteria: str = ""
    completion_status: str = "Not Started"  # CompletionStatus
    approver: str = ""


class Outcome(ProgramScoped, table=True):
    code: str = Field(max_length=20)  # OUT-###
    description: str
    metric: str = ""
    baseline_value: str = ""
    target_value: str = ""
    target_date: date | None = None


class Requirement(ProgramScoped, table=True):
    code: str = Field(max_length=20, index=True)  # REQ-### / NFR-###
    kind: str = "FR"  # RequirementKind
    statement: str
    priority: str = "Must"  # MoSCoW
    nfr_category: str = ""  # NFRCategory, solo NFR
    measurable_criterion: str = ""  # obligatorio para NFR (RTM-03)
    target_value: float | None = None  # para el radar NFR
    achieved_value: float | None = None
    unit: str = ""
    source: str = ""  # SOW, workshop, presales…
    status: str = "Proposed"
    workstream_id: int | None = Field(default=None, foreign_key="workstream.id")


class ArchitectureElement(ProgramScoped, table=True):
    code: str = Field(max_length=20)  # AE-###
    name: str
    view: str = "Technology"  # ArchitectureView
    workstream_id: int | None = Field(default=None, foreign_key="workstream.id")
    hld_ref: str = ""
    lld_ref: str = ""


class TestEvidence(ProgramScoped, table=True):
    __test__ = False  # que pytest no la tome por una clase de tests

    code: str = Field(max_length=20)  # TE-###
    title: str
    kind: str = "Manual test"  # automated test | manual test | demo | document
    result: str = "Pending"  # EvidenceResult
    evidence_date: date | None = None
    link: str = ""


class TraceLink(ProgramScoped, table=True):
    """Enlace genérico de la RTM. Dirección canónica aguas abajo:
    outcome/objective -> requirement -> arch_element -> adr; requirement -> test_evidence; * -> gate."""

    src_type: str = Field(max_length=20, index=True)  # TraceType
    src_id: int = Field(index=True)
    dst_type: str = Field(max_length=20, index=True)
    dst_id: int = Field(index=True)
    relation: str = ""
