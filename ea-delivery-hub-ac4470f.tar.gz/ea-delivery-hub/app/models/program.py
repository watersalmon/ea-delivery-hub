"""Programa, ajustes, workstreams y stakeholders."""

from __future__ import annotations

from datetime import date

from sqlmodel import Field

from app.models.base import ProgramScoped, Timestamped


class Program(Timestamped, table=True):
    id: int | None = Field(default=None, primary_key=True)
    code: str = Field(index=True, unique=True, max_length=40)
    name: str = Field(max_length=200)
    client: str = Field(max_length=200)
    sponsor: str = ""
    pm: str = ""
    ea: str = ""
    phase: int = Field(default=0, ge=0, le=6)
    classification: str = "Internal Use - Confidential"
    export_language: str = "en"
    applicable_frameworks: str = ""  # campo libre configurable (CLAUDE.md §11): nada sectorial fijo
    operations_owner: str = ""  # owner de operaciones del cliente (OPS-01)
    operations_engaged: bool = False  # operaciones participa en el diseño/readiness (OPS-01)
    start_date: date | None = None
    is_demo: bool = False


class ProgramSettings(ProgramScoped, table=True):
    """Escala de riesgo, umbrales RAG del score y SLA de decisiones (CLAUDE.md §5 Settings)."""

    risk_scale: int = 3  # 3 => 1-3 x 1-3 (RAID Log Dell); 5 => 1-5 x 1-5
    amber_from: int = 3
    red_from: int = 7
    decision_sla_days: int = 10

    @classmethod
    def defaults_for_scale(cls, scale: int) -> dict[str, int]:
        if scale == 5:
            return {"risk_scale": 5, "amber_from": 5, "red_from": 15}
        return {"risk_scale": 3, "amber_from": 3, "red_from": 7}


class Workstream(ProgramScoped, table=True):
    name: str = Field(max_length=120)
    lead: str = ""
    scope: str = ""


class Stakeholder(ProgramScoped, table=True):
    name: str = Field(max_length=120)
    organization: str = "Customer"  # Organization
    role: str = ""
    influence: int = Field(default=3, ge=1, le=5)
    interest: int = Field(default=3, ge=1, le=5)
    stance: str = "Neutral"  # Stance
    is_decision_maker: bool = False
    channel: str = ""
    cadence: str = ""
    key_message: str = ""
    comms_owner: str = ""
