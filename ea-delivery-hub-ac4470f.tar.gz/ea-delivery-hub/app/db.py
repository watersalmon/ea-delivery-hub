"""Motor de base de datos y sesiones (SQLite por defecto, Postgres opcional)."""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

from sqlalchemy import text
from sqlalchemy.engine import Engine, make_url
from sqlalchemy.pool import StaticPool
from sqlmodel import Session, SQLModel, create_engine

from app import audit
from app.config import get_settings

_engine: Engine | None = None


def _build_engine(url: str) -> Engine:
    parsed = make_url(url)
    connect_args: dict[str, object] = {}
    kwargs: dict[str, object] = {"pool_pre_ping": True}
    if parsed.get_backend_name() == "sqlite":
        connect_args["check_same_thread"] = False
        if parsed.database and parsed.database != ":memory:":
            Path(parsed.database).parent.mkdir(parents=True, exist_ok=True)
        else:
            kwargs["poolclass"] = StaticPool  # BD en memoria compartida entre conexiones (tests)
    audit.install()
    return create_engine(url, connect_args=connect_args, **kwargs)


def get_engine() -> Engine:
    global _engine
    if _engine is None:
        _engine = _build_engine(get_settings().database_url)
    return _engine


def init_db() -> None:
    """Crea las tablas que falten. En Docker ya las ha creado Alembic (entrypoint); en local/tests basta."""
    import app.models  # noqa: F401  registra las tablas

    SQLModel.metadata.create_all(get_engine())


def reset_engine() -> None:
    global _engine
    _engine = None


def get_session() -> Iterator[Session]:
    with Session(get_engine()) as session:
        yield session


def db_ok() -> bool:
    try:
        with get_engine().connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
    except Exception:
        return False
