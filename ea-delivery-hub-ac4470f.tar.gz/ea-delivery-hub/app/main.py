"""Punto de entrada FastAPI de EA Delivery Hub."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.config import APP_DIR, VERSION, get_settings
from app.db import db_ok, init_db
from app.models import current_user
from app.routers import (
    admin,
    closeout,
    dashboard,
    data_entry,
    decisions,
    definition,
    deletion,
    design_authority,
    exports,
    gates,
    inline,
    library,
    pages,
    raid,
    shell,
    stakeholders,
    traceability,
)
from app.routers.deps import NoProgramError


@asynccontextmanager
async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
    init_db()
    yield


app = FastAPI(
    title="EA Delivery Hub", version=VERSION, docs_url="/api/docs", redoc_url=None, lifespan=lifespan
)
app.mount("/static", StaticFiles(directory=str(APP_DIR / "static")), name="static")


@app.middleware("http")
async def bind_user(request: Request, call_next: Any) -> Any:
    """Sin login en v1: el usuario de created_by/updated_by y del AuditLog sale de EA_USER."""
    token = current_user.set(get_settings().current_user)
    try:
        return await call_next(request)
    finally:
        current_user.reset(token)


@app.exception_handler(NoProgramError)
async def no_program(request: Request, _exc: NoProgramError) -> Any:
    from sqlmodel import Session

    from app.db import get_engine
    from app.web import page_context, render

    with Session(get_engine()) as session:
        return render(request, "pages/no_program.html", page_context(request, "portfolio", session))


@app.get("/health", include_in_schema=False)
def health() -> JSONResponse:
    ok = db_ok()
    return JSONResponse(
        {"status": "ok" if ok else "degraded", "version": VERSION, "db": "ok" if ok else "error"},
        status_code=200 if ok else 503,
    )


app.include_router(shell.router)
app.include_router(inline.router)
app.include_router(raid.router)
app.include_router(stakeholders.router)
app.include_router(traceability.router)
app.include_router(dashboard.router)
app.include_router(exports.router)
app.include_router(decisions.router)
app.include_router(design_authority.router)
app.include_router(gates.router)
app.include_router(definition.router)
app.include_router(data_entry.router)
app.include_router(closeout.router)
app.include_router(library.router)
app.include_router(admin.router)
app.include_router(deletion.router)
# Las rutas de páginas van al final: incluyen un catch-all /{slug}
app.include_router(pages.router)
