"""ADR-01..03 (guía §5.2, §8.1, §13.2)."""

from __future__ import annotations

from collections.abc import Iterator

from app.models.enums import ADR_OPEN, ADR_PENDING, ADRStatus, Severity
from app.rules.base import ALL_GATES, RuleResult, result, rule
from app.rules.context import ProgramContext


@rule("ADR-01", "Critical-path decision without owner or date", "§5.2, §8.1", "decisions", ALL_GATES)
def critical_decision_unowned(ctx: ProgramContext) -> Iterator[RuleResult]:
    for adr in ctx.adrs:
        if not adr.critical_path or adr.status not in ADR_OPEN:
            continue
        missing = []
        if not adr.owner.strip():
            missing.append("owner")
        if adr.due_date is None:
            missing.append("due date")
        if missing:
            yield result(
                "ADR-01",
                Severity.RED,
                "adr",
                adr.id,
                adr.code,
                f"Critical-path decision without {' and '.join(missing)}.",
                "Assign an owner and a decision date at the next Design Authority.",
            )


@rule("ADR-02", "Pending ADR beyond the decision SLA", "§5.2", "decisions")
def adr_sla(ctx: ProgramContext) -> Iterator[RuleResult]:
    sla = ctx.settings.decision_sla_days
    for adr in ctx.adrs:
        if adr.status in ADR_PENDING and adr.submitted_at:
            age = (ctx.today - adr.submitted_at).days
            if age > sla:
                yield result(
                    "ADR-02",
                    Severity.AMBER,
                    "adr",
                    adr.id,
                    adr.code,
                    f"'{adr.status}' for {age} days (SLA {sla} days).",
                    "Put it on the next Design Authority agenda or escalate one level.",
                )


@rule("ADR-03", "Approved ADR without impacted artifacts", "§5.2, §13.2", "decisions")
def adr_without_impacts(ctx: ProgramContext) -> Iterator[RuleResult]:
    for adr in ctx.adrs:
        if adr.status == ADRStatus.APPROVED and not adr.impacted_artifacts.strip():
            yield result(
                "ADR-03",
                Severity.AMBER,
                "adr",
                adr.id,
                adr.code,
                "Approved decision without impacted artifacts identified.",
                "List the artifacts to update (HLD, LLD, RTM, runbooks…) and their owners.",
            )
