"""RACI-01 / RACI-02 (guía §6 y §9)."""

from __future__ import annotations

from collections.abc import Iterator

from app.models.enums import ACCOUNTABLE_VALUES, RESPONSIBLE_VALUES, Severity
from app.rules.base import RuleResult, result, rule
from app.rules.context import ProgramContext


def _values_by_activity(ctx: ProgramContext) -> dict[int, list[str]]:
    out: dict[int, list[str]] = {a.id: [] for a in ctx.raci_activities if a.id is not None}
    for asg in ctx.raci_assignments:
        out.setdefault(asg.activity_id, []).append(asg.value)
    return out


@rule("RACI-01", "Exactly one Accountable per activity", "§6, §9", "decisions", blocks_gates={"G1", "G2"})
def raci_single_accountable(ctx: ProgramContext) -> Iterator[RuleResult]:
    values = _values_by_activity(ctx)
    for act in ctx.raci_activities:
        count = sum(1 for v in values.get(act.id or -1, []) if v in ACCOUNTABLE_VALUES)
        if count != 1:
            yield result(
                "RACI-01",
                Severity.RED,
                "raci_activity",
                act.id,
                act.name,
                f"'{act.name}' has {count} Accountable roles (exactly one required).",
                "Keep a single A for the activity; turn the others into C or R.",
            )


@rule("RACI-02", "At least one Responsible per activity", "§6, §9", "decisions")
def raci_has_responsible(ctx: ProgramContext) -> Iterator[RuleResult]:
    values = _values_by_activity(ctx)
    for act in ctx.raci_activities:
        if not any(v in RESPONSIBLE_VALUES for v in values.get(act.id or -1, [])):
            yield result(
                "RACI-02",
                Severity.AMBER,
                "raci_activity",
                act.id,
                act.name,
                f"'{act.name}' has no Responsible role.",
                "Assign who does the work (R or A/R).",
            )
