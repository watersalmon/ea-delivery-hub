"""DEP-01, STK-01, OPS-01 y BASE-01."""

from __future__ import annotations

from collections.abc import Iterator

from app.models.enums import RAIDType, Severity, Stance
from app.rules.base import RuleResult, result, rule
from app.rules.context import ProgramContext


@rule("DEP-01", "External dependency without verifiable commitment", "§8.1", "dependencies", {"G3", "G4"})
def external_dependency_unverified(ctx: ProgramContext) -> Iterator[RuleResult]:
    for dep in ctx.dependencies:
        if dep.external and not dep.commitment_verified and dep.status != "Closed":
            sev = Severity.RED if dep.critical_path else Severity.AMBER
            where = " on the critical path" if dep.critical_path else ""
            yield result(
                "DEP-01",
                sev,
                "dependency",
                dep.id,
                dep.code,
                f"Dependency on {dep.target}{where} has no verifiable commitment.",
                "Get a dated, written commitment (PO, email, signed plan) and attach the evidence.",
            )


@rule("STK-01", "Comms plan without decision makers or detractors", "§6", "outcomes_scope")
def comms_plan_coverage(ctx: ProgramContext) -> Iterator[RuleResult]:
    gaps = []
    if not any(s.is_decision_maker for s in ctx.stakeholders):
        gaps.append("decision makers")
    if not any(s.stance == Stance.DETRACTOR for s in ctx.stakeholders):
        gaps.append("detractors")
    if gaps:
        yield result(
            "STK-01",
            Severity.AMBER,
            "program",
            ctx.program.id,
            ctx.program.code,
            f"Stakeholder & comms plan has no {' or '.join(gaps)} identified.",
            "Map who decides and who may resist, with a message and channel for each.",
        )


@rule("OPS-01", "Operations without owner or involvement before G5", "§11.1, §14", "operations", {"G5"})
def operations_engaged(ctx: ProgramContext) -> Iterator[RuleResult]:
    if ctx.program.phase < 3:
        return
    gaps = []
    if not ctx.program.operations_owner.strip():
        gaps.append("no operations owner")
    if not ctx.program.operations_engaged:
        gaps.append("operations not yet involved")
    if gaps:
        yield result(
            "OPS-01",
            Severity.RED,
            "program",
            ctx.program.id,
            ctx.program.code,
            f"Operational readiness at risk: {', '.join(gaps)}.",
            "Name the customer operations owner and bring them into design and readiness reviews.",
        )


@rule("BASE-01", "Baselined element changed without Change/ADR", "§14", "architecture")
def baseline_drift(ctx: ProgramContext) -> Iterator[RuleResult]:
    if ctx.baseline is None:
        return
    approved = ctx.baseline.approved_at
    change_ids = {i.id for i in ctx.raid_items if i.type == RAIDType.CHANGE}
    codes = {f"requirement:{r.id}": r.code for r in ctx.requirements}
    codes.update({f"arch_element:{a.id}": a.code for a in ctx.arch_elements})
    current = ctx.current_hashes()
    for key, old_hash in ctx.baseline_hashes().items():
        new_hash = current.get(key)
        if new_hash is None or new_hash == old_hash:
            continue
        etype, _, raw_id = key.partition(":")
        eid = int(raw_id)
        covered = any(
            link.created_at >= approved
            and (
                (link.src_type == etype and link.src_id == eid)
                or (link.dst_type == etype and link.dst_id == eid)
            )
            and (
                "adr" in (link.src_type, link.dst_type)
                or (link.src_type == "raid" and link.src_id in change_ids)
                or (link.dst_type == "raid" and link.dst_id in change_ids)
            )
            for link in ctx.trace_links
        )
        if not covered:
            code = codes.get(key, key)
            yield result(
                "BASE-01",
                Severity.AMBER,
                etype,
                eid,
                code,
                f"{code} changed since baseline v{ctx.baseline.version} without a Change or ADR.",
                "Raise a Change (or ADR) and link it, or revert to the baselined version.",
            )


@rule("ORR-01", "Operational readiness check in red", "§10, CLAUDE.md §7.13", "operations", {"G5"})
def orr_red(ctx: ProgramContext) -> Iterator[RuleResult]:
    """El ORR bloquea G5 si alguna dimensión está en rojo (PDR-009)."""
    for check in ctx.orr_checks:
        if check.status == "red":
            yield result(
                "ORR-01",
                Severity.RED,
                "orr",
                check.id,
                check.dimension,
                f"Operational readiness '{check.dimension}' is red: {check.criterion}.",
                "Agree a recovery plan with operations; G5 stays blocked until it is amber or green.",
            )
