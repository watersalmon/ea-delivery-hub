"""RTM-01..03 (guía §6, §7.1, §14)."""

from __future__ import annotations

from collections.abc import Iterator

from app.models.enums import MoSCoW, RequirementKind, Severity
from app.rules.base import RuleResult, result, rule
from app.rules.context import ProgramContext


@rule("RTM-01", "Orphan requirement", "§6", "requirements", blocks_gates={"G1", "G2", "G5"})
def orphan_requirement(ctx: ProgramContext) -> Iterator[RuleResult]:
    for req in ctx.requirements:
        if req.priority == MoSCoW.WONT:
            continue
        missing = []
        if not ctx.is_linked("requirement", req.id, ("outcome", "objective")):
            missing.append("outcome/objective")
        if not ctx.is_linked("requirement", req.id, ("arch_element",)):
            missing.append("architecture element")
        if missing:
            sev = Severity.RED if req.priority == MoSCoW.MUST else Severity.AMBER
            yield result(
                "RTM-01",
                sev,
                "requirement",
                req.id,
                req.code,
                f"{req.priority} requirement not traced to {' or '.join(missing)}.",
                "Link it in the RTM, or descope it through Change Control.",
            )


@rule("RTM-02", "Requirement without test/evidence at G5", "§10", "requirements", blocks_gates={"G5"})
def requirement_without_evidence(ctx: ProgramContext) -> Iterator[RuleResult]:
    if ctx.program.phase < 5:
        return
    for req in ctx.requirements:
        if req.priority == MoSCoW.WONT:
            continue
        if not ctx.is_linked("requirement", req.id, ("test_evidence",)):
            yield result(
                "RTM-02",
                Severity.RED,
                "requirement",
                req.id,
                req.code,
                "No test or evidence proves this requirement before acceptance (G5).",
                "Attach test results, a demo record or a signed document.",
            )


@rule("RTM-03", "NFR without measurable criterion", "§7.1, §14", "requirements")
def nfr_not_measurable(ctx: ProgramContext) -> Iterator[RuleResult]:
    for req in ctx.requirements:
        if req.kind == RequirementKind.NON_FUNCTIONAL and not req.measurable_criterion.strip():
            yield result(
                "RTM-03",
                Severity.AMBER,
                "requirement",
                req.id,
                req.code,
                "Non-functional requirement without a measurable criterion.",
                "State a metric and target (e.g. availability >= 99.95% monthly, RPO <= 15 min).",
            )
