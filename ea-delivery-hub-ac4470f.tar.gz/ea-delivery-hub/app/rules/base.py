"""Tipos del motor de reglas de governance (CLAUDE.md §6)."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from app.models.enums import Severity

if TYPE_CHECKING:
    from app.rules.context import ProgramContext


# Los 7 controles de la salud semanal (guía §11.1)
CONTROLS: tuple[tuple[str, str], ...] = (
    ("outcomes_scope", "Outcomes & scope"),
    ("decisions", "Decisions"),
    ("architecture", "Architecture"),
    ("dependencies", "Dependencies"),
    ("raid", "RAID"),
    ("requirements", "Requirements"),
    ("operations", "Operations"),
)

ALL_GATES = frozenset(f"G{n}" for n in range(7))


@dataclass(frozen=True)
class RuleResult:
    rule_id: str
    severity: Severity
    entity_type: str
    entity_id: int | None
    entity_code: str
    message: str
    suggested_action: str
    control: str
    blocks_gates: frozenset[str] = field(default_factory=frozenset)


@dataclass(frozen=True)
class Rule:
    rule_id: str
    title: str
    source: str  # sección de la guía
    control: str
    check: Callable[[ProgramContext], Iterable[RuleResult]]
    blocks_gates: frozenset[str] = frozenset()


REGISTRY: dict[str, Rule] = {}


def rule(
    rule_id: str, title: str, source: str, control: str, blocks_gates: Iterable[str] = ()
) -> Callable[[Callable[[ProgramContext], Iterable[RuleResult]]], Rule]:
    """Registra una regla pura `ctx -> resultados`."""

    def deco(fn: Callable[[ProgramContext], Iterable[RuleResult]]) -> Rule:
        r = Rule(rule_id, title, source, control, fn, frozenset(blocks_gates))
        REGISTRY[rule_id] = r
        return r

    return deco


def result(
    r_id: str,
    severity: Severity,
    entity_type: str,
    entity_id: int | None,
    entity_code: str,
    message: str,
    action: str,
) -> RuleResult:
    meta = REGISTRY[r_id]
    gates = meta.blocks_gates if severity == Severity.RED else frozenset()
    return RuleResult(
        r_id, severity, entity_type, entity_id, entity_code, message, action, meta.control, gates
    )
