"""Snapshot en memoria de un programa: las reglas solo leen esto (puras y fáciles de testear)."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import date
from typing import Any

from sqlmodel import Session, SQLModel, select

from app.models import (
    ADR,
    ArchitectureElement,
    Baseline,
    Dependency,
    Gate,
    ORRCheck,
    Program,
    ProgramSettings,
    RACIActivity,
    RACIAssignment,
    RACIRole,
    RAIDItem,
    Requirement,
    Stakeholder,
    TestEvidence,
    TraceLink,
)

_VOLATILE = {"id", "created_at", "created_by", "updated_at", "updated_by"}


def _normalise(value: Any) -> Any:
    # 15 y 15.0 son el mismo valor: el ORM devuelve float tras recargar una columna REAL
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return value


def content_hash(obj: SQLModel) -> str:
    """Hash del contenido de negocio de un elemento (sin ids ni metadatos). Base de BASE-01.

    Se excluyen las claves foráneas (`*_id`): un import reasigna ids y no es un cambio de negocio.
    """
    data = {
        k: _normalise(v) for k, v in obj.model_dump().items() if k not in _VOLATILE and not k.endswith("_id")
    }
    raw = json.dumps(data, sort_keys=True, default=str, ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass
class ProgramContext:
    program: Program
    settings: ProgramSettings
    today: date
    stakeholders: list[Stakeholder] = field(default_factory=list)
    raci_roles: list[RACIRole] = field(default_factory=list)
    raci_activities: list[RACIActivity] = field(default_factory=list)
    raci_assignments: list[RACIAssignment] = field(default_factory=list)
    raid_items: list[RAIDItem] = field(default_factory=list)
    dependencies: list[Dependency] = field(default_factory=list)
    adrs: list[ADR] = field(default_factory=list)
    requirements: list[Requirement] = field(default_factory=list)
    arch_elements: list[ArchitectureElement] = field(default_factory=list)
    test_evidence: list[TestEvidence] = field(default_factory=list)
    trace_links: list[TraceLink] = field(default_factory=list)
    gates: list[Gate] = field(default_factory=list)
    orr_checks: list[ORRCheck] = field(default_factory=list)
    baseline: Baseline | None = None  # la más reciente

    # ----- utilidades de trazabilidad -----
    def linked_ids(self, entity_type: str, entity_id: int | None, other_type: str) -> set[int]:
        """Ids de `other_type` enlazados con la entidad, en cualquier dirección."""
        out: set[int] = set()
        for link in self.trace_links:
            if link.src_type == entity_type and link.src_id == entity_id and link.dst_type == other_type:
                out.add(link.dst_id)
            elif link.dst_type == entity_type and link.dst_id == entity_id and link.src_type == other_type:
                out.add(link.src_id)
        return out

    def is_linked(self, entity_type: str, entity_id: int | None, other_types: Iterable[str]) -> bool:
        return any(self.linked_ids(entity_type, entity_id, t) for t in other_types)

    def baseline_hashes(self) -> dict[str, str]:
        if self.baseline is None:
            return {}
        data: dict[str, str] = json.loads(self.baseline.element_hashes or "{}")
        return data

    def current_hashes(self) -> dict[str, str]:
        hashes = {f"requirement:{r.id}": content_hash(r) for r in self.requirements}
        hashes.update({f"arch_element:{a.id}": content_hash(a) for a in self.arch_elements})
        return hashes


def _all(session: Session, model: type[Any], program_id: int) -> list[Any]:
    return list(session.exec(select(model).where(model.program_id == program_id)).all())


def load_context(session: Session, program_id: int, today: date | None = None) -> ProgramContext:
    program = session.get(Program, program_id)
    if program is None:
        raise LookupError(f"Program {program_id} not found")
    settings = session.exec(select(ProgramSettings).where(ProgramSettings.program_id == program_id)).first()
    baseline = session.exec(
        select(Baseline).where(Baseline.program_id == program_id).order_by(Baseline.version.desc())  # type: ignore[attr-defined]
    ).first()
    return ProgramContext(
        program=program,
        settings=settings or ProgramSettings(program_id=program_id),
        today=today or date.today(),
        stakeholders=_all(session, Stakeholder, program_id),
        raci_roles=_all(session, RACIRole, program_id),
        raci_activities=_all(session, RACIActivity, program_id),
        raci_assignments=_all(session, RACIAssignment, program_id),
        raid_items=_all(session, RAIDItem, program_id),
        dependencies=_all(session, Dependency, program_id),
        adrs=_all(session, ADR, program_id),
        requirements=_all(session, Requirement, program_id),
        arch_elements=_all(session, ArchitectureElement, program_id),
        test_evidence=_all(session, TestEvidence, program_id),
        trace_links=_all(session, TraceLink, program_id),
        gates=_all(session, Gate, program_id),
        orr_checks=_all(session, ORRCheck, program_id),
        baseline=baseline,
    )
