"""Motor de reglas de governance (CLAUDE.md §6): evaluación, salud semanal (§11.1) y bloqueo de gates."""

from __future__ import annotations

from dataclasses import dataclass

from app.models.enums import RAG, ADRStatus, Severity

# Importar los módulos registra las reglas en REGISTRY
from app.rules import decisions, delivery, raci, raid, requirements  # noqa: F401
from app.rules.base import CONTROLS, REGISTRY, Rule, RuleResult
from app.rules.context import ProgramContext, content_hash, load_context


def evaluate(ctx: ProgramContext) -> list[RuleResult]:
    out: list[RuleResult] = []
    for r in REGISTRY.values():
        out.extend(r.check(ctx))
    order = {Severity.RED: 0, Severity.AMBER: 1}
    return sorted(out, key=lambda x: (order[x.severity], x.rule_id, x.entity_code))


@dataclass(frozen=True)
class ControlHealth:
    key: str
    label: str
    rag: RAG
    reasons: list[RuleResult]


def weekly_health(results: list[RuleResult]) -> list[ControlHealth]:
    """RAG de cada control = peor severidad de sus reglas abiertas; verde si no hay ninguna."""
    health = []
    for key, label in CONTROLS:
        reasons = [r for r in results if r.control == key]
        if any(r.severity == Severity.RED for r in reasons):
            rag = RAG.RED
        elif reasons:
            rag = RAG.AMBER
        else:
            rag = RAG.GREEN
        health.append(ControlHealth(key, label, rag, reasons))
    return health


def overall_rag(health: list[ControlHealth]) -> RAG:
    rags = {h.rag for h in health}
    if RAG.RED in rags:
        return RAG.RED
    if RAG.AMBER in rags:
        return RAG.AMBER
    return RAG.GREEN


def gate_blockers(ctx: ProgramContext, results: list[RuleResult], gate_code: str) -> list[RuleResult]:
    """Reglas rojas abiertas que impiden superar el gate. Un waiver registrado como ADR aprobada las anula."""
    gate = next((g for g in ctx.gates if g.code == gate_code), None)
    if gate is not None and gate.waiver_adr_id is not None:
        waiver = next((a for a in ctx.adrs if a.id == gate.waiver_adr_id), None)
        if waiver is not None and waiver.status == ADRStatus.APPROVED:
            return []
    return [r for r in results if r.severity == Severity.RED and gate_code in r.blocks_gates]


def can_pass_gate(ctx: ProgramContext, results: list[RuleResult], gate_code: str) -> bool:
    return not gate_blockers(ctx, results, gate_code)


__all__ = [
    "CONTROLS",
    "REGISTRY",
    "ControlHealth",
    "ProgramContext",
    "Rule",
    "RuleResult",
    "can_pass_gate",
    "content_hash",
    "evaluate",
    "gate_blockers",
    "load_context",
    "overall_rag",
    "weekly_health",
]
