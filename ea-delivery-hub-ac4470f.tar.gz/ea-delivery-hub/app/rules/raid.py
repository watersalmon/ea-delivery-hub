"""RAID-01..04 (guía §6, §8, §11.1)."""

from __future__ import annotations

from collections.abc import Iterator

from app.models import RAIDItem
from app.models.enums import RAIDType, Severity
from app.rules.base import ALL_GATES, RuleResult, result, rule
from app.rules.context import ProgramContext


def _open_risks(ctx: ProgramContext) -> Iterator[RAIDItem]:
    return (i for i in ctx.raid_items if i.type == RAIDType.RISK and not i.is_closed)


@rule("RAID-01", "Red risk without owner or response", "§6, §11.1", "raid", blocks_gates=ALL_GATES)
def red_risk_without_owner(ctx: ProgramContext) -> Iterator[RuleResult]:
    for risk in _open_risks(ctx):
        score = risk.score
        if score is None or score < ctx.settings.red_from:
            continue
        missing = [n for n, v in (("owner", risk.owner), ("response", risk.response)) if not v.strip()]
        if missing:
            yield result(
                "RAID-01",
                Severity.RED,
                "raid",
                risk.id,
                risk.code,
                f"Critical risk (score {score}) without {' and '.join(missing)}.",
                "Name a mitigation owner and an agreed response this week.",
            )


@rule("RAID-02", "Risk not in cause-event-consequence format", "§8", "raid")
def risk_incomplete(ctx: ProgramContext) -> Iterator[RuleResult]:
    for risk in _open_risks(ctx):
        fields = {
            "cause": risk.cause,
            "event": risk.event,
            "consequence": risk.consequence,
            "escalation trigger": risk.escalation_trigger,
        }
        missing = [name for name, value in fields.items() if not value.strip()]
        if risk.due_date is None:
            missing.append("due date")
        if missing:
            yield result(
                "RAID-02",
                Severity.AMBER,
                "raid",
                risk.id,
                risk.code,
                f"Risk is missing: {', '.join(missing)}.",
                "Rewrite as 'Due to [cause], there is a risk of [event], which could lead to [impact]'.",
            )


@rule("RAID-03", "Overdue RAID item", "§11.1", "raid")
def overdue_items(ctx: ProgramContext) -> Iterator[RuleResult]:
    for item in ctx.raid_items:
        if item.due_date and item.due_date < ctx.today and not item.is_closed:
            days = (ctx.today - item.due_date).days
            yield result(
                "RAID-03",
                Severity.AMBER,
                "raid",
                item.id,
                item.code,
                f"{item.type} overdue by {days} day(s) and still '{item.monitor_status}'.",
                "Update the status, re-plan the date or close it.",
            )


@rule("RAID-04", "Escalation trigger met", "§8, §8.1", "raid", blocks_gates=ALL_GATES)
def trigger_met(ctx: ProgramContext) -> Iterator[RuleResult]:
    escalated = {
        i.source_risk_id for i in ctx.raid_items if i.type == RAIDType.ESCALATION and i.source_risk_id
    }
    for risk in _open_risks(ctx):
        if risk.trigger_met and risk.id not in escalated:
            forum = risk.escalation_forum or "the agreed forum"
            yield result(
                "RAID-04",
                Severity.RED,
                "raid",
                risk.id,
                risk.code,
                f"Escalation trigger met ('{risk.escalation_trigger}') with no escalation raised.",
                f"Raise an Escalation to {forum} with options and a recommendation.",
            )
