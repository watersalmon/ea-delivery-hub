"""Fábrica de contextos de programa en memoria (sin BD) para testear reglas puras."""

from __future__ import annotations

from datetime import date

import pytest

from app.models import Program, ProgramSettings, Stakeholder
from app.rules import ProgramContext, evaluate

TODAY = date(2026, 10, 16)


def make_ctx(**kwargs: object) -> ProgramContext:
    program = kwargs.pop("program", None) or Program(
        id=1,
        code="TEST",
        name="Test program",
        client="Fictitious client",
        phase=1,
        operations_owner="Ops lead",
        operations_engaged=True,
    )
    ctx = ProgramContext(
        program=program,  # type: ignore[arg-type]
        settings=ProgramSettings(program_id=1),
        today=TODAY,
        # Por defecto un plan de comunicación completo, para que STK-01 no contamine otros tests
        stakeholders=[
            Stakeholder(id=1, program_id=1, name="Decider", is_decision_maker=True),
            Stakeholder(id=2, program_id=1, name="Sceptic", stance="Detractor"),
        ],
    )
    for key, value in kwargs.items():
        setattr(ctx, key, value)
    return ctx


def fired(ctx: ProgramContext, rule_id: str) -> list:  # type: ignore[type-arg]
    return [r for r in evaluate(ctx) if r.rule_id == rule_id]


@pytest.fixture
def ctx_factory():  # type: ignore[no-untyped-def]
    return make_ctx
