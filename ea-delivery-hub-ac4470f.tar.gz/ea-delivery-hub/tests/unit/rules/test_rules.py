"""Cada regla de CLAUDE.md §6 tiene un caso que no la dispara (pasa) y otro que la dispara (falla)."""

from __future__ import annotations

from datetime import UTC, date, datetime, timedelta

from app.models import (
    ADR,
    ArchitectureElement,
    Baseline,
    Dependency,
    Program,
    RACIActivity,
    RACIAssignment,
    RACIRole,
    RAIDItem,
    Requirement,
    Stakeholder,
    TestEvidence,
    TraceLink,
)
from app.models.enums import Severity
from app.rules import content_hash
from tests.unit.rules.conftest import TODAY, fired, make_ctx

# ---------------------------------------------------------------- RACI


def _raci(values: list[str]) -> dict[str, list]:  # type: ignore[type-arg]
    roles = [RACIRole(id=i + 1, program_id=1, name=f"Role {i + 1}") for i in range(len(values))]
    act = RACIActivity(id=1, program_id=1, name="Architecture governance")
    asg = [
        RACIAssignment(id=i + 1, program_id=1, activity_id=1, role_id=i + 1, value=v)
        for i, v in enumerate(values)
    ]
    return {"raci_roles": roles, "raci_activities": [act], "raci_assignments": asg}


def test_raci01_passes_with_single_accountable() -> None:
    assert not fired(make_ctx(**_raci(["A/R", "C", "C", "C"])), "RACI-01")


def test_raci01_fails_with_two_accountables() -> None:
    res = fired(make_ctx(**_raci(["A/R", "C", "C", "A/C"])), "RACI-01")
    assert len(res) == 1 and res[0].severity == Severity.RED


def test_raci01_fails_with_no_accountable() -> None:
    assert fired(make_ctx(**_raci(["R", "C", "I"])), "RACI-01")


def test_raci02_passes_with_responsible() -> None:
    assert not fired(make_ctx(**_raci(["A", "R", "C"])), "RACI-02")


def test_raci02_fails_without_responsible() -> None:
    res = fired(make_ctx(**_raci(["A/C", "C", "I"])), "RACI-02")
    assert len(res) == 1 and res[0].severity == Severity.AMBER


# ---------------------------------------------------------------- RAID


def _risk(**kw: object) -> RAIDItem:
    base: dict[str, object] = {
        "id": 10,
        "program_id": 1,
        "type": "Risk",
        "code": "RK-010",
        "title": "Power readiness",
        "owner": "Facilities lead",
        "response": "Temporary generators",
        "cause": "Late grid upgrade",
        "event": "Insufficient power at go-live",
        "consequence": "Go-live slips",
        "escalation_trigger": "No grid date by 1 Nov",
        "escalation_forum": "SteerCo",
        "probability": 3,
        "impact": 3,
        "due_date": TODAY + timedelta(days=10),
        "monitor_status": "Action Required",
    }
    base.update(kw)
    return RAIDItem(**base)


def test_raid01_passes_when_red_risk_is_owned() -> None:
    assert not fired(make_ctx(raid_items=[_risk()]), "RAID-01")


def test_raid01_fails_when_red_risk_has_no_owner() -> None:
    res = fired(make_ctx(raid_items=[_risk(owner="")]), "RAID-01")
    assert res and res[0].severity == Severity.RED


def test_raid01_ignores_amber_score() -> None:
    assert not fired(make_ctx(raid_items=[_risk(owner="", probability=2, impact=3)]), "RAID-01")


def test_raid02_passes_with_complete_risk() -> None:
    assert not fired(make_ctx(raid_items=[_risk()]), "RAID-02")


def test_raid02_fails_without_cause_event_consequence() -> None:
    res = fired(make_ctx(raid_items=[_risk(cause="", consequence="")]), "RAID-02")
    assert res and "cause" in res[0].message and "consequence" in res[0].message


def test_raid03_passes_when_not_overdue() -> None:
    assert not fired(make_ctx(raid_items=[_risk()]), "RAID-03")


def test_raid03_fails_when_overdue_and_open() -> None:
    res = fired(make_ctx(raid_items=[_risk(due_date=TODAY - timedelta(days=3))]), "RAID-03")
    assert res and "3 day" in res[0].message


def test_raid03_ignores_closed_items() -> None:
    item = _risk(due_date=TODAY - timedelta(days=3), monitor_status="Closed")
    assert not fired(make_ctx(raid_items=[item]), "RAID-03")


def test_raid04_passes_when_escalation_raised() -> None:
    esc = RAIDItem(id=11, program_id=1, type="Escalation", code="ES-001", title="x", source_risk_id=10)
    assert not fired(make_ctx(raid_items=[_risk(trigger_met=True), esc]), "RAID-04")


def test_raid04_fails_when_trigger_met_without_escalation() -> None:
    res = fired(make_ctx(raid_items=[_risk(trigger_met=True)]), "RAID-04")
    assert res and "SteerCo" in res[0].suggested_action


# ---------------------------------------------------------------- DEP


def _dep(**kw: object) -> Dependency:
    base: dict[str, object] = {
        "id": 1,
        "program_id": 1,
        "code": "DEP-001",
        "title": "WAN circuits",
        "source": "Networking",
        "target": "Telco provider",
        "external": True,
        "commitment_verified": True,
    }
    base.update(kw)
    return Dependency(**base)


def test_dep01_passes_with_verified_commitment() -> None:
    assert not fired(make_ctx(dependencies=[_dep()]), "DEP-01")


def test_dep01_fails_amber_without_commitment() -> None:
    res = fired(make_ctx(dependencies=[_dep(commitment_verified=False)]), "DEP-01")
    assert res[0].severity == Severity.AMBER


def test_dep01_fails_red_on_critical_path() -> None:
    res = fired(make_ctx(dependencies=[_dep(commitment_verified=False, critical_path=True)]), "DEP-01")
    assert res[0].severity == Severity.RED


# ---------------------------------------------------------------- ADR


def _adr(**kw: object) -> ADR:
    base: dict[str, object] = {
        "id": 1,
        "program_id": 1,
        "code": "ADR-001",
        "title": "Backup target",
        "status": "Proposed",
        "owner": "EA",
        "due_date": TODAY + timedelta(days=7),
        "submitted_at": TODAY - timedelta(days=2),
    }
    base.update(kw)
    return ADR(**base)


def test_adr01_passes_with_owner_and_date() -> None:
    assert not fired(make_ctx(adrs=[_adr(critical_path=True)]), "ADR-01")


def test_adr01_fails_without_owner_on_critical_path() -> None:
    res = fired(make_ctx(adrs=[_adr(critical_path=True, owner="", due_date=None)]), "ADR-01")
    assert res[0].severity == Severity.RED and "owner and due date" in res[0].message


def test_adr02_passes_within_sla() -> None:
    assert not fired(make_ctx(adrs=[_adr()]), "ADR-02")


def test_adr02_fails_beyond_sla() -> None:
    res = fired(make_ctx(adrs=[_adr(submitted_at=TODAY - timedelta(days=25))]), "ADR-02")
    assert res and "25 days" in res[0].message


def test_adr03_passes_with_impacts() -> None:
    adr = _adr(status="Approved", impacted_artifacts="HLD §4, RTM")
    assert not fired(make_ctx(adrs=[adr]), "ADR-03")


def test_adr03_fails_without_impacts() -> None:
    assert fired(make_ctx(adrs=[_adr(status="Approved")]), "ADR-03")


# ---------------------------------------------------------------- RTM


def _req(**kw: object) -> Requirement:
    base: dict[str, object] = {
        "id": 1,
        "program_id": 1,
        "code": "REQ-001",
        "statement": "Self-service VM provisioning",
        "priority": "Must",
    }
    base.update(kw)
    return Requirement(**base)


def _link(src: str, sid: int, dst: str, did: int, **kw: object) -> TraceLink:
    return TraceLink(program_id=1, src_type=src, src_id=sid, dst_type=dst, dst_id=did, **kw)


FULL_TRACE = [_link("objective", 1, "requirement", 1), _link("requirement", 1, "arch_element", 1)]


def test_rtm01_passes_when_traced() -> None:
    assert not fired(make_ctx(requirements=[_req()], trace_links=FULL_TRACE), "RTM-01")


def test_rtm01_fails_red_for_orphan_must() -> None:
    res = fired(make_ctx(requirements=[_req()]), "RTM-01")
    assert res[0].severity == Severity.RED


def test_rtm01_fails_amber_for_orphan_should() -> None:
    res = fired(make_ctx(requirements=[_req(priority="Should")], trace_links=FULL_TRACE[:1]), "RTM-01")
    assert res[0].severity == Severity.AMBER and "architecture element" in res[0].message


def test_rtm02_passes_with_evidence_at_g5() -> None:
    program = Program(
        id=1, code="T", name="T", client="C", phase=5, operations_owner="x", operations_engaged=True
    )
    links = [*FULL_TRACE, _link("requirement", 1, "test_evidence", 1)]
    ctx = make_ctx(program=program, requirements=[_req()], trace_links=links)
    ctx.test_evidence = [TestEvidence(id=1, program_id=1, code="TE-001", title="UAT", result="Pass")]
    assert not fired(ctx, "RTM-02")


def test_rtm02_fails_without_evidence_at_g5() -> None:
    program = Program(
        id=1, code="T", name="T", client="C", phase=5, operations_owner="x", operations_engaged=True
    )
    assert fired(make_ctx(program=program, requirements=[_req()], trace_links=FULL_TRACE), "RTM-02")


def test_rtm02_not_evaluated_before_phase_5() -> None:
    assert not fired(make_ctx(requirements=[_req()], trace_links=FULL_TRACE), "RTM-02")


def test_rtm03_passes_with_measurable_nfr() -> None:
    nfr = _req(code="NFR-001", kind="NFR", measurable_criterion=">= 99.95% monthly availability")
    assert not fired(make_ctx(requirements=[nfr], trace_links=FULL_TRACE), "RTM-03")


def test_rtm03_fails_with_vague_nfr() -> None:
    nfr = _req(code="NFR-001", kind="NFR", statement="The platform must be highly available")
    assert fired(make_ctx(requirements=[nfr], trace_links=FULL_TRACE), "RTM-03")


# ---------------------------------------------------------------- STK / OPS


def test_stk01_passes_with_deciders_and_detractors() -> None:
    assert not fired(make_ctx(), "STK-01")


def test_stk01_fails_without_detractors() -> None:
    only_sponsor = [Stakeholder(id=1, program_id=1, name="CIO", stance="Sponsor", is_decision_maker=True)]
    res = fired(make_ctx(stakeholders=only_sponsor), "STK-01")
    assert res and "detractors" in res[0].message


def test_ops01_passes_with_engaged_owner() -> None:
    program = Program(
        id=1, code="T", name="T", client="C", phase=4, operations_owner="Ops", operations_engaged=True
    )
    assert not fired(make_ctx(program=program), "OPS-01")


def test_ops01_fails_without_owner_in_delivery() -> None:
    program = Program(id=1, code="T", name="T", client="C", phase=4)
    res = fired(make_ctx(program=program), "OPS-01")
    assert res[0].severity == Severity.RED and "G5" in res[0].blocks_gates


# ---------------------------------------------------------------- BASE


def _baseline_ctx(changed: bool, linked: bool) -> object:
    req = _req()
    ae = ArchitectureElement(id=1, program_id=1, code="AE-001", name="Compute cluster")
    approved = datetime(2026, 9, 1, tzinfo=UTC)
    baseline = Baseline(
        id=1,
        program_id=1,
        version=1,
        sha256="x",
        payload="{}",
        approved_at=approved,
        element_hashes=f'{{"requirement:1": "{content_hash(req)}", "arch_element:1": "{content_hash(ae)}"}}',
    )
    if changed:
        req.statement = "Self-service VM provisioning with GPU profiles"
    links = list(FULL_TRACE)
    if linked:
        change = RAIDItem(id=50, program_id=1, type="Change", code="CH-001", title="Add GPU profiles")
        links.append(_link("raid", 50, "requirement", 1, created_at=datetime(2026, 9, 10, tzinfo=UTC)))
        return make_ctx(
            requirements=[req], arch_elements=[ae], baseline=baseline, trace_links=links, raid_items=[change]
        )
    return make_ctx(requirements=[req], arch_elements=[ae], baseline=baseline, trace_links=links)


def test_base01_passes_when_unchanged() -> None:
    assert not fired(_baseline_ctx(changed=False, linked=False), "BASE-01")  # type: ignore[arg-type]


def test_base01_passes_when_change_is_linked() -> None:
    assert not fired(_baseline_ctx(changed=True, linked=True), "BASE-01")  # type: ignore[arg-type]


def test_base01_fails_when_changed_without_change() -> None:
    res = fired(_baseline_ctx(changed=True, linked=False), "BASE-01")  # type: ignore[arg-type]
    assert res and res[0].entity_code == "REQ-001"


def test_registry_has_all_rules() -> None:
    from app.rules import REGISTRY

    expected = {
        "RACI-01", "RACI-02", "RAID-01", "RAID-02", "RAID-03", "RAID-04", "DEP-01", "ADR-01",
        "ADR-02", "ADR-03", "RTM-01", "RTM-02", "RTM-03", "STK-01", "OPS-01", "BASE-01", "ORR-01",
    }  # fmt: skip
    assert set(REGISTRY) == expected


def test_registry_is_date_independent() -> None:
    # Las reglas usan ctx.today, nunca date.today(): el resultado es reproducible
    ctx = make_ctx(raid_items=[_risk(due_date=date(2026, 10, 15))])
    assert fired(ctx, "RAID-03")


def test_content_hash_ignores_int_float_representation() -> None:
    a = _req(kind="NFR", target_value=15)
    b = _req(kind="NFR", target_value=15.0)
    assert content_hash(a) == content_hash(b)


def test_orr01_passes_without_red_checks() -> None:
    from app.models import ORRCheck

    checks = [ORRCheck(id=1, program_id=1, dimension="Backup", criterion="Restore drill", status="amber")]
    assert not fired(make_ctx(orr_checks=checks), "ORR-01")


def test_orr01_fails_with_red_check_and_blocks_g5() -> None:
    from app.models import ORRCheck

    checks = [ORRCheck(id=1, program_id=1, dimension="Runbooks", criterion="Runbooks accepted", status="red")]
    res = fired(make_ctx(orr_checks=checks), "ORR-01")
    assert res and res[0].blocks_gates == frozenset({"G5"})
