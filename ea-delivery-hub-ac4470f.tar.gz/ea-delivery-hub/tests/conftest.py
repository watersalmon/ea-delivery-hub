from __future__ import annotations

import os
from collections.abc import Iterator

import pytest
from fastapi.testclient import TestClient

# BD efímera para los tests (antes de importar la app). Se fuerza: dentro del contenedor DATABASE_URL apunta
# a /data/ea.db y los tests vaciarían los datos de la app.
os.environ["DATABASE_URL"] = "sqlite://"


@pytest.fixture
def client() -> Iterator[TestClient]:
    from app.main import app

    with TestClient(app) as c:
        yield c


@pytest.fixture(autouse=True)
def _fresh_database() -> Iterator[None]:
    """Cada test arranca con una BD en memoria vacía: los tests no dependen del orden."""
    from sqlmodel import SQLModel

    import app.models  # noqa: F401
    from app.db import get_engine

    engine = get_engine()
    SQLModel.metadata.drop_all(engine)
    SQLModel.metadata.create_all(engine)
    yield
