"""Smoke de pantallas con Playwright + capturas en docs/screenshots/.

Se ejecuta en el servicio `e2e` (make e2e) contra la app levantada y con el seed cargado (BASE_URL).
"""

from __future__ import annotations

import os
import re
from pathlib import Path

import pytest
from playwright.sync_api import Page, expect

BASE_URL = os.getenv("BASE_URL", "http://localhost:8080")
SHOTS = Path(os.getenv("SCREENSHOTS_DIR", "docs/screenshots"))
PHASE = os.getenv("PHASE", "fase5")
# htmx activa el contenido que acaba de insertar en el siguiente tick; un usuario nunca es tan rápido como
# Playwright, así que damos ese margen antes de interactuar con el editor recién abierto.
EDITOR_READY_MS = 150

SCREENS = [
    ("portfolio", "/", "Program Portfolio"),
    ("dashboard", "/dashboard", "Sovereign Private Cloud"),
    ("raid_risks", "/raid", "RAID & Dependencies"),
    ("raid_actions", "/raid?tab=actions", "RAID & Dependencies"),
    ("dependencies", "/raid/dependencies", "Dependencies"),
    ("raci", "/stakeholders?tab=raci", "Stakeholders, RACI & Comms"),
    ("power_interest", "/stakeholders?tab=map", "Stakeholders, RACI & Comms"),
    ("goals_sdm", "/goals", "Goals & Solution Dependency Map"),
    ("rtm", "/rtm", "Requirements & RTM"),
    ("adr_list", "/adr", "Decisions (ADR)"),
    ("adr_detail", "/adr/ADR-001", "ADR-001 · Use immutable object storage as primary backup target"),
    ("design_authority", "/design-authority", "Architecture Design Authority"),
    ("gates_roadmap", "/gates", "Gates & Roadmap"),
    ("brief", "/brief", "Architecture Brief"),
    ("first_10_days", "/onboarding", "First 10 days · engagement setup"),
    ("architecture", "/architecture", "Architecture (HLD/LLD)"),
    ("orr", "/orr", "Operational Readiness Review"),
    ("handover", "/handover", "As-built & Handover"),
    ("lessons", "/lessons", "Lessons Learned"),
    ("template_library", "/templates", "Template Library"),
    ("playbook", "/playbook/10-phases", "EA Playbook · Lifecycle by phase"),
    ("admin", "/admin", "Administration"),
]


@pytest.fixture(autouse=True)
def _setup(page: Page) -> None:
    SHOTS.mkdir(parents=True, exist_ok=True)
    page.set_viewport_size({"width": 1440, "height": 900})


@pytest.mark.parametrize(("name", "path", "heading"), SCREENS)
def test_screen_renders(page: Page, name: str, path: str, heading: str) -> None:
    errors: list[str] = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.goto(f"{BASE_URL}{path}")
    expect(page.get_by_role("heading", level=1)).to_have_text(heading)
    expect(page.get_by_test_id("classification-footer")).to_contain_text("Internal Use - Confidential")
    page.screenshot(path=str(SHOTS / f"{PHASE}_{name}.png"), full_page=True)
    assert errors == []


def test_shell_at_1024(page: Page) -> None:
    page.set_viewport_size({"width": 1024, "height": 800})
    page.goto(f"{BASE_URL}/dashboard")
    expect(page.get_by_role("complementary", name="Main navigation")).to_be_visible()
    page.screenshot(path=str(SHOTS / f"{PHASE}_dashboard_1024.png"))


def test_ctrl_k_search(page: Page) -> None:
    page.goto(f"{BASE_URL}/dashboard")
    page.keyboard.press("Control+k")
    expect(page.locator("#global-search")).to_be_focused()
    page.keyboard.type("RK-004")
    expect(page.locator("#search-results [role=option]").first).to_contain_text("RK-004")


def test_inline_edit_risk_owner(page: Page) -> None:
    page.goto(f"{BASE_URL}/raid")
    row = page.locator("tr#RK-005")
    row.locator('td[data-col="owner"]').click()
    field = row.locator('td[data-col="owner"] input')
    field.wait_for()
    page.wait_for_timeout(EDITOR_READY_MS)
    field.fill("Lucía Ferrán (Networking)")
    field.press("Enter")
    expect(page.locator('tr#RK-005 td[data-col="owner"]')).to_have_text("Lucía Ferrán (Networking)")


def test_matrix_cell_filters_and_columns_toggle(page: Page) -> None:
    page.goto(f"{BASE_URL}/raid")
    page.get_by_label("Probability 3, impact 3").click()
    expect(page.locator("tbody tr[id^=RK-]")).to_have_count(2)
    page.get_by_label("Show cause / event / consequence / trigger / forum").check()
    expect(page.locator('th[data-col="cause"]')).to_be_visible()
    page.screenshot(path=str(SHOTS / f"{PHASE}_raid_filtered_extra_columns.png"), full_page=True)


def test_column_filter(page: Page) -> None:
    page.goto(f"{BASE_URL}/raid")
    page.locator('th[data-col="monitor_status"] .filter-btn').click()
    page.locator("[data-filter-input='11']").fill("Monitoring")
    expect(page.locator("table[data-sheet] tbody tr:not([hidden])")).to_have_count(3)


def test_raci_live_validation(page: Page) -> None:
    page.goto(f"{BASE_URL}/stakeholders?tab=raci")
    row = page.locator("tr", has_text="Capacity planning reviews")
    expect(row).to_contain_text("RACI-02")
    row.locator("td.editable").nth(2).click()
    row.locator("select").wait_for()
    page.wait_for_timeout(EDITOR_READY_MS)
    row.locator("select").select_option("R")
    expect(page.locator("tr", has_text="Capacity planning reviews")).to_contain_text("OK")


def test_export_menu_downloads_raid_log(page: Page) -> None:
    page.goto(f"{BASE_URL}/raid")
    page.get_by_role("button", name="Export").click()
    page.screenshot(path=str(SHOTS / f"{PHASE}_export_menu.png"))
    with page.expect_download() as info:
        page.get_by_role("menuitem", name="With program data").first.click()
    assert info.value.suggested_filename.endswith(".xlsx")
    assert "_RAID-Log_v" in info.value.suggested_filename


def test_design_authority_meeting_mode(page: Page) -> None:
    page.goto(f"{BASE_URL}/design-authority")
    page.locator("a", has_text=re.compile(r"\d{2} \w{3} \d{4}")).first.click()
    if page.get_by_role("button", name="Start meeting mode").count():
        page.get_by_role("button", name="Start meeting mode").click()
    expect(page.get_by_role("heading", name="Decisions, one by one")).to_be_visible()
    page.get_by_role("button", name="Start").click()
    page.wait_for_timeout(1200)
    page.screenshot(path=str(SHOTS / f"{PHASE}_design_authority_meeting_mode.png"), full_page=True)


def test_gate_pass_is_blocked(page: Page) -> None:
    page.goto(f"{BASE_URL}/gates")
    page.get_by_role("button", name="Pass G4").click()
    expect(page.get_by_role("alert")).to_contain_text("G4 is blocked by")
    page.screenshot(path=str(SHOTS / f"{PHASE}_gate_blocked.png"))


# ------------------------------------------------------------------ huecos de edición (manual de usuario)


def test_risk_response_inline_edit(page: Page) -> None:
    page.goto(f"{BASE_URL}/raid")
    cell = page.locator('tr#RK-004 [data-col="response"]')
    cell.click()
    field = cell.locator("textarea")
    field.wait_for()
    page.wait_for_timeout(EDITOR_READY_MS)
    field.fill("Order temporary UPS capacity")
    field.press("Enter")
    expect(page.locator('tr#RK-004 [data-col="response"]')).to_contain_text("Order temporary UPS capacity")


def test_raise_escalation_from_risk(page: Page) -> None:
    page.goto(f"{BASE_URL}/raid")
    page.locator("tr#RK-001").get_by_role("button", name="Raise escalation").click()
    expect(page).to_have_url(re.compile(r"tab=escalation"))
    expect(page.locator("tbody")).to_contain_text("RK-001")
    page.screenshot(path=str(SHOTS / f"{PHASE}_raid_escalation.png"), full_page=True)


def test_requirement_edit_page(page: Page) -> None:
    page.goto(f"{BASE_URL}/rtm")
    page.get_by_label("Edit REQ-001").click()
    expect(page.get_by_role("heading", name="Edit requirement REQ-001")).to_be_visible()
    page.screenshot(path=str(SHOTS / f"{PHASE}_requirement_edit.png"), full_page=True)
    page.get_by_label("Source (SOW, workshop, presales…)").fill("SOW §3.1")
    page.get_by_role("button", name="Save").click()
    expect(page).to_have_url(re.compile(r"/rtm#REQ-001"))


def test_outcomes_and_workstreams_screens(page: Page) -> None:
    page.goto(f"{BASE_URL}/goals")
    page.get_by_label("Outcome", exact=True).fill("Self-service provisioning in under a day")
    page.get_by_role("button", name="Outcome", exact=True).click()
    expect(page.locator("body")).to_contain_text("Self-service provisioning in under a day")
    page.screenshot(path=str(SHOTS / f"{PHASE}_goals_outcomes.png"), full_page=True)
    page.goto(f"{BASE_URL}/admin")
    page.get_by_label("Workstream name").fill("Service Management")
    page.get_by_role("button", name="Workstream", exact=True).click()
    expect(page.locator("#workstreams")).to_contain_text("Service Management")
    page.locator("#workstreams").screenshot(path=str(SHOTS / f"{PHASE}_admin_workstreams.png"))


# ------------------------------------------------------------------ borrado con dependencias (PDR-011)


def test_delete_shows_dependencies_and_removes_the_record(page: Page) -> None:
    page.goto(f"{BASE_URL}/admin")
    page.get_by_label("Delete Networking").click()
    expect(page.get_by_role("heading", name="Delete workstream")).to_be_visible()
    expect(page.locator("body")).to_contain_text("loses its workstream")
    page.screenshot(path=str(SHOTS / f"{PHASE}_delete_confirm.png"), full_page=True)
    page.get_by_role("link", name="Cancel").click()
    page.goto(f"{BASE_URL}/raid/dependencies")
    page.get_by_label("Delete DEP-001").click()
    page.get_by_role("button", name="Delete", exact=True).click()
    expect(page.locator("[role=status]")).to_contain_text("DEP-001")
    expect(page.locator("tr#DEP-001")).to_have_count(0)
