"""Fase 0: healthcheck y shell vacío (sidebar por ciclo de vida, tokens, sin CDN)."""

from __future__ import annotations

import re

import pytest
from fastapi.testclient import TestClient

from app.navigation import NAVIGATION


def test_health_ok(client: TestClient) -> None:
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"
    assert r.json()["db"] == "ok"


def test_home_renders_shell(client: TestClient) -> None:
    html = client.get("/").text
    assert "EA Delivery Hub" in html
    assert "Architecture &amp; Delivery Governance" in html
    for group in ("Main", "Define", "Govern", "Deliver &amp; Close", "Enablement"):
        assert group in html
    assert "Internal Use - Confidential" in html
    assert 'id="global-search"' in html


def test_sidebar_follows_lifecycle_order(client: TestClient) -> None:
    html = client.get("/").text
    positions = [html.index(f'data-nav="{i.slug}"') for g in NAVIGATION for i in g.items if i.feature is None]
    assert positions == sorted(positions)


def test_copilot_hidden_by_default(client: TestClient) -> None:
    assert 'data-nav="copilot"' not in client.get("/").text
    assert client.get("/copilot").status_code == 404


@pytest.mark.parametrize("slug", [i.slug for g in NAVIGATION for i in g.items if i.feature is None])
def test_every_nav_entry_resolves(client: TestClient, slug: str) -> None:
    url = "/" if slug == "portfolio" else f"/{slug}"
    r = client.get(url)
    assert r.status_code == 200
    assert 'aria-current="page"' in r.text


def test_no_cdn_at_runtime(client: TestClient) -> None:
    html = client.get("/raid").text
    external = re.findall(r'(?:src|href)="(https?://[^"]+)"', html)
    assert external == []


def test_static_vendor_served(client: TestClient) -> None:
    for path in (
        "/static/vendor/htmx/htmx.min.js",
        "/static/vendor/alpine/alpine.min.js",
        "/static/vendor/lucide/sprite.svg",
        "/static/css/tokens.css",
    ):
        assert client.get(path).status_code == 200, path


def test_tokens_define_brand_and_rag() -> None:
    from app.config import APP_DIR

    css = (APP_DIR / "static/css/tokens.css").read_text(encoding="utf-8")
    for token in ("--dell-blue", "--navy-900", "--row-alt", "--rag-green", "--rag-amber", "--rag-red"):
        assert token in css
