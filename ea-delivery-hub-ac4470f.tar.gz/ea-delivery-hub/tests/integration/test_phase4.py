"""Fase 4: ADR, Design Authority, Gates, Brief, 10 días, revisión HLD/LLD, altas y plantillas T01-T15."""

from __future__ import annotations

import re
from collections.abc import Iterator
from io import BytesIO

import pytest
from docx import Document
from fastapi.testclient import TestClient
from openpyxl import load_workbook
from sqlmodel import Session, col, select

from app.db import get_engine, init_db
from app.models import (
    ADR,
    ADRStatusChange,
    ArchitectureDiagram,
    Baseline,
    DesignReview,
    Gate,
    Meeting,
    MeetingDecision,
    Program,
    RAIDItem,
    RAIDUpdate,
    Requirement,
    ReviewItem,
    Stakeholder,
    TraceLink,
)
from app.services import seed


@pytest.fixture
def client() -> Iterator[TestClient]:
    from app.main import app

    init_db()
    with Session(get_engine()) as s:
        seed.run(s)
    with TestClient(app) as c:
        yield c


def _s() -> Session:
    return Session(get_engine())


def _pid(code: str = "SPC-AASD") -> int:
    with _s() as s:
        return s.exec(select(Program.id).where(Program.code == code)).one()  # type: ignore[return-value]


def _adr(code: str) -> ADR:
    with _s() as s:
        return s.exec(select(ADR).where(ADR.program_id == _pid(), ADR.code == code)).one()


def _error(r) -> str:  # type: ignore[no-untyped-def]
    from urllib.parse import unquote

    m = re.search(r"error=([^&#]+)", r.headers.get("location", ""))
    return unquote(m.group(1)) if m else ""


# ------------------------------------------------------------------ ADR


def test_adr_catalogue_filters(client: TestClient) -> None:
    html = client.get("/adr?status=Proposed&critical=true").text
    assert re.findall(r'<tr id="(ADR-\d+)"', html) == ["ADR-003"]


def test_adr_invalid_transition_is_rejected(client: TestClient) -> None:
    r = client.post("/adr/ADR-003/status", data={"to": "Approved"}, follow_redirects=False)
    assert "cannot move from 'Proposed' to 'Approved'" in _error(r)
    assert _adr("ADR-003").status == "Proposed"


def test_critical_adr_needs_owner_and_date_before_approval(client: TestClient) -> None:
    client.post("/adr/ADR-003/status", data={"to": "Under Review"})
    r = client.post("/adr/ADR-003/status", data={"to": "Approved"}, follow_redirects=False)
    assert "ADR-01" in _error(r)
    adr = _adr("ADR-003")
    client.post(f"/edit/adr/{adr.id}/owner", data={"value": "Jorge Salvat"})
    client.post(f"/edit/adr/{adr.id}/due_date", data={"value": "2026-11-30"})
    client.post("/adr/ADR-003/status", data={"to": "Approved", "note": "SteerCo"})
    adr = _adr("ADR-003")
    assert adr.status == "Approved" and adr.approved_at is not None
    with _s() as s:
        steps = [h.to_status for h in s.exec(select(ADRStatusChange).where(ADRStatusChange.adr_id == adr.id)
                                             .order_by(col(ADRStatusChange.id))).all()]  # fmt: skip
    assert steps[-2:] == ["Under Review", "Approved"]


def test_new_adr_form_validates_and_creates(client: TestClient) -> None:
    r = client.post("/adr/new", data={"title": "x", "context": "y", "critical_path": "on"})
    assert r.status_code == 422 and "ADR-01" in r.text
    r = client.post("/adr/new", data={"title": "Use EVPN multi-site", "context": "WAN design", "option_1": "EVPN",
                                      "option_2": "Static routing"}, follow_redirects=False)  # fmt: skip
    assert r.headers["location"] == "/adr/ADR-007"
    assert _adr("ADR-007").status == "Proposed"


def test_tradeoff_score_updates_totals(client: TestClient) -> None:
    html = client.get("/adr/ADR-001").text
    option_id = re.search(r'hx-post="/adr/option/(\d+)/score/security"', html).group(1)  # type: ignore[union-attr]
    r = client.post(f"/adr/option/{option_id}/score/security", data={"value": "1"})
    assert r.status_code == 200 and "Total" in r.text
    assert client.post(f"/adr/option/{option_id}/score/security", data={"value": "9"}).status_code == 422


# ------------------------------------------------------------------ Gates


def test_gate_is_blocked_by_red_rules(client: TestClient) -> None:
    r = client.post("/gates/G4/pass", follow_redirects=False)
    assert "G4 is blocked by" in _error(r) and "RAID-01" in _error(r)
    with _s() as s:
        assert s.get(Program, _pid()).phase == 4  # type: ignore[union-attr]


def test_waiver_must_be_an_approved_adr(client: TestClient) -> None:
    proposed = _adr("ADR-003")
    r = client.post("/gates/G4/waiver", data={"adr_id": str(proposed.id)}, follow_redirects=False)
    assert "approved ADR" in _error(r)


def test_gate_passes_with_waiver_and_advances_phase(client: TestClient) -> None:
    approved = _adr("ADR-001")
    client.post("/gates/G4/waiver", data={"adr_id": str(approved.id)})
    r = client.post("/gates/G4/pass", follow_redirects=False)
    assert _error(r) == ""
    with _s() as s:
        gates = {g.code: g for g in s.exec(select(Gate).where(Gate.program_id == _pid())).all()}
        assert gates["G4"].status == "Passed" and gates["G5"].status == "In Progress"
        assert s.get(Program, _pid()).phase == 5  # type: ignore[union-attr]


def test_gate_without_red_rules_passes(client: TestClient) -> None:
    client.cookies.set("ea_program", str(_pid("EDP-CMM")))
    r = client.post("/gates/G1/pass", follow_redirects=False)
    assert _error(r) == ""
    with _s() as s:
        assert s.get(Program, _pid("EDP-CMM")).phase == 2  # type: ignore[union-attr]


def test_only_active_gate_can_be_passed(client: TestClient) -> None:
    client.cookies.set("ea_program", str(_pid("EDP-CMM")))
    r = client.post("/gates/G3/pass", follow_redirects=False)
    assert "Only the active gate" in _error(r)


# ------------------------------------------------------------------ Design Authority


def test_design_authority_close_generates_minutes_and_actions(client: TestClient) -> None:
    keys, vdi = _adr("ADR-003"), _adr("ADR-004")
    r = client.post("/design-authority/new", data={"meeting_date": "2026-10-23", "adr_id": [str(keys.id), str(vdi.id)]},
                    follow_redirects=False)  # fmt: skip
    mid = int(r.headers["location"].rsplit("/", 1)[1])
    assert _adr("ADR-003").status == "Under Review"
    client.post(f"/design-authority/{mid}/start")
    with _s() as s:
        decisions = s.exec(
            select(MeetingDecision)
            .where(MeetingDecision.meeting_id == mid)
            .order_by(col(MeetingDecision.order))
        ).all()
    # Cerrar con resultados pendientes no se permite
    assert "pending" in _error(client.post(f"/design-authority/{mid}/close", follow_redirects=False))
    d_keys, d_vdi = decisions
    for field, value in (("outcome", "Approved"), ("owner", "Jorge Salvat"), ("due_date", "2026-11-15"),
                         ("conditions", "External KMS in the customer HSM")):  # fmt: skip
        client.post(f"/edit/meeting_decision/{d_keys.id}/{field}", data={"value": value})
    client.post(f"/edit/meeting_decision/{d_vdi.id}/outcome", data={"value": "Deferred"})
    for i in range(5):
        client.post(f"/design-authority/{mid}/participant/{i}")
    client.post(
        f"/design-authority/{mid}/action", data={"title": "Share the HSM sizing", "owner": "Pablo Ibarra"}
    )
    assert _error(client.post(f"/design-authority/{mid}/close", follow_redirects=False)) == ""

    assert _adr("ADR-003").status == "Approved" and _adr("ADR-003").owner == "Jorge Salvat"
    assert _adr("ADR-004").status == "Deferred"
    with _s() as s:
        meeting = s.get(Meeting, mid)
        assert meeting is not None and meeting.status == "Closed" and meeting.quorum_met
        ids = s.exec(select(TraceLink.dst_id).where(TraceLink.src_type == "meeting", TraceLink.src_id == mid,
                                                    TraceLink.dst_type == "raid")).all()  # fmt: skip
        titles = [s.get(RAIDItem, i).title for i in ids]  # type: ignore[union-attr]
    assert any("Apply the conditions of ADR-003" in t for t in titles)
    assert any("re-submission" in t and "ADR-004" in t for t in titles)
    assert "Share the HSM sizing" in titles

    minutes = client.get(f"/export/T09?item={mid}")
    doc = Document(BytesIO(minutes.content))
    text = "\n".join(p.text for p in doc.paragraphs) + "\n".join(
        c.text for t in doc.tables for row in t.rows for c in row.cells
    )
    assert (
        "Design Authority · Minutes" in text
        and "ADR-003" in text
        and "Approved" in text
        and "Share the HSM sizing" in text
    )
    # Tras cerrar, las decisiones ya no se pueden editar
    assert (
        client.post(f"/edit/meeting_decision/{d_vdi.id}/outcome", data={"value": "Approved"}).status_code
        == 409
    )


# ------------------------------------------------------------------ Brief, 10 días, baseline


def test_brief_sections_and_word_warning(client: TestClient) -> None:
    html = client.get("/brief").text
    for title in ("Business outcomes and metrics", "Scope in", "Scope out", "Open decisions and dates"):
        assert title in html
    with _s() as s:
        from app.models import ArchitectureBrief

        brief = s.exec(select(ArchitectureBrief).where(ArchitectureBrief.program_id == _pid())).one()
    client.post(f"/edit/brief/{brief.id}/context", data={"value": "word " * 1000})
    assert "will likely exceed two pages" in client.get("/brief").text
    doc = Document(BytesIO(client.get("/export/T01").content))
    assert any("Warning: this brief has" in p.text for p in doc.paragraphs)


def test_onboarding_checklists_persist(client: TestClient) -> None:
    assert 'aria-checked="true"' in client.post("/onboarding/check/ten_days/0").text
    assert 'aria-checked="true"' in client.post("/onboarding/check/ten_days_q/7").text
    assert client.post("/onboarding/check/ten_days/99").status_code == 404
    assert client.get("/onboarding").text.count('aria-checked="true"') == 2


def test_create_baseline_increments_version(client: TestClient) -> None:
    client.post("/baseline/new")
    with _s() as s:
        versions = s.exec(
            select(Baseline.version).where(Baseline.program_id == _pid()).order_by(col(Baseline.version))
        ).all()
        latest = s.exec(select(Baseline).where(Baseline.program_id == _pid(), Baseline.version == 2)).one()
    assert list(versions) == [1, 2] and len(latest.sha256) == 64 and '"roadmap"' in latest.payload


# ------------------------------------------------------------------ HLD / LLD


def test_review_deviation_creates_adr_or_change(client: TestClient) -> None:
    r = client.post("/architecture/review/new", data={"doc_type": "LLD", "title": "Backup LLD", "doc_version": "0.9"},
                    follow_redirects=False)  # fmt: skip
    rid = int(r.headers["location"].rsplit("/", 1)[1])
    with _s() as s:
        items = s.exec(
            select(ReviewItem).where(ReviewItem.review_id == rid).order_by(col(ReviewItem.question_key))
        ).all()
    assert len(items) == 6  # guía §7.2
    client.post(f"/edit/review_item/{items[0].id}/answer", data={"value": "No"})
    r = client.post(
        f"/architecture/item/{items[0].id}/deviation", data={"target": "adr"}, follow_redirects=False
    )
    assert r.headers["location"].startswith("/adr/ADR-")
    r = client.post(
        f"/architecture/item/{items[5].id}/deviation", data={"target": "change"}, follow_redirects=False
    )
    assert "tab=changes#CH-" in r.headers["location"]
    with _s() as s:
        a, b = s.get(ReviewItem, items[0].id), s.get(ReviewItem, items[5].id)
        assert a is not None and a.adr_id and a.deviation and b is not None and b.raid_item_id


def test_diagram_upload_accepts_images_and_serves_them_safely(client: TestClient) -> None:
    svg = b'<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script><rect width="10" height="10"/></svg>'
    r = client.post("/architecture/diagram", data={"view": "Context", "title": "Context"},
                    files={"file": ("context.svg", svg, "image/svg+xml")}, follow_redirects=False)  # fmt: skip
    assert r.headers["location"] == "/architecture#diagrams"
    with _s() as s:
        d = s.exec(select(ArchitectureDiagram).where(ArchitectureDiagram.program_id == _pid())).one()
    served = client.get(f"/architecture/diagram/{d.id}")
    assert served.status_code == 200 and "sandbox" in served.headers["content-security-policy"]
    bad = client.post("/architecture/diagram", data={"view": "Context"}, files={"file": ("x.exe", b"MZ", "application/octet-stream")},
                      follow_redirects=False)  # fmt: skip
    assert "Upload a PNG" in _error(bad)


# ------------------------------------------------------------------ Altas


def test_data_entry_forms(client: TestClient) -> None:
    client.post(
        "/stakeholders/new", data={"name": "Ana Sol", "stance": "Detractor", "organization": "Customer"}
    )
    client.post("/goals/new", data={"title": "Reduce operational risk"})
    client.post("/requirements/new", data={"kind": "NFR", "statement": "Backup window", "priority": "Must",
                                           "nfr_category": "Performance", "measurable_criterion": "<= 6 h nightly"})  # fmt: skip
    client.post("/raci/role", data={"name": "Security Officer"})
    with _s() as s:
        assert s.exec(select(Stakeholder).where(Stakeholder.name == "Ana Sol")).one().stance == "Detractor"
        req = s.exec(
            select(Requirement).where(Requirement.program_id == _pid(), Requirement.code == "NFR-007")
        ).one()
        gate = s.exec(select(Gate).where(Gate.program_id == _pid(), Gate.code == "G5")).one()
        risk = s.exec(select(RAIDItem).where(RAIDItem.program_id == _pid(), RAIDItem.code == "RK-001")).one()
    client.post(f"/rtm/{req.id}/links/gate", data={"target": [f"gate:{gate.id}"]})
    client.post(
        "/evidence/new",
        data={"title": "Backup window report", "result": "Pass", "requirement_id": str(req.id)},
    )
    html = client.get("/rtm").text
    row = html[html.index('<tr id="NFR-007"') :]
    row = row[: row.index("</tr>")]
    assert "G5" in row and "Backup window report" in row
    client.post(f"/rtm/{req.id}/links/gate", data={})
    client.post(f"/raid/{risk.id}/update", data={"text": "Generator contract signed"})
    with _s() as s:
        assert s.exec(
            select(RAIDUpdate).where(
                RAIDUpdate.raid_item_id == risk.id, RAIDUpdate.text == "Generator contract signed"
            )
        ).one()
        assert not s.exec(
            select(TraceLink).where(TraceLink.src_id == req.id, TraceLink.dst_type == "gate")
        ).first()
    assert "Security Officer" in client.get("/stakeholders?tab=raci").text


# ------------------------------------------------------------------ Plantillas


@pytest.mark.parametrize("mode", ["filled", "blank"])
@pytest.mark.parametrize("tid", ["T01", "T02", "T08", "T09"])
def test_docx_templates_reopen(client: TestClient, tid: str, mode: str) -> None:
    r = client.get(f"/export/{tid}?mode={mode}")
    assert r.status_code == 200
    doc = Document(BytesIO(r.content))
    assert "Internal Use - Confidential" in doc.sections[0].header.paragraphs[0].text
    first = doc.tables[0].cell(0, 0).text
    assert first.split("\n")[0] in {"Architecture Brief", "Architecture Governance Charter", "Architecture Decision Record",
                                    "Design Authority · Agenda", "Design Authority · Minutes"}  # fmt: skip


@pytest.mark.parametrize("mode", ["filled", "blank"])
@pytest.mark.parametrize(("tid", "sheet"), [("T08-log", "Decision Log"), ("T11", "Roadmap"), ("T15", "Plan")])
def test_xlsx_templates_reopen(client: TestClient, tid: str, sheet: str, mode: str) -> None:
    wb = load_workbook(BytesIO(client.get(f"/export/{tid}?mode={mode}").content))
    assert wb.sheetnames[0] == "Cover" and sheet in wb.sheetnames


def test_t10_has_one_sheet_per_review_with_answer_list(client: TestClient) -> None:
    wb = load_workbook(BytesIO(client.get("/export/T10").content))
    ws = wb[next(n for n in wb.sheetnames if n.startswith("HLD"))]
    assert ws["C5"].value == "Yes" and ws["C9"].value == "No"
    assert any(dv.formula1 == "=L_Answer" for dv in ws.data_validations.dataValidation)


def test_t11_roadmap_has_gantt_rules(client: TestClient) -> None:
    ws = load_workbook(BytesIO(client.get("/export/T11").content))["Roadmap"]
    assert ws["A5"].value == "WP-001"
    assert len(ws.conditional_formatting) >= 2


def test_t08_per_adr_export(client: TestClient) -> None:
    r = client.get("/export/T08?item=ADR-001")
    assert 'filename="Sovereign-Private-Cloud_ADR-001_v' in r.headers["content-disposition"]
    assert client.get("/export/T08?item=ADR-999").status_code == 404


def test_review_seed_shows_deviation(client: TestClient) -> None:
    with _s() as s:
        review = s.exec(select(DesignReview).where(DesignReview.program_id == _pid())).one()
    html = client.get(f"/architecture/review/{review.id}").text
    assert "→ ADR" in html and "Changes Requested" in html
