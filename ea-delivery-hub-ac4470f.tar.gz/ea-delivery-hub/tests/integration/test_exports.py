"""Fase 3: las plantillas se reabren con openpyxl / python-pptx y tienen la estructura de CLAUDE.md §8."""

from __future__ import annotations

import re
from collections.abc import Iterator
from datetime import date
from io import BytesIO
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from openpyxl import load_workbook
from openpyxl.workbook.workbook import Workbook
from pptx import Presentation
from sqlmodel import Session, select

from app.db import get_engine, init_db
from app.models import Program
from app.services import seed
from app.services.exports.base import ExportContext, filename, make_context
from app.services.exports.export_all import export_all
from app.services.exports.registry import TEMPLATES

TODAY = date(2026, 10, 16)
RISK_HEADERS = [
    "ID", "Organization", "Date Added", "Reported By", "Risk Title", "Workstream", "Risk Mitigation Owner",
    "Probability", "Impact", "Risk Score", "Due Date", "Monitor Status", "Contingency Plan", "Risk Mitigation & Updates",
    "Cause", "Event", "Consequence", "Escalation Trigger", "Escalation Forum",
]  # fmt: skip


@pytest.fixture
def session() -> Iterator[Session]:
    init_db()
    with Session(get_engine()) as s:
        seed.run(s, today=TODAY)
        yield s


def _ctx(session: Session, mode: str = "filled", lang: str | None = None) -> ExportContext:
    program = session.exec(select(Program).where(Program.code == "SPC-AASD")).one()
    return make_context(session, program, mode, lang, today=TODAY)


def _wb(tid: str, ctx: ExportContext) -> Workbook:
    return load_workbook(BytesIO(TEMPLATES[tid].build(ctx)))


def _validation_for(ws, cell: str) -> str | None:  # type: ignore[no-untyped-def]
    for dv in ws.data_validations.dataValidation:
        if cell in dv.sqref:
            return dv.formula1
    return None


# ------------------------------------------------------------------ comunes


@pytest.mark.parametrize("tid", [t for t, tpl in TEMPLATES.items() if tpl.fmt == "xlsx"])
@pytest.mark.parametrize("mode", ["filled", "blank"])
def test_every_xlsx_reopens_with_cover_and_lists(session: Session, tid: str, mode: str) -> None:
    wb = _wb(tid, _ctx(session, mode))
    assert wb.sheetnames[0] == "Cover"
    assert wb["Lists"].sheet_state == "hidden"
    cover = wb["Cover"]
    labels = [cover.cell(row=r, column=2).value for r in range(5, 12)]
    assert labels == ["Program", "Customer", "Version", "Date", "Owner", "Status", "Classification"]
    assert cover["C11"].value == "Internal Use - Confidential"
    assert cover["C5"].value == ("Sovereign Private Cloud" if mode == "filled" else "<Program name>")
    for name, dn in wb.defined_names.items():
        assert dn.attr_text.startswith("Lists!$"), name


@pytest.mark.parametrize("tid", [t for t, tpl in TEMPLATES.items() if tpl.fmt == "pptx"])
@pytest.mark.parametrize("mode", ["filled", "blank"])
def test_every_pptx_reopens_as_single_16x9_slide(session: Session, tid: str, mode: str) -> None:
    prs = Presentation(BytesIO(TEMPLATES[tid].build(_ctx(session, mode))))
    assert len(prs.slides) == 1
    assert round(prs.slide_width / prs.slide_height, 2) == 1.78
    texts = " ".join(sh.text_frame.text for sh in prs.slides[0].shapes if sh.has_text_frame)
    assert "Internal Use - Confidential" in texts
    assert any(sh.has_table for sh in prs.slides[0].shapes)


def test_filename_follows_convention(session: Session) -> None:
    assert (
        filename(_ctx(session), "RAID-Log", "xlsx") == "Sovereign-Private-Cloud_RAID-Log_v1.0_20261016.xlsx"
    )
    assert filename(_ctx(session, "blank"), "RAID-Log", "xlsx") == "Template_RAID-Log_v1.0_20261016.xlsx"


# ------------------------------------------------------------------ T04 RAID


def test_t04_raid_structure_formulas_and_validations(session: Session) -> None:
    wb = _wb("T04", _ctx(session))
    assert wb.sheetnames == ["Cover", "Risks", "Actions", "Issues", "Decisions", "Escalation", "Changes", "Comms",
                             "Lessons Learned", "Lists"]  # fmt: skip
    ws = wb["Risks"]
    assert ws["A1"].value == "RISKS LOG"
    assert "Global Project Management Methodology" in ws["A2"].value
    assert [c.value for c in ws[4]][: len(RISK_HEADERS)] == RISK_HEADERS
    assert ws.freeze_panes == "B5"
    assert ws.auto_filter.ref.startswith("A4:S")
    codes = [ws.cell(row=r, column=1).value for r in range(5, 12)]
    assert codes == [f"RK-00{n}" for n in range(1, 8)]
    assert ws["J5"].value == '=IF(AND(ISNUMBER(H5),ISNUMBER(I5)),H5*I5,"")'
    assert ws["J200"].value.startswith("=IF(")  # la fórmula sigue en las filas libres
    assert _validation_for(ws, "H5") == "=L_Scale" and _validation_for(ws, "I5") == "=L_Scale"
    assert _validation_for(ws, "L5") == "=L_MonitorStatus"
    rules = {str(rng.sqref): [r.type for r in rs] for rng, rs in ws.conditional_formatting._cf_rules.items()}
    assert "iconSet" in rules["J5:J304"]
    assert any(
        "expression" in types for rng, types in rules.items() if rng.startswith("G5")
    )  # rojo sin owner
    assert ws.column_dimensions["O"].outlineLevel == 1  # causa/evento/consecuencia plegables


def test_t04_blank_has_grey_italic_examples_and_scale_list(session: Session) -> None:
    wb = _wb("T04", _ctx(session, "blank"))
    ws = wb["Risks"]
    assert ws["A5"].value == "RK-001" and ws["A5"].font.i is True
    lists = wb["Lists"]
    col = [c.value for c in lists["A"]]
    assert col[0] == "L_Scale" and col[1:4] == ["1", "2", "3"]


def test_t04_spanish_labels(session: Session) -> None:
    wb = _wb("T04", _ctx(session, lang="es"))
    assert wb.sheetnames[:3] == ["Portada", "Riesgos", "Acciones"]
    assert wb["Riesgos"]["H4"].value == "Probabilidad"


# ------------------------------------------------------------------ T03 / T05


def test_t03_sdm_two_level_header_and_merged_goals(session: Session) -> None:
    ws = _wb("T03", _ctx(session))["Solution Dependency"]
    assert ws["A3"].value == "Solution Dependency Log"
    assert ws["A4"].value == "Goals and Objectives" and ws["E4"].value == "Requirements Completion"
    assert [ws.cell(row=5, column=c).value for c in range(1, 8)] == [
        "Goal ID", "Goal", "Obj ID", "Objective", "Acceptance Criteria", "Completion Status", "Approver"]  # fmt: skip
    merged = {str(m) for m in ws.merged_cells.ranges}
    assert "A6:A11" in merged and "B6:B11" in merged  # Goal-001 con 6 objetivos
    assert _validation_for(ws, "F6") == "=L_Completion"


def test_t05_rtm_sheets_trace_formulas_and_coverage(session: Session) -> None:
    wb = _wb("T05", _ctx(session))
    assert wb.sheetnames == [
        "Cover",
        "Outcomes",
        "Requirements",
        "Trace",
        "Solution Dependency",
        "Coverage",
        "Lists",
    ]
    trace = wb["Trace"]
    assert trace["I5"].value.startswith('=IF($A5="","",IF(LEN(TRIM(D5))>0,"Yes","No"))')
    cov = wb["Coverage"]
    assert cov["B5"].value == "=COUNTA('Trace'!A5:A304)"
    assert cov["B9"].value.startswith("=IF($B$5=0,0,COUNTIF('Trace'!L5:L304")
    assert cov["B9"].number_format == "0%"
    orphan_rules = [
        r
        for rng, rs in trace.conditional_formatting._cf_rules.items()
        for r in rs
        if str(rng.sqref) == "A5:H304"
    ]
    assert len(orphan_rules) == 2  # rojo (Must) y ámbar


# ------------------------------------------------------------------ T06 / T12


def test_t06_raci_counts_accountables_with_formula(session: Session) -> None:
    ws = _wb("T06", _ctx(session))["RACI Matrix"]
    assert [c.value for c in ws[4]][:5] == [
        "Activity / deliverable",
        "EA",
        "PM / Delivery Lead",
        "Tech / Domain Lead",
        "Customer",
    ]
    assert ws["F5"].value == '=IF($A5="","",COUNTIF(B5:E5,"A")+COUNTIF(B5:E5,"A/R")+COUNTIF(B5:E5,"A/C"))'
    assert "RACI-01" in ws["H5"].value
    assert _validation_for(ws, "B5") == "=L_RACI"
    names = [ws.cell(row=r, column=1).value for r in range(5, 14)]
    assert "Data residency sign-off" in names


def test_t06_blank_is_preloaded_with_guide_raci(session: Session) -> None:
    ws = _wb("T06", _ctx(session, "blank"))["RACI Matrix"]
    assert ws["A5"].value == "Outcomes and end-to-end architecture" and ws["B5"].value == "A/R"


def test_t12_health_has_seven_controls_with_rag(session: Session) -> None:
    wb = _wb("T12", _ctx(session))
    ws = wb["Weekly Health Check"]
    controls = [ws.cell(row=r, column=1).value for r in range(5, 12)]
    assert controls == [
        "Outcomes & scope",
        "Decisions",
        "Architecture",
        "Dependencies",
        "RAID",
        "Requirements",
        "Operations",
    ]
    assert ws["B11"].value == "Red" and "OPS-01" in ws["F11"].value
    assert wb["Findings"].max_row >= 4 + 17


def test_t16_raid_slide_has_definition_block(session: Session) -> None:
    prs = Presentation(BytesIO(TEMPLATES["T16-raid"].build(_ctx(session))))
    texts = [sh.text_frame.text for sh in prs.slides[0].shapes if sh.has_text_frame]
    assert "Risks, Actions, Issues & Dependencies (RAID)" in texts
    assert any(t.startswith("Purpose:") for t in texts) and any(t.startswith("Process:") for t in texts)
    table = next(sh.table for sh in prs.slides[0].shapes if sh.has_table)
    assert table.cell(0, 0).text == "ID" and table.cell(1, 0).text in {"RK-001", "RK-004"}


# ------------------------------------------------------------------ descarga y export-all


@pytest.fixture
def client(session: Session) -> Iterator[TestClient]:
    from app.main import app

    with TestClient(app) as c:
        yield c


def test_export_endpoint_streams_file(client: TestClient) -> None:
    r = client.get("/export/T04")
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("application/vnd.openxmlformats-officedocument.spreadsheetml")
    assert re.search(r'filename="[A-Za-z-]+_RAID-Log_v[\d.]+_\d{8}\.xlsx"', r.headers["content-disposition"])
    assert (
        client.get("/export/T16-rtm?mode=blank")
        .headers["content-type"]
        .endswith("presentationml.presentation")
    )
    assert client.get("/export/T04?mode=nope").status_code == 404


def test_export_all_writes_blank_and_filled(session: Session, tmp_path: Path) -> None:
    files = export_all(session, tmp_path)
    programs = len(session.exec(select(Program)).all())
    assert len(files) == len(TEMPLATES) * (1 + programs)
    assert (tmp_path / "blank").is_dir() and (tmp_path / "SPC-AASD").is_dir()
