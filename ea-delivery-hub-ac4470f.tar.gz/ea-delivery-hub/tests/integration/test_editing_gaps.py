"""Huecos de edición detectados al escribir el manual: workstreams, outcomes, respuesta del riesgo,
resolución de RAID-04 desde la interfaz y edición completa de requisitos."""

from __future__ import annotations

from collections.abc import Iterator

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app.db import get_engine, init_db
from app.models import Outcome, Program, RAIDItem, Requirement, TraceLink, Workstream
from app.models.enums import RAIDType
from app.rules import evaluate, load_context
from app.services import seed


@pytest.fixture
def client() -> Iterator[TestClient]:
    from app.main import app

    init_db()
    with Session(get_engine()) as s:
        seed.run(s)
    with TestClient(app) as c:
        yield c


def _s() -> Session:
    return Session(get_engine())


def _pid() -> int:
    with _s() as s:
        return s.exec(select(Program.id).where(Program.code == "SPC-AASD")).one()  # type: ignore[return-value]


def _rules(rule_id: str) -> list[str]:
    with _s() as s:
        return [r.entity_code for r in evaluate(load_context(s, _pid())) if r.rule_id == rule_id]


def _risk(rule_id: str) -> RAIDItem:
    code = _rules(rule_id)[0]
    with _s() as s:
        return s.exec(select(RAIDItem).where(RAIDItem.program_id == _pid(), RAIDItem.code == code)).one()


# ------------------------------------------------------------------ workstreams


def test_workstreams_can_be_created_and_edited(client: TestClient) -> None:
    page = client.get("/admin").text
    assert 'id="workstreams"' in page and "Compute &amp; Storage" in page

    r = client.post("/workstreams/new", data={"name": "Service Management", "lead": "Ops lead"})
    assert r.status_code == 200 and "Service Management" in r.text
    dup = client.post("/workstreams/new", data={"name": "Service Management"}, follow_redirects=False)
    assert "already%20exists" in dup.headers["location"]

    with _s() as s:
        ws = s.exec(select(Workstream).where(Workstream.name == "Service Management")).one()
    r = client.post(f"/edit/workstream/{ws.id}/scope", data={"value": "ITSM processes"})
    assert r.status_code == 200 and "ITSM processes" in r.text
    assert "cannot be empty" in client.post(f"/edit/workstream/{ws.id}/name", data={"value": " "}).text
    # El workstream nuevo aparece en los desplegables del RAID
    assert "Service Management" in client.get("/raid/new?type=Risk").text


# ------------------------------------------------------------------ outcomes


def test_outcomes_can_be_created_edited_and_linked(client: TestClient) -> None:
    r = client.post(
        "/outcomes/new",
        data={
            "description": "Cut provisioning time",
            "metric": "Days",
            "target_value": "1",
            "target_date": "2027-06-30",
        },
    )
    assert r.status_code == 200 and "Cut provisioning time" in r.text
    with _s() as s:
        out = s.exec(select(Outcome).where(Outcome.description == "Cut provisioning time")).one()
    assert out.code.startswith("OUT-") and str(out.target_date) == "2027-06-30"

    r = client.post(f"/edit/outcome/{out.id}/baseline_value", data={"value": "15 days"})
    assert r.text.strip().startswith("15 days")  # solo el contenido: la <td> conserva sus atributos
    with _s() as s:
        req_id = s.exec(select(Requirement.id).where(Requirement.program_id == out.program_id)).first()
    editor = client.get(f"/rtm/{req_id}/links/upstream/edit").text
    assert f'value="outcome:{out.id}"' in editor  # enlazable desde la celda de la RTM
    bad = client.post("/outcomes/new", data={"description": ""}, follow_redirects=False)
    assert "error=" in bad.headers["location"]


# ------------------------------------------------------------------ RAID-01: respuesta del riesgo


def test_risk_response_is_editable_inline_and_clears_raid01(client: TestClient) -> None:
    risk = _risk("RAID-01")
    html = client.get("/raid").text
    assert f'hx-get="/edit/raid/{risk.id}/response"' in html

    client.post(f"/edit/raid/{risk.id}/owner", data={"value": "Infra lead"})
    r = client.post(f"/edit/raid/{risk.id}/response", data={"value": "Order spare UPS capacity"})
    assert r.status_code == 200 and "Order spare UPS capacity" in r.text
    assert risk.code not in _rules("RAID-01")


# ------------------------------------------------------------------ RAID-04: escalado desde la interfaz


def test_raise_escalation_resolves_raid04(client: TestClient) -> None:
    risk = _risk("RAID-04")
    assert f'action="/raid/{risk.id}/escalate"' in client.get("/raid").text
    assert f'action="/raid/{risk.id}/escalate"' in client.get("/dashboard").text

    r = client.post(f"/raid/{risk.id}/escalate", follow_redirects=False)
    assert r.status_code == 303 and "tab=escalation" in r.headers["location"]
    assert risk.code not in _rules("RAID-04")
    client.post(f"/raid/{risk.id}/escalate")  # idempotente: no duplica la escalation
    with _s() as s:
        escs = s.exec(
            select(RAIDItem).where(RAIDItem.type == RAIDType.ESCALATION, RAIDItem.source_risk_id == risk.id)
        ).all()
    assert len(escs) == 1
    assert escs[0].escalation_forum == risk.escalation_forum and escs[0].title.startswith(risk.code)


def test_trigger_met_is_editable_and_new_escalation_takes_a_source_risk(client: TestClient) -> None:
    risk = _risk("RAID-04")
    assert f'hx-get="/edit/raid/{risk.id}/trigger_met"' in client.get("/raid").text
    form = client.get("/raid/new?type=Escalation").text
    assert 'name="source_risk_id"' in form and risk.code in form
    client.post(
        "/raid/new",
        data={"type": "Escalation", "title": "Escalate power", "source_risk_id": str(risk.id)},
    )
    assert risk.code not in _rules("RAID-04")


def test_raid_export_keeps_reference_columns() -> None:
    from app.content.raid_layout import columns_for

    assert "trigger_met" in [c.field for c in columns_for(RAIDType.RISK)]
    assert "trigger_met" not in [c.field for c in columns_for(RAIDType.RISK, export=True)]


# ------------------------------------------------------------------ requisitos


def test_requirement_edit_page_updates_every_field(client: TestClient) -> None:
    with _s() as s:
        req = s.exec(
            select(Requirement).where(Requirement.program_id == _pid(), Requirement.kind == "NFR")
        ).first()
        assert req is not None
        ws = s.exec(select(Workstream).where(Workstream.program_id == _pid())).first()
        assert ws is not None
    assert f'href="/requirements/{req.code}/edit"' in client.get("/rtm").text
    page = client.get(f"/requirements/{req.code}/edit")
    assert page.status_code == 200 and req.statement in page.text

    data = {
        "kind": "NFR",
        "statement": "Platform availability for tenant workloads",
        "priority": "Should",
        "status": "Approved",
        "workstream_id": str(ws.id),
        "source": "SOW §4.2",
        "nfr_category": req.nfr_category or "Availability",
        "measurable_criterion": ">= 99.95% monthly",
        "target_value": "99,95",
        "achieved_value": "",
        "unit": "%",
    }
    r = client.post(f"/requirements/{req.code}/edit", data=data, follow_redirects=False)
    assert r.status_code == 303
    with _s() as s:
        saved = s.get(Requirement, req.id)
        assert saved is not None
    assert (saved.statement, saved.priority, saved.status, saved.source) == (
        "Platform availability for tenant workloads", "Should", "Approved", "SOW §4.2",
    )  # fmt: skip
    assert saved.workstream_id == ws.id and saved.target_value == 99.95 and saved.achieved_value is None


def test_requirement_edit_validates_and_kind_change_renumbers(client: TestClient) -> None:
    with _s() as s:
        req = s.exec(
            select(Requirement).where(Requirement.program_id == _pid(), Requirement.kind == "FR")
        ).first()
        assert req is not None
        links = len(
            s.exec(
                select(TraceLink).where(TraceLink.src_type == "requirement", TraceLink.src_id == req.id)
            ).all()
        )
    base = {"kind": "FR", "statement": req.statement, "priority": req.priority, "status": req.status}
    bad = client.post(f"/requirements/{req.code}/edit", data={**base, "statement": ""})
    assert bad.status_code == 422 and "cannot be empty" in bad.text
    bad = client.post(f"/requirements/{req.code}/edit", data={**base, "target_value": "abc"})
    assert bad.status_code == 422 and "Enter a number" in bad.text

    r = client.post(f"/requirements/{req.code}/edit", data={**base, "kind": "NFR"}, follow_redirects=False)
    assert r.status_code == 303
    with _s() as s:
        saved = s.get(Requirement, req.id)
        assert saved is not None
        after = len(
            s.exec(
                select(TraceLink).where(TraceLink.src_type == "requirement", TraceLink.src_id == req.id)
            ).all()
        )
    assert saved.kind == "NFR" and saved.code.startswith("NFR-") and after == links
    assert client.get("/requirements/REQ-999/edit").status_code == 404


def test_goal_and_objective_text_are_editable(client: TestClient) -> None:
    html = client.get("/goals").text
    assert 'hx-get="/edit/goal/' in html and "/objective" in html


# ------------------------------------------------------------------ contadores de checklists


def test_dod_toggle_is_saved_and_updates_the_counter(client: TestClient) -> None:
    from app.content.guide import EA_DOD

    assert f"0 / {len(EA_DOD)} Definition of Done" in client.get("/handover").text
    r = client.post("/handover/dod/0")
    assert 'aria-checked="true"' in r.text
    assert 'id="dod-count" hx-swap-oob="true"' in r.text and f"1 / {len(EA_DOD)}" in r.text
    assert f"1 / {len(EA_DOD)} Definition of Done" in client.get("/handover").text  # guardado
    r = client.post("/handover/dod/0")
    assert 'aria-checked="false"' in r.text and f"0 / {len(EA_DOD)}" in r.text


def test_onboarding_toggle_updates_stage_progress(client: TestClient) -> None:
    r = client.post("/onboarding/check/ten_days/0")
    assert 'id="stages-count" hx-swap-oob="true"' in r.text and 'id="stage-mark-before"' in r.text
