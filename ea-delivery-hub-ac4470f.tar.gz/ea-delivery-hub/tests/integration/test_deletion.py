"""Borrado de registros con dependencias (PDR-011): confirmación, bloqueos, relaciones que se quitan y
detalle que se borra con el registro."""

from __future__ import annotations

import re
from collections.abc import Iterator
from typing import Any

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app.db import get_engine, init_db
from app.models import (
    ADR,
    ADROption,
    AuditLog,
    Goal,
    Meeting,
    MeetingDecision,
    Objective,
    Program,
    RACIAssignment,
    RACIRole,
    RAIDItem,
    RAIDUpdate,
    Requirement,
    TraceLink,
    WorkPackage,
    Workstream,
)
from app.models.enums import RAIDType
from app.services import seed
from app.services.deletion import DELETABLE


@pytest.fixture
def client() -> Iterator[TestClient]:
    from app.main import app

    init_db()
    with Session(get_engine()) as s:
        seed.run(s)
    with TestClient(app) as c:
        yield c


def _s() -> Session:
    return Session(get_engine())


def _pid(code: str = "SPC-AASD") -> int:
    with _s() as s:
        return s.exec(select(Program.id).where(Program.code == code)).one()  # type: ignore[return-value]


def _first(model: type[Any], **where: Any) -> Any:
    with _s() as s:
        q = select(model).where(model.program_id == _pid())
        for k, v in where.items():
            q = q.where(getattr(model, k) == v)
        return s.exec(q).first()


# ------------------------------------------------------------------ todas las pantallas


def test_every_deletable_kind_has_a_confirmation_page(client: TestClient) -> None:
    for kind, spec in DELETABLE.items():
        obj = _first(spec.model) if kind != "program" else _s().get(Program, _pid())
        if obj is None:
            continue  # el seed no tiene ese tipo de registro (p. ej. diagramas subidos)
        r = client.get(f"/delete/{kind}/{obj.id}")
        assert r.status_code == 200, kind
        assert f"Delete {spec.noun}" in r.text, kind


@pytest.mark.parametrize(
    ("url", "kind"),
    [
        ("/raid", "raid"),
        ("/raid/dependencies", "dependency"),
        ("/stakeholders", "stakeholder"),
        ("/stakeholders?tab=raci", "raci_activity"),
        ("/stakeholders?tab=raci", "raci_role"),
        ("/goals", "goal"),
        ("/goals", "objective"),
        ("/goals", "outcome"),
        ("/rtm", "requirement"),
        ("/rtm", "test_evidence"),
        ("/architecture", "arch_element"),
        ("/architecture", "design_review"),
        ("/gates", "gate_criterion"),
        ("/gates", "workpackage"),
        ("/adr", "adr"),
        ("/orr", "orr"),
        ("/handover", "handover"),
        ("/admin", "program"),
        ("/admin", "workstream"),
    ],
)
def test_screens_offer_delete(client: TestClient, url: str, kind: str) -> None:
    assert f'href="/delete/{kind}/' in client.get(url).text


def test_adr_detail_offers_delete_and_option_delete(client: TestClient) -> None:
    html = client.get("/adr/ADR-001").text
    assert 'href="/delete/adr/' in html and 'href="/delete/adr_option/' in html


# ------------------------------------------------------------------ sin dependencias


def test_simple_delete_redirects_back_with_a_message_and_is_audited(client: TestClient) -> None:
    risk = _first(RAIDItem, type=RAIDType.ACTION)
    r = client.post(f"/delete/raid/{risk.id}", data={"next": "/raid?tab=actions"}, follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"].startswith("/raid?tab=actions&deleted=")
    assert "deleted." in client.get(r.headers["location"]).text
    with _s() as s:
        assert s.get(RAIDItem, risk.id) is None
        assert s.exec(
            select(AuditLog).where(
                AuditLog.entity == "RAIDItem", AuditLog.entity_id == risk.id, AuditLog.action == "delete"
            )
        ).all()


def test_next_must_be_an_internal_path(client: TestClient) -> None:
    dep = _first(RAIDItem, type=RAIDType.COMM)
    r = client.post(f"/delete/raid/{dep.id}", data={"next": "https://evil.example"}, follow_redirects=False)
    assert r.headers["location"].startswith("/raid")


def test_records_of_other_programs_are_not_reachable(client: TestClient) -> None:
    with _s() as s:
        other = s.exec(select(RAIDItem).where(RAIDItem.program_id == _pid("HBM-ICDA"))).first()
        assert other is not None
    assert client.get(f"/delete/raid/{other.id}").status_code == 404
    assert client.post(f"/delete/raid/{other.id}").status_code == 404


# ------------------------------------------------------------------ bloqueos


def test_goal_with_objectives_is_blocked(client: TestClient) -> None:
    goal = _first(Goal)
    page = client.get(f"/delete/goal/{goal.id}").text
    assert "It cannot be deleted yet" in page and "belongs to this goal" in page
    assert ">Delete</button>" not in page.replace("\n", "")
    assert client.post(f"/delete/goal/{goal.id}").status_code == 409
    with _s() as s:
        assert s.get(Goal, goal.id) is not None


def test_adr_on_a_design_authority_agenda_is_blocked(client: TestClient) -> None:
    with _s() as s:
        d = s.exec(select(MeetingDecision).where(MeetingDecision.program_id == _pid())).first()
        assert d is not None
    page = client.get(f"/delete/adr/{d.adr_id}").text
    assert "On the agenda of" in page
    assert client.post(f"/delete/adr/{d.adr_id}").status_code == 409


def test_closed_session_cannot_be_deleted(client: TestClient) -> None:
    meeting = _first(Meeting, status="Closed")
    if meeting is None:
        pytest.skip("seed without closed sessions")
    assert "The session is closed" in client.get(f"/delete/meeting/{meeting.id}").text
    assert client.post(f"/delete/meeting/{meeting.id}").status_code == 409


# ------------------------------------------------------------------ relaciones que se quitan


def test_requirement_delete_lists_and_removes_its_trace_links(client: TestClient) -> None:
    req = _first(Requirement, code="REQ-001")
    with _s() as s:
        links = s.exec(
            select(TraceLink).where(
                ((TraceLink.src_type == "requirement") & (TraceLink.src_id == req.id))  # type: ignore[arg-type]
                | ((TraceLink.dst_type == "requirement") & (TraceLink.dst_id == req.id))  # type: ignore[arg-type]
            )
        ).all()
    assert links
    page = client.get(f"/delete/requirement/{req.id}").text
    assert f"Relations that will be removed ({len(links)})" in page
    client.post(f"/delete/requirement/{req.id}")
    with _s() as s:
        assert s.get(Requirement, req.id) is None
        assert all(s.get(TraceLink, link.id) is None for link in links)


def test_workstream_delete_clears_references_but_keeps_records(client: TestClient) -> None:
    ws = _first(Workstream, name="Networking")
    with _s() as s:
        risks = s.exec(select(RAIDItem).where(RAIDItem.workstream_id == ws.id)).all()
        assert risks
    assert "loses its workstream" in client.get(f"/delete/workstream/{ws.id}").text
    client.post(f"/delete/workstream/{ws.id}")
    with _s() as s:
        assert s.get(Workstream, ws.id) is None
        for r in risks:
            kept = s.get(RAIDItem, r.id)
            assert kept is not None and kept.workstream_id is None


def test_risk_delete_removes_updates_and_clears_source_risk(client: TestClient) -> None:
    with _s() as s:
        issue = s.exec(
            select(RAIDItem).where(RAIDItem.program_id == _pid(), RAIDItem.source_risk_id.is_not(None))  # type: ignore[union-attr]
        ).first()
        assert issue is not None
        risk_id = issue.source_risk_id
        ups = s.exec(select(RAIDUpdate).where(RAIDUpdate.raid_item_id == risk_id)).all()
    page = client.get(f"/delete/raid/{risk_id}").text
    assert f"{issue.code} loses its source risk" in page
    client.post(f"/delete/raid/{risk_id}")
    with _s() as s:
        kept = s.get(RAIDItem, issue.id)
        assert kept is not None and kept.source_risk_id is None
        assert all(s.get(RAIDUpdate, u.id) is None for u in ups)


def test_adr_delete_takes_its_options(client: TestClient) -> None:
    with _s() as s:
        on_agenda = {d.adr_id for d in s.exec(select(MeetingDecision)).all()}
        adr = next(
            a for a in s.exec(select(ADR).where(ADR.program_id == _pid())).all() if a.id not in on_agenda
        )
        opts = s.exec(select(ADROption).where(ADROption.adr_id == adr.id)).all()
    r = client.post(f"/delete/adr/{adr.id}", follow_redirects=False)
    assert r.status_code == 303
    with _s() as s:
        assert s.get(ADR, adr.id) is None and all(s.get(ADROption, o.id) is None for o in opts)


def test_work_package_delete_updates_dependants(client: TestClient) -> None:
    wp = _first(WorkPackage, code="WP-001")
    client.post(f"/delete/workpackage/{wp.id}")
    with _s() as s:
        for other in s.exec(select(WorkPackage).where(WorkPackage.program_id == _pid())).all():
            assert "WP-001" not in other.depends_on


def test_raci_role_delete_removes_its_cells(client: TestClient) -> None:
    role = _first(RACIRole)
    client.post(f"/delete/raci_role/{role.id}")
    with _s() as s:
        assert not s.exec(select(RACIAssignment).where(RACIAssignment.role_id == role.id)).all()


def test_goal_can_be_deleted_once_its_objectives_are_gone(client: TestClient) -> None:
    goal = _first(Goal)
    with _s() as s:
        objs = s.exec(select(Objective).where(Objective.goal_id == goal.id)).all()
    for o in objs:
        assert client.post(f"/delete/objective/{o.id}", follow_redirects=False).status_code == 303
    assert client.post(f"/delete/goal/{goal.id}", follow_redirects=False).status_code == 303


# ------------------------------------------------------------------ programa


def test_program_delete_requires_typing_its_code(client: TestClient) -> None:
    pid = _pid("EDP-CMM")
    page = client.get(f"/delete/program/{pid}").text
    assert "All its records" in page and "Type <code>EDP-CMM</code>" in page
    assert client.post(f"/delete/program/{pid}", data={"confirm_code": "nope"}).status_code == 422
    r = client.post(f"/delete/program/{pid}", data={"confirm_code": "EDP-CMM"}, follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"].startswith("/admin")
    with _s() as s:
        assert s.get(Program, pid) is None
        assert not s.exec(select(RAIDItem).where(RAIDItem.program_id == pid)).all()
        assert s.get(Program, _pid()) is not None  # los demás programas siguen


# ------------------------------------------------------------------ quitar relaciones sueltas


def test_links_can_be_removed_one_by_one(client: TestClient) -> None:
    link = _first(TraceLink, src_type="arch_element", dst_type="adr")
    with _s() as s:
        adr = s.get(ADR, link.dst_id)
        assert adr is not None
    html = client.get(f"/adr/{adr.code}").text
    assert f'action="/links/{link.id}/delete"' in html
    r = client.post(f"/links/{link.id}/delete", data={"next": f"/adr/{adr.code}"}, follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"] == f"/adr/{adr.code}"
    with _s() as s:
        assert s.get(TraceLink, link.id) is None


def test_source_risk_of_an_issue_can_be_changed_or_cleared(client: TestClient) -> None:
    with _s() as s:
        issue = s.exec(
            select(RAIDItem).where(RAIDItem.program_id == _pid(), RAIDItem.source_risk_id.is_not(None))  # type: ignore[union-attr]
        ).first()
        assert issue is not None
    editor = client.get(f"/edit/raid/{issue.id}/source_risk_id").text
    assert re.search(r'<option value="\d+"', editor)
    client.post(f"/edit/raid/{issue.id}/source_risk_id", data={"value": ""})
    with _s() as s:
        kept = s.get(RAIDItem, issue.id)
        assert kept is not None and kept.source_risk_id is None
