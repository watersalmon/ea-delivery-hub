"""Fase 1: seed idempotente que dispara todas las reglas, AuditLog, bloqueo de gates y migraciones."""

from __future__ import annotations

from collections.abc import Iterator
from datetime import date
from pathlib import Path

import pytest
from sqlalchemy.pool import StaticPool
from sqlmodel import Session, SQLModel, create_engine, func, select

from app import audit
from app.models import ADR, AuditLog, Gate, Program, RAIDItem, Requirement, current_user
from app.rules import REGISTRY, can_pass_gate, evaluate, gate_blockers, load_context, weekly_health
from app.services import seed

TODAY = date(2026, 10, 16)


@pytest.fixture
def session() -> Iterator[Session]:
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    audit.install()
    SQLModel.metadata.create_all(engine)
    with Session(engine) as s:
        yield s


@pytest.fixture
def seeded(session: Session) -> Session:
    seed.run(session, today=TODAY)
    return session


def _program(session: Session, code: str) -> Program:
    return session.exec(select(Program).where(Program.code == code)).one()


def _results(session: Session, code: str) -> list:  # type: ignore[type-arg]
    p = _program(session, code)
    assert p.id is not None
    return evaluate(load_context(session, p.id, today=TODAY))


def test_seed_triggers_every_rule(seeded: Session) -> None:
    fired: set[str] = set()
    for p in seeded.exec(select(Program)).all():
        assert p.id is not None
        fired |= {r.rule_id for r in evaluate(load_context(seeded, p.id, today=TODAY))}
    assert fired == set(REGISTRY), f"Rules never fired: {set(REGISTRY) - fired}"


def test_main_program_shows_most_rules(seeded: Session) -> None:
    fired = {r.rule_id for r in _results(seeded, "SPC-AASD")}
    assert set(REGISTRY) - fired == {"RTM-02", "STK-01"}  # demostradas en los programas ligeros


def test_seed_is_idempotent(seeded: Session) -> None:
    def counts() -> tuple[int, int, int]:
        return (
            seeded.exec(select(func.count()).select_from(Program)).one(),
            seeded.exec(select(func.count()).select_from(RAIDItem)).one(),
            seeded.exec(select(func.count()).select_from(Requirement)).one(),
        )

    before = counts()
    seed.run(seeded, today=TODAY)
    assert counts() == before
    assert {p.code for p in seeded.exec(select(Program)).all()} == {"SPC-AASD", "HBM-ICDA", "EDP-CMM"}


def test_seed_keeps_non_demo_programs(seeded: Session) -> None:
    seeded.add(Program(code="REAL-1", name="Customer engagement", client="Someone"))
    seeded.commit()
    seed.run(seeded, today=TODAY)
    assert _program(seeded, "REAL-1").is_demo is False


def test_ids_are_prefixed_and_sequential(seeded: Session) -> None:
    p = _program(seeded, "SPC-AASD")
    codes = sorted(
        seeded.exec(select(RAIDItem.code).where(RAIDItem.program_id == p.id, RAIDItem.type == "Risk")).all()
    )
    assert codes[:3] == ["RK-001", "RK-002", "RK-003"]


def test_weekly_health_has_seven_controls_with_reasons(seeded: Session) -> None:
    health = weekly_health(_results(seeded, "SPC-AASD"))
    assert [h.label for h in health] == [
        "Outcomes & scope", "Decisions", "Architecture", "Dependencies", "RAID", "Requirements", "Operations",
    ]  # fmt: skip
    by_key = {h.key: h for h in health}
    assert by_key["operations"].rag == "red" and by_key["operations"].reasons[0].rule_id == "OPS-01"
    assert by_key["architecture"].rag == "amber"


def test_gate_blocked_by_red_rules_and_unblocked_by_waiver(seeded: Session) -> None:
    p = _program(seeded, "SPC-AASD")
    assert p.id is not None
    ctx = load_context(seeded, p.id, today=TODAY)
    results = evaluate(ctx)
    assert not can_pass_gate(ctx, results, "G4")
    assert {r.rule_id for r in gate_blockers(ctx, results, "G4")} >= {"RAID-01", "ADR-01"}

    waiver = ADR(
        program_id=p.id, code="ADR-099", title="Waiver to pass G4 with open red items", status="Approved"
    )
    seeded.add(waiver)
    seeded.flush()
    gate = seeded.exec(select(Gate).where(Gate.program_id == p.id, Gate.code == "G4")).one()
    gate.waiver_adr_id = waiver.id
    seeded.add(gate)
    seeded.flush()
    ctx = load_context(seeded, p.id, today=TODAY)
    assert can_pass_gate(ctx, evaluate(ctx), "G4")


def test_audit_log_records_field_changes(seeded: Session) -> None:
    risk = seeded.exec(select(RAIDItem).where(RAIDItem.code == "RK-004")).first()
    assert risk is not None and risk.owner == ""
    token = current_user.set("ines.calderon")
    try:
        risk.owner = "Jorge Salvat"
        seeded.add(risk)
        seeded.commit()
    finally:
        current_user.reset(token)
    entry = seeded.exec(
        select(AuditLog).where(AuditLog.entity == "RAIDItem", AuditLog.entity_id == risk.id)
    ).one()
    assert (entry.field_name, entry.old_value, entry.new_value, entry.user) == (
        "owner", "", "Jorge Salvat", "ines.calderon",
    )  # fmt: skip
    assert risk.updated_by == "ines.calderon"


def test_audit_log_records_creation(session: Session) -> None:
    p = Program(code="NEW", name="New", client="C")
    session.add(p)
    session.commit()
    assert session.exec(
        select(AuditLog).where(AuditLog.entity == "Program", AuditLog.action == "create")
    ).one()


def test_audit_log_is_append_only(session: Session) -> None:
    session.add(AuditLog(program_id=1, entity="X", action="create"))
    session.commit()
    entry = session.exec(select(AuditLog)).first()
    assert entry is not None
    entry.new_value = "tampered"
    session.add(entry)
    with pytest.raises(audit.AuditLogImmutableError):
        session.commit()


def test_alembic_migration_matches_models(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from alembic import command
    from alembic.autogenerate import compare_metadata
    from alembic.config import Config
    from alembic.migration import MigrationContext

    from app import db
    from app.config import BASE_DIR, get_settings

    url = f"sqlite:///{(tmp_path / 'm.db').as_posix()}"
    monkeypatch.setenv("DATABASE_URL", url)
    get_settings.cache_clear()
    db.reset_engine()
    try:
        command.upgrade(Config(str(BASE_DIR / "alembic.ini")), "head")
        engine = create_engine(url)
        with engine.connect() as conn:
            diff = compare_metadata(MigrationContext.configure(conn), SQLModel.metadata)
        assert diff == []
    finally:
        get_settings.cache_clear()
        db.reset_engine()


def test_base01_flags_only_the_uncontrolled_change(seeded: Session) -> None:
    seeded.expire_all()  # recarga desde BD, como en una petición real
    hits = [r.entity_code for r in _results(seeded, "SPC-AASD") if r.rule_id == "BASE-01"]
    assert hits == ["REQ-003"]  # REQ-002 también cambió, pero con un Change enlazado
