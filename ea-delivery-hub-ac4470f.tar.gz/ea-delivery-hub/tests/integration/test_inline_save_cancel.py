"""Editor inline con Save/Cancel explícitos: nada se guarda al cambiar, Cancel no recarga la página."""

from __future__ import annotations

from collections.abc import Iterator

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app.db import get_engine, init_db
from app.models import Program, RAIDItem, Workstream
from app.services import seed


@pytest.fixture
def client() -> Iterator[TestClient]:
    from app.main import app

    init_db()
    with Session(get_engine()) as s:
        seed.run(s)
    with TestClient(app) as c:
        yield c


def _risk() -> RAIDItem:
    with Session(get_engine()) as s:
        pid = s.exec(select(Program.id).where(Program.code == "SPC-AASD")).one()
        return s.exec(select(RAIDItem).where(RAIDItem.program_id == pid, RAIDItem.type == "Risk")).first()  # type: ignore[return-value]


def test_editor_has_save_and_cancel_and_no_change_trigger(client: TestClient) -> None:
    risk = _risk()
    for field in ("due_date", "owner", "probability", "response"):
        html = client.get(f"/edit/raid/{risk.id}/{field}").text
        assert 'hx-trigger="change"' not in html, field
        assert ">Save<" in html and ">Cancel<" in html, field
        assert f"/edit/raid/{risk.id}/{field}/cancel" in html, field
        assert "location.reload" not in html, field


def test_save_sets_soft_refresh_header(client: TestClient) -> None:
    risk = _risk()
    r = client.post(f"/edit/raid/{risk.id}/owner", data={"value": "Ana Test"})
    assert r.status_code == 200 and "Ana Test" in r.text
    assert "ea:saved" in r.headers.get("HX-Trigger", "")
    with Session(get_engine()) as s:
        assert s.get(RAIDItem, risk.id).owner == "Ana Test"  # type: ignore[union-attr]


def test_cancel_row_scope_rerenders_row_without_saving(client: TestClient) -> None:
    risk = _risk()
    r = client.get(f"/edit/raid/{risk.id}/owner/cancel")
    assert r.status_code == 200
    assert f'id="{risk.code}"' in r.text and "<form" not in r.text.split("</tr>")[0].split("<td", 1)[0]
    assert "HX-Trigger" not in r.headers
    with Session(get_engine()) as s:
        assert s.get(RAIDItem, risk.id).owner == risk.owner  # type: ignore[union-attr]


def test_cancel_cell_scope_returns_original_content(client: TestClient) -> None:
    with Session(get_engine()) as s:
        ws = s.exec(select(Workstream)).first()
        assert ws is not None
        ws_id, scope = ws.id, ws.scope
    r = client.get(f"/edit/workstream/{ws_id}/scope/cancel")
    assert r.status_code == 200 and "<form" not in r.text
    assert (scope or "").strip() in r.text.replace("&amp;", "&")


def test_cancel_unknown_field_404(client: TestClient) -> None:
    assert client.get("/edit/raid/1/nope/cancel").status_code == 404


def test_validation_error_reshows_editor_and_saves_nothing(client: TestClient) -> None:
    with Session(get_engine()) as s:
        ws = s.exec(select(Workstream)).first()
        assert ws is not None
        ws_id, name = ws.id, ws.name
    r = client.post(f"/edit/workstream/{ws_id}/name", data={"value": " "})
    assert "cannot be empty" in r.text and "<form" in r.text and ">Save<" in r.text
    assert "HX-Trigger" not in r.headers
    with Session(get_engine()) as s:
        assert s.get(Workstream, ws_id).name == name  # type: ignore[union-attr]
