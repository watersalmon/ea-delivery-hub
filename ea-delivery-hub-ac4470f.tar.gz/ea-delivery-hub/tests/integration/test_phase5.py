"""Fase 5: round-trip JSON, ORR, handover y baselines, lessons, biblioteca, playbook, administración y 17 plantillas."""

from __future__ import annotations

import json
import re
from collections.abc import Iterator
from io import BytesIO
from pathlib import Path

import pytest
from docx import Document
from fastapi.testclient import TestClient
from openpyxl import load_workbook
from sqlmodel import Session, select

from app.db import get_engine, init_db
from app.models import Gate, ORRCheck, Program, ProgramSettings, RAIDItem
from app.rules import evaluate, load_context
from app.services import seed
from app.services.exports.export_all import export_all
from app.services.exports.registry import TEMPLATES
from app.services.markdown import render as md
from app.services.program_io import comparable, export_program, import_program


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    from app import config
    from app.main import app

    monkeypatch.setattr(config, "branding_override_path", lambda: tmp_path / "branding.override.yaml")
    import app.routers.admin as admin

    monkeypatch.setattr(admin, "branding_override_path", lambda: tmp_path / "branding.override.yaml")
    config.get_branding.cache_clear()
    init_db()
    with Session(get_engine()) as s:
        seed.run(s)
    with TestClient(app) as c:
        yield c
    config.get_branding.cache_clear()


def _s() -> Session:
    return Session(get_engine())


def _pid(code: str = "SPC-AASD") -> int:
    with _s() as s:
        return s.exec(select(Program.id).where(Program.code == code)).one()  # type: ignore[return-value]


# ------------------------------------------------------------------ JSON round-trip (criterio de aceptación)


def _findings(s: Session, pid: int) -> list[tuple[str, str]]:
    prog = s.get(Program, pid)
    assert prog is not None
    return sorted(
        (r.rule_id, "PROGRAM" if r.entity_code == prog.code else r.entity_code)
        for r in evaluate(load_context(s, pid))
    )


def test_json_round_trip_preserves_the_program(client: TestClient) -> None:
    r = client.get(f"/admin/export/{_pid()}")
    assert r.status_code == 200 and r.headers["content-disposition"].startswith(
        'attachment; filename="SPC-AASD_program_'
    )
    payload = r.json()
    imported = client.post(
        "/admin/import",
        files={"file": ("p.json", json.dumps(payload), "application/json")},
        follow_redirects=False,
    )
    assert imported.status_code == 303 and imported.headers["location"] == "/dashboard"
    with _s() as s:
        new = s.exec(select(Program).where(Program.code == "SPC-AASD-2")).one()
        assert new.id is not None and not new.is_demo
        again = export_program(s, new.id)
        assert comparable(again) == comparable(payload)
        assert _findings(s, new.id) == _findings(s, _pid())
    html = client.get("/dashboard", cookies={"ea_program": str(new.id)}).text
    assert "Sovereign Private Cloud" in html


def test_import_rejects_invalid_files(client: TestClient) -> None:
    r = client.post(
        "/admin/import",
        files={"file": ("x.json", b'{"format": "other"}', "application/json")},
        follow_redirects=False,
    )
    assert "not an EA Delivery Hub program export" in r.headers["location"].replace("%20", " ")
    r = client.post(
        "/admin/import", files={"file": ("x.json", b"not json", "application/json")}, follow_redirects=False
    )
    assert "error=" in r.headers["location"]


def test_import_remaps_foreign_keys_and_self_references() -> None:
    init_db()
    with _s() as s:
        seed.run(s)
        data = export_program(s, _pid())
        new = import_program(s, data, name="Copy")
        s.commit()
        esc = s.exec(
            select(RAIDItem).where(RAIDItem.program_id == new.id, RAIDItem.type == "Escalation")
        ).one()
        src = s.get(RAIDItem, esc.source_risk_id)
        assert src is not None and src.program_id == new.id and src.code == "RK-006"


# ------------------------------------------------------------------ ORR


def test_orr_red_blocks_g5_and_shows_on_screen(client: TestClient) -> None:
    html = client.get("/orr").text
    assert "G5 blocked" in html and "ORR-01" in html
    with _s() as s:
        red = s.exec(select(ORRCheck).where(ORRCheck.program_id == _pid(), ORRCheck.status == "red")).one()
    client.post(f"/edit/orr/{red.id}/status", data={"value": "amber"})
    with _s() as s:
        assert not [r for r in evaluate(load_context(s, _pid())) if r.rule_id == "ORR-01"]
    client.post("/orr/new", data={"dimension": "Patching", "criterion": "Monthly patch window agreed"})
    assert "Patching" in client.get("/orr").text


def test_operations_owner_edit_clears_ops01(client: TestClient) -> None:
    pid = _pid()
    client.post(f"/edit/program/{pid}/operations_owner", data={"value": "Nuria Pons"})
    client.post(f"/edit/program/{pid}/operations_engaged", data={"value": "true"})
    with _s() as s:
        assert not [r for r in evaluate(load_context(s, pid)) if r.rule_id == "OPS-01"]


# ------------------------------------------------------------------ Handover y baselines


def test_handover_diff_between_baseline_and_current(client: TestClient) -> None:
    html = client.get("/handover").text
    assert "~ REQ-002" in html and "~ REQ-003" in html  # cambiados tras la baseline v1
    client.post("/baseline/new")
    html = client.get("/handover?a=1&b=2").text
    assert "~ REQ-003" in html
    html = client.get("/handover?a=2&b=current").text
    assert "No differences." in html


def test_handover_items_and_dod(client: TestClient) -> None:
    client.post(
        "/handover/item",
        data={
            "kind": "Transfer",
            "title": "ADR-004 to customer architecture board",
            "receiving_owner": "Jorge Salvat",
        },
    )
    assert "ADR-004 to customer architecture board" in client.get("/handover").text
    r = client.post("/handover/dod/0")
    assert 'aria-checked="true"' in r.text and "/handover/dod/0" in r.text
    assert client.post("/handover/dod/99").status_code == 404


# ------------------------------------------------------------------ Lessons


def test_lessons_add_and_reuse_across_programs(client: TestClient) -> None:
    client.post(
        "/lessons/new", data={"title": "Book DR tests early", "recommendation": "Plan the DR window at G3"}
    )
    assert "Book DR tests early" in client.get("/lessons").text
    client.cookies.set("ea_program", str(_pid("EDP-CMM")))
    html = client.get("/lessons?q=facilities").text
    lid = re.search(r'action="/lessons/(\d+)/reuse"', html).group(1)  # type: ignore[union-attr]
    client.post(f"/lessons/{lid}/reuse")
    with _s() as s:
        copied = s.exec(
            select(RAIDItem).where(RAIDItem.program_id == _pid("EDP-CMM"), RAIDItem.type == "LessonLearned")
        ).one()
    assert copied.context.startswith("[Reused from Sovereign Private Cloud]")


# ------------------------------------------------------------------ Biblioteca y Playbook


def test_library_lists_17_templates_with_filters(client: TestClient) -> None:
    html = client.get("/templates").text
    assert len(set(re.findall(r'id="tpl-(T\d{2})"', html))) == 17
    assert "generator pending" not in html
    only_docx = client.get("/templates?fmt=DOCX").text
    assert set(re.findall(r'id="tpl-(T\d{2})"', only_docx)) == {"T01", "T02", "T08", "T09", "T14"}


def test_playbook_renders_markdown_safely(client: TestClient) -> None:
    html = client.get("/playbook/10-phases").text
    assert "Phase 4 · Govern delivery" in html and 'href="/orr"' in html
    out = str(md("**bold** <script>alert(1)</script> [x](javascript:alert(1)) | a |"))
    assert "<strong>bold</strong>" in out and "<script>" not in out and 'href="javascript' not in out
    assert client.get("/playbook/nope").status_code == 404


# ------------------------------------------------------------------ Administración


def test_admin_creates_program_with_defaults(client: TestClient) -> None:
    r = client.post("/admin/program/new", data={"code": "NEW-1", "name": "New engagement", "client": "Fictitious Co",
                                                "phase": "2", "risk_scale": "5"}, follow_redirects=False)  # fmt: skip
    assert r.headers["location"] == "/dashboard"
    with _s() as s:
        p = s.exec(select(Program).where(Program.code == "NEW-1")).one()
        gates = {g.code: g.status for g in s.exec(select(Gate).where(Gate.program_id == p.id)).all()}
        st = s.exec(select(ProgramSettings).where(ProgramSettings.program_id == p.id)).one()
    assert (
        gates["G1"] == "Passed" and gates["G2"] == "In Progress" and st.risk_scale == 5 and st.red_from == 15
    )
    dup = client.post(
        "/admin/program/new", data={"code": "NEW-1", "name": "x", "client": "y"}, follow_redirects=False
    )
    assert "already in use" in dup.headers["location"].replace("%20", " ")


def test_admin_scale_and_sla(client: TestClient) -> None:
    pid = _pid()
    client.post(f"/admin/settings/{pid}/scale", data={"risk_scale": "5"})
    with _s() as s:
        st = s.exec(select(ProgramSettings).where(ProgramSettings.program_id == pid)).one()
    assert (st.risk_scale, st.amber_from, st.red_from) == (5, 5, 15)
    r = client.post(f"/edit/settings/{st.id}/decision_sla_days", data={"value": "abc"})
    assert "whole number" in r.text
    client.post(f"/edit/settings/{st.id}/decision_sla_days", data={"value": "40"})
    with _s() as s:
        assert not [r for r in evaluate(load_context(s, pid)) if r.rule_id == "ADR-02"]


def test_admin_branding_override(client: TestClient) -> None:
    client.post("/admin/branding", data={"classification": "Customer Confidential", "methodology_banner": "Banner",
                                         "export_language": "es"})  # fmt: skip
    assert "Customer Confidential" in client.get("/").text
    wb = load_workbook(BytesIO(client.get("/export/T04?mode=blank").content))
    assert wb.sheetnames[0] == "Portada"


# ------------------------------------------------------------------ Plantillas de la fase y export-all


@pytest.mark.parametrize("mode", ["filled", "blank"])
@pytest.mark.parametrize(
    ("tid", "sheet"), [("T07", "Comms Plan"), ("T13", "ORR"), ("T17", "Lessons Learned")]
)
def test_phase5_xlsx(client: TestClient, tid: str, sheet: str, mode: str) -> None:
    wb = load_workbook(BytesIO(client.get(f"/export/{tid}?mode={mode}").content))
    assert wb.sheetnames[0] == "Cover" and sheet in wb.sheetnames


def test_t07_and_t13_live_checks(client: TestClient) -> None:
    ws = load_workbook(BytesIO(client.get("/export/T07").content))["Comms Plan"]
    assert any(
        isinstance(c.value, str) and "Detractor" in c.value and c.value.startswith("=IF(")
        for row in ws.iter_rows()
        for c in row
    )
    ws = load_workbook(BytesIO(client.get("/export/T13").content))["ORR"]
    assert any(isinstance(c.value, str) and "BLOCKED" in c.value for row in ws.iter_rows() for c in row)


@pytest.mark.parametrize("mode", ["filled", "blank"])
def test_t14_docx(client: TestClient, mode: str) -> None:
    doc = Document(BytesIO(client.get(f"/export/T14?mode={mode}").content))
    text = "\n".join(p.text for p in doc.paragraphs)
    assert "EA Definition of Done" in text and "Baseline reconciliation" in text


def test_export_all_generates_the_17_templates(tmp_path: Path) -> None:
    init_db()
    with _s() as s:
        seed.run(s)
        files = export_all(s, tmp_path)
        programs = len(s.exec(select(Program)).all())
    blank = {re.match(r"T\d+", t).group(0) for t in TEMPLATES}  # type: ignore[union-attr]
    assert len(blank) == 17
    assert len(list((tmp_path / "blank").iterdir())) == len(TEMPLATES)
    assert len(files) == len(TEMPLATES) * (1 + programs)
