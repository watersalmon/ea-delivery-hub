"""RTM: editor de enlaces por celda (set-links). Guarda exactamente el conjunto marcado de un tipo."""

from __future__ import annotations

from collections.abc import Iterator

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app.db import get_engine, init_db
from app.models import (
    ADR,
    ArchitectureElement,
    AuditLog,
    Gate,
    Objective,
    Outcome,
    Program,
    Requirement,
    TraceLink,
)
from app.services import seed


@pytest.fixture
def client() -> Iterator[TestClient]:
    from app.main import app

    init_db()
    with Session(get_engine()) as s:
        seed.run(s)
    with TestClient(app) as c:
        yield c


def _pid(s: Session) -> int:
    return s.exec(select(Program.id).where(Program.code == "SPC-AASD")).one()


def _links(s: Session, req: Requirement, kind: str) -> set[int]:
    out: set[int] = set()
    for lk in s.exec(select(TraceLink).where(TraceLink.program_id == req.program_id)).all():
        if lk.src_type == "requirement" and lk.src_id == req.id and lk.dst_type == kind:
            out.add(lk.dst_id)
        if lk.dst_type == "requirement" and lk.dst_id == req.id and lk.src_type == kind:
            out.add(lk.src_id)
    return out


def _n_audit(s: Session) -> int:
    return len(s.exec(select(AuditLog).where(AuditLog.entity == "TraceLink")).all())


def _req_and_aes() -> tuple[Requirement, list[ArchitectureElement]]:
    with Session(get_engine()) as s:
        pid = _pid(s)
        aes = list(s.exec(select(ArchitectureElement).where(ArchitectureElement.program_id == pid)).all())
        for req in s.exec(select(Requirement).where(Requirement.program_id == pid)).all():
            if not _links(s, req, "arch_element"):
                return req, aes
    raise AssertionError("seed has no requirement without architecture elements")


def test_set_adds_removes_and_is_noop_when_unchanged(client: TestClient) -> None:
    req, aes = _req_and_aes()
    a, b = aes[0], aes[1]
    url = f"/rtm/{req.id}/links/arch_element"
    with Session(get_engine()) as s:
        before = _n_audit(s)
    r = client.post(url, data={"target": [f"arch_element:{a.id}", f"arch_element:{b.id}"]})
    assert r.status_code == 204 and "ea:saved" in r.headers["HX-Trigger"]
    with Session(get_engine()) as s:
        assert _links(s, req, "arch_element") == {a.id, b.id}
        assert _n_audit(s) == before + 2
    client.post(url, data={"target": [f"arch_element:{a.id}"]})  # quitar uno
    with Session(get_engine()) as s:
        assert _links(s, req, "arch_element") == {a.id}
        n = _n_audit(s)
        assert n == before + 3
    client.post(url, data={"target": [f"arch_element:{a.id}"]})  # mismo conjunto: no-op, sin auditoría
    with Session(get_engine()) as s:
        assert _links(s, req, "arch_element") == {a.id}
        assert _n_audit(s) == n
    client.post(url, data={})  # vaciar
    with Session(get_engine()) as s:
        assert _links(s, req, "arch_element") == set()


def test_set_only_touches_its_own_type(client: TestClient) -> None:
    req, aes = _req_and_aes()
    with Session(get_engine()) as s:
        gate = s.exec(select(Gate).where(Gate.program_id == req.program_id)).first()
        assert gate is not None
        s.add(
            TraceLink(
                program_id=req.program_id,
                src_type="requirement",
                src_id=req.id or 0,
                dst_type="gate",
                dst_id=gate.id or 0,
            )
        )
        s.commit()
        gate_id = gate.id
    client.post(f"/rtm/{req.id}/links/arch_element", data={"target": [f"arch_element:{aes[0].id}"]})
    with Session(get_engine()) as s:
        assert gate_id in _links(s, req, "gate")


def test_upstream_group_mixes_objectives_and_outcomes(client: TestClient) -> None:
    req, _ = _req_and_aes()
    with Session(get_engine()) as s:
        obj = s.exec(select(Objective).where(Objective.program_id == req.program_id)).first()
        out = s.exec(select(Outcome).where(Outcome.program_id == req.program_id)).first()
        assert obj and out
        obj_id, out_id = obj.id, out.id
    r = client.post(
        f"/rtm/{req.id}/links/upstream", data={"target": [f"objective:{obj_id}", f"outcome:{out_id}"]}
    )
    assert r.status_code == 204
    with Session(get_engine()) as s:
        assert obj_id in _links(s, req, "objective") and out_id in _links(s, req, "outcome")
    client.post(f"/rtm/{req.id}/links/upstream", data={"target": [f"outcome:{out_id}"]})
    with Session(get_engine()) as s:
        assert _links(s, req, "objective") == set() and out_id in _links(s, req, "outcome")


def test_wrong_type_and_unknown_return_errors(client: TestClient) -> None:
    req, aes = _req_and_aes()
    base = f"/rtm/{req.id}/links"
    with Session(get_engine()) as s:
        gates_before = _links(s, req, "gate")
    assert client.post(f"{base}/nonsense", data={}).status_code == 404
    assert client.post("/rtm/999999/links/gate", data={}).status_code == 404
    assert client.get(f"{base}/nonsense/edit").status_code == 404
    r = client.post(f"{base}/gate", data={"target": [f"arch_element:{aes[0].id}"]})  # tipo ajeno al grupo
    assert r.status_code == 422
    assert client.post(f"{base}/arch_element", data={"target": ["arch_element:999999"]}).status_code == 404
    assert client.post(f"{base}/arch_element", data={"target": ["lol"]}).status_code == 422
    with Session(get_engine()) as s:
        assert _links(s, req, "gate") == gates_before and _links(s, req, "arch_element") == set()


def test_adr_group_inherited_are_readonly(client: TestClient) -> None:
    with Session(get_engine()) as s:
        pid = _pid(s)
        ae = s.exec(select(ArchitectureElement).where(ArchitectureElement.program_id == pid)).first()
        adrs = list(s.exec(select(ADR).where(ADR.program_id == pid)).all())
        req = s.exec(select(Requirement).where(Requirement.program_id == pid)).first()
        assert ae and req and len(adrs) >= 2
        for lk in s.exec(select(TraceLink).where(TraceLink.program_id == pid)).all():
            pair = {lk.src_type, lk.dst_type}
            if pair == {"requirement", "adr"} and req.id in (lk.src_id, lk.dst_id):
                s.delete(lk)
        inherited, direct = adrs[0], adrs[1]
        s.add(
            TraceLink(
                program_id=pid,
                src_type="requirement",
                src_id=req.id or 0,
                dst_type="arch_element",
                dst_id=ae.id or 0,
            )
        )
        s.add(
            TraceLink(
                program_id=pid,
                src_type="arch_element",
                src_id=ae.id or 0,
                dst_type="adr",
                dst_id=inherited.id or 0,
            )
        )
        s.commit()
        req_id, inh_id, inh_code, dir_id = req.id, inherited.id, inherited.code, direct.id
        req_obj = req
    html = client.get(f"/rtm/{req_id}/links/adr/edit").text
    assert "Inherited" in html and inh_code in html
    assert f'value="adr:{inh_id}"' not in html  # solo lectura: no se puede marcar
    assert f'value="adr:{dir_id}"' in html
    client.post(f"/rtm/{req_id}/links/adr", data={"target": [f"adr:{dir_id}"]})
    with Session(get_engine()) as s:
        assert _links(s, req_obj, "adr") == {dir_id}  # la heredada ni se toca ni pasa a directa


def test_editor_has_search_save_cancel_and_prechecked(client: TestClient) -> None:
    req, aes = _req_and_aes()
    client.post(f"/rtm/{req.id}/links/arch_element", data={"target": [f"arch_element:{aes[0].id}"]})
    html = " ".join(client.get(f"/rtm/{req.id}/links/arch_element/edit").text.split())
    assert 'type="search"' in html and ">Save<" in html and ">Cancel<" in html
    assert f'value="arch_element:{aes[0].id}" checked' in html
    assert f'value="arch_element:{aes[1].id}" checked' not in html
    assert "<dialog" not in html  # el diálogo vive en la página; aquí solo llega su contenido


def test_old_edit_links_block_is_gone(client: TestClient) -> None:
    html = client.get("/rtm").text
    assert "Edit links" not in html and "/rtm/link" not in html
    assert "/links/upstream/edit" in html and "/links/gate/edit" in html
    assert '<dialog id="link-dialog"' in html and 'hx-target="#link-dialog-body"' in html
    assert 'hx-target="closest td"' not in html.split('id="REQ-')[1]  # ya no se edita dentro de la celda


def test_adr_architecture_element_links_via_modal(client: TestClient) -> None:
    with Session(get_engine()) as s:
        pid = _pid(s)
        adr = s.exec(select(ADR).where(ADR.program_id == pid)).first()
        aes = list(s.exec(select(ArchitectureElement).where(ArchitectureElement.program_id == pid)).all())
        assert adr
        adr_id, code = adr.id, adr.code

    def linked() -> set[int]:
        with Session(get_engine()) as s:
            return {
                lk.src_id
                for lk in s.exec(select(TraceLink).where(TraceLink.program_id == pid)).all()
                if lk.src_type == "arch_element" and lk.dst_type == "adr" and lk.dst_id == adr_id
            }

    assert "Edit links" in client.get(f"/adr/{code}").text
    html = client.get(f"/adr/{code}/links/arch_element/edit").text
    assert (
        'type="search"' in html and ">Save<" in html and f'hx-post="/adr/{code}/links/arch_element"' in html
    )
    r = client.post(
        f"/adr/{code}/links/arch_element",
        data={"target": [f"arch_element:{aes[0].id}", f"arch_element:{aes[1].id}"]},
    )
    assert r.status_code == 204 and "ea:saved" in r.headers["HX-Trigger"]
    assert linked() == {aes[0].id, aes[1].id}
    client.post(f"/adr/{code}/links/arch_element", data={"target": [f"arch_element:{aes[1].id}"]})
    assert linked() == {aes[1].id}
    assert client.post(f"/adr/{code}/links/arch_element", data={"target": ["gate:1"]}).status_code == 422
    assert (
        client.post(f"/adr/{code}/links/arch_element", data={"target": ["arch_element:999999"]}).status_code
        == 404
    )
    assert client.get("/adr/ADR-999/links/arch_element/edit").status_code == 404
    assert linked() == {aes[1].id}
