"""Fase 2: pantallas RAID, RACI, RTM, Solution Dependency Map, dashboard y portfolio sobre el seed demo."""

from __future__ import annotations

import re
from collections.abc import Iterator

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app.db import get_engine, init_db
from app.models import AuditLog, Program, RACIActivity, RACIAssignment, RACIRole, RAIDItem
from app.services import seed


@pytest.fixture
def client() -> Iterator[TestClient]:
    from app.main import app

    init_db()
    with Session(get_engine()) as s:
        seed.run(s)
    with TestClient(app) as c:
        yield c


def _item(code: str, program: str = "SPC-AASD") -> RAIDItem:
    with Session(get_engine()) as s:
        pid = s.exec(select(Program.id).where(Program.code == program)).one()
        return s.exec(select(RAIDItem).where(RAIDItem.program_id == pid, RAIDItem.code == code)).one()


# ------------------------------------------------------------------ RAID


RISK_COLUMNS = [
    "ID", "Organization", "Date Added", "Reported By", "Risk Title", "Workstream", "Risk Mitigation Owner",
    "Probability", "Impact", "Risk Score", "Due Date", "Monitor Status", "Contingency Plan", "Risk Mitigation &amp; Updates",
]  # fmt: skip


def test_raid_risks_sheet_has_reference_columns_and_tabs(client: TestClient) -> None:
    html = client.get("/raid").text
    assert "RISKS LOG" in html
    headers = re.findall(r'class="sort-btn[^"]*" data-sort="[^"]+">([^<]+)</button>', html)
    assert headers == RISK_COLUMNS
    for tab in (
        "Cover",
        "Risks",
        "Actions",
        "Issues",
        "Decisions",
        "Escalation",
        "Changes",
        "Comms",
        "Lessons Learned",
    ):
        assert f">\n          {tab}" in html or f">{tab}" in html
    for extra in ("Cause", "Event", "Consequence", "Escalation Trigger", "Escalation Forum"):
        assert f">{extra}</th>" in html
    assert "Purpose:" in html and "Process:" in html and "Additional Information:" in html
    assert "Dell Technologies&#39; Global Project Management Methodology" in html


@pytest.mark.parametrize(
    "tab", ["cover", "actions", "issues", "decisions", "escalation", "changes", "comms", "lessons"]
)
def test_raid_every_tab_renders(client: TestClient, tab: str) -> None:
    assert client.get(f"/raid?tab={tab}").status_code == 200


def test_raid_score_shows_dot_and_number(client: TestClient) -> None:
    html = client.get("/raid").text
    assert re.search(r'bg-rag-red" role="img" aria-label="score 9"></span>9', html)


def test_risk_matrix_cell_filters_risks(client: TestClient) -> None:
    html = client.get("/raid?tab=risks&p=3&i=3").text
    rows = re.findall(r'<tr id="(RK-\d+)"', html)
    assert rows == ["RK-001", "RK-004"]


def test_raid_rows_flag_rule_alerts(client: TestClient) -> None:
    html = client.get("/raid").text
    assert re.search(r'<tr id="RK-004" class="flag-red"', html)
    assert re.search(r'<tr id="RK-005" class="flag-amber"', html)


def test_inline_edit_updates_row_badges_and_audit(client: TestClient) -> None:
    risk = _item("RK-004")
    r = client.post(f"/edit/raid/{risk.id}/owner", data={"value": "Jorge Salvat"})
    assert r.status_code == 200
    assert "Jorge Salvat" in r.text and 'id="RK-004"' in r.text
    assert (
        'id="badge-critical_risks_no_owner" hx-swap-oob="true" class="nav-badge' in r.text
    )  # sigue sin respuesta
    r = client.post(
        f"/edit/raid/{risk.id}/response", data={"value": "Disable catalogue telemetry; local proxy"}
    )
    assert 'id="badge-critical_risks_no_owner" hx-swap-oob="true" class="hidden"' in r.text
    with Session(get_engine()) as s:
        fields = {
            a.field_name
            for a in s.exec(
                select(AuditLog).where(AuditLog.entity_id == risk.id, AuditLog.entity == "RAIDItem")
            )
        }
    assert {"owner", "response"} <= fields


def test_inline_edit_rejects_values_outside_closed_list(client: TestClient) -> None:
    risk = _item("RK-002")
    r = client.post(f"/edit/raid/{risk.id}/probability", data={"value": "9"})
    assert "Pick a value from the list." in r.text
    assert _item("RK-002").probability == 3


def test_inline_editor_offers_scale_values(client: TestClient) -> None:
    risk = _item("RK-002")
    html = client.get(f"/edit/raid/{risk.id}/probability").text
    assert re.findall(r'<option value="(\d)"', html) == ["1", "2", "3"]


def test_unknown_inline_field_is_404(client: TestClient) -> None:
    risk = _item("RK-002")
    assert client.get(f"/edit/raid/{risk.id}/program_id").status_code == 404


def test_register_risk_requires_cause_event_consequence(client: TestClient) -> None:
    r = client.post("/raid/new", data={"type": "Risk", "title": "Vendor insolvency"})
    assert r.status_code == 422
    assert "cause-event-consequence" in r.text


def test_register_risk_creates_next_code(client: TestClient) -> None:
    r = client.post("/raid/new", data={
        "type": "Risk", "title": "Vendor insolvency", "cause": "a small reseller", "event": "it stops trading",
        "consequence": "support contracts lapse", "probability": "1", "impact": "3", "owner": "PM",
    }, follow_redirects=False)  # fmt: skip
    assert r.status_code == 303 and r.headers["location"].endswith("#RK-008")
    assert _item("RK-008").score == 3


def test_dependencies_page_and_graph(client: TestClient) -> None:
    html = client.get("/raid/dependencies").text
    assert "Dependency graph" in html and 'class="stroke-rag-red"' in html
    r = client.post("/raid/dependencies/new", data={"title": "Firewall rules", "source": "Networking",
                                                     "target": "Customer security team", "external": "on"},
                    follow_redirects=False)  # fmt: skip
    assert r.status_code == 303 and r.headers["location"].endswith("#DEP-005")


# ------------------------------------------------------------------ RACI / stakeholders


def _raci_cell(activity: str, role: str) -> tuple[int, int]:
    with Session(get_engine()) as s:
        pid = s.exec(select(Program.id).where(Program.code == "SPC-AASD")).one()
        act = s.exec(
            select(RACIActivity).where(RACIActivity.program_id == pid, RACIActivity.name == activity)
        ).one()
        rol = s.exec(select(RACIRole).where(RACIRole.program_id == pid, RACIRole.name == role)).one()
        assert act.id is not None and rol.id is not None
        return act.id, rol.id


def test_raci_matrix_shows_live_validation(client: TestClient) -> None:
    html = client.get("/stakeholders?tab=raci").text
    assert "RACI-01" in html and "RACI-02" in html
    assert html.count(">OK</span>") == 7  # las 7 filas de la guía (PDR-001) pasan


def test_raci_edit_fixes_double_accountable(client: TestClient) -> None:
    act, role = _raci_cell("Data residency sign-off", "Customer")
    r = client.post(f"/raci/{act}/{role}", data={"value": "C"})
    assert r.status_code == 200 and "RACI-01" not in r.text and ">OK</span>" in r.text
    with Session(get_engine()) as s:
        cell = s.exec(
            select(RACIAssignment).where(RACIAssignment.activity_id == act, RACIAssignment.role_id == role)
        ).one()
    assert cell.value == "C"


def test_raci_rejects_invalid_value(client: TestClient) -> None:
    act, role = _raci_cell("Data residency sign-off", "Customer")
    assert client.post(f"/raci/{act}/{role}", data={"value": "X"}).status_code == 422


@pytest.mark.parametrize("tab", ["directory", "map", "comms"])
def test_stakeholder_tabs_render(client: TestClient, tab: str) -> None:
    assert client.get(f"/stakeholders?tab={tab}").status_code == 200


# ------------------------------------------------------------------ Goals / RTM


def test_solution_dependency_map_two_level_header_and_merged_goals(client: TestClient) -> None:
    html = client.get("/goals").text
    assert "Solution Dependency Log" in html
    assert 'colspan="4" class="th-sub">Goals and Objectives' in html
    assert 'colspan="3" class="th-dark">Requirements Completion' in html
    assert 'rowspan="6" id="Goal-001"' in html


def test_rtm_coverage_and_orphan_filter(client: TestClient) -> None:
    html = client.get("/rtm").text
    assert "% traced end to end" in html
    orphans = client.get("/rtm?orphans=true").text
    assert re.findall(r'<tr id="((?:REQ|NFR)-\d+)"', orphans) == ["REQ-006", "REQ-007"]


def test_rtm_gate_filter(client: TestClient) -> None:
    html = client.get("/rtm?gate=G6").text
    assert set(re.findall(r'<tr id="((?:REQ|NFR)-\d+)"', html)) == {"REQ-003", "REQ-006"}


# ------------------------------------------------------------------ Dashboard / portfolio / shell


def test_dashboard_shows_seven_controls_and_gate_block(client: TestClient) -> None:
    html = client.get("/dashboard").text
    for label in (
        "Outcomes &amp; scope",
        "Decisions",
        "Architecture",
        "Dependencies",
        "RAID",
        "Requirements",
        "Operations",
    ):
        assert f">{label}</th>" in html
    assert "Active gate G4 · blocked" in html
    assert "nfr-radar" in html


def test_dashboard_checklist_toggle_persists(client: TestClient) -> None:
    assert 'aria-checked="true"' in client.post("/dashboard/checklist/2").text
    assert client.get("/dashboard").text.count('aria-checked="true"') == 1


def test_sidebar_badges_are_computed(client: TestClient) -> None:
    html = client.get("/dashboard").text
    assert re.search(r'id="badge-active_gate" class="nav-badge bg-rag-red">G4<', html)
    assert re.search(r'id="badge-adr_pending" class="nav-badge bg-dell-blue">2<', html)


def test_portfolio_lists_all_programs(client: TestClient) -> None:
    html = client.get("/").text
    for name in ("Sovereign Private Cloud", "Hybrid Backup Modernisation", "Edge Data Platform Discovery"):
        assert name in html


def test_program_selector_switches_active_program(client: TestClient) -> None:
    with Session(get_engine()) as s:
        pid = s.exec(select(Program.id).where(Program.code == "EDP-CMM")).one()
    r = client.post("/program/select?next=/dashboard", data={"program_id": str(pid)}, follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"] == "/dashboard"
    client.cookies.set("ea_program", str(pid))
    assert "Edge Data Platform Discovery</h1>" in client.get("/dashboard").text


def test_global_search_finds_codes(client: TestClient) -> None:
    html = client.get("/search?q=RK-004").text
    assert "Data residency of backup metadata" in html and 'href="/raid?tab=risks#RK-004"' in html
