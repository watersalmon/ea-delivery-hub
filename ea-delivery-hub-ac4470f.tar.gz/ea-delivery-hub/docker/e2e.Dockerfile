# Imagen para los smoke tests de Playwright: dependencias instaladas una vez (no en cada ejecución).
FROM mcr.microsoft.com/playwright/python:v1.49.1-noble
ARG HTTP_PROXY
ARG HTTPS_PROXY
ARG NO_PROXY
RUN pip install --no-cache-dir playwright==1.49.1 pytest==8.3.4 pytest-playwright==0.6.2
WORKDIR /work
