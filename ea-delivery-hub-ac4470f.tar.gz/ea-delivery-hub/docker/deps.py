"""Imprime las dependencias de pyproject.toml (base + extras pedidos) para `pip install -r`."""

import sys
import tomllib

with open("pyproject.toml", "rb") as fh:
    project = tomllib.load(fh)["project"]

deps = list(project["dependencies"])
for extra in sys.argv[1:]:
    deps += project["optional-dependencies"][extra]
print("\n".join(deps))
