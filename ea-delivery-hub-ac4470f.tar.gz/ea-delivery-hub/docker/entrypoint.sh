#!/bin/sh
# Aplica migraciones (si existen) y arranca el proceso indicado.
set -e
if [ -f /app/alembic.ini ] && [ -d /app/app/migrations ]; then
  alembic -c /app/alembic.ini upgrade head
fi
exec "$@"
