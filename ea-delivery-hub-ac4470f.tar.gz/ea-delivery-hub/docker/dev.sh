#!/bin/sh
# Desarrollo: Tailwind en watch (polling, para bind mounts/sync desde Windows) + uvicorn --reload.
set -e
tailwindcss -c tailwind.config.js -i app/static/css/input.css -o app/static/css/app.css --watch=always --poll &
exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload --reload-dir app
