# Verificación de las plantillas con una suite ofimática real (LibreOffice headless):
# abre cada XLSX/DOCX/PPTX, recalcula fórmulas y lo convierte a PDF/PNG para revisión visual.
FROM debian:bookworm-slim
ARG HTTP_PROXY
ARG HTTPS_PROXY
ARG NO_PROXY
RUN apt-get update \
    && apt-get install -y --no-install-recommends libreoffice-calc libreoffice-impress libreoffice-writer \
       fonts-liberation fonts-dejavu-core poppler-utils python3 \
    && rm -rf /var/lib/apt/lists/*
WORKDIR /work
