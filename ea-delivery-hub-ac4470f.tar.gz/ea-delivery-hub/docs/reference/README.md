# Material de referencia (no versionado)

Coloca aquí, fuera de git:

- `Guia_Practica_Enterprise_Architect_Dell.docx` — fuente de verdad metodológica.
- `raid_log_screenshot.png` — estilo del RAID Log.
- `solution_dependency_map_screenshot.png` — estilo del Solution Dependency Map.

Se excluyen de git porque son documentos internos y las capturas contienen nombres reales de clientes y personas (CLAUDE.md §11).
