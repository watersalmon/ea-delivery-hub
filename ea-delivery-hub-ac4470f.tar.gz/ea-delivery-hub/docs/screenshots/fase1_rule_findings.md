# Phase 1: governance rules fired by the demo seed

Generated inside the container after `make seed`.

## Hybrid Backup Modernisation (HBM-ICDA): phase 5, overall RED

Weekly health: Outcomes & scope: GREEN | Decisions: GREEN | Architecture: GREEN | Dependencies: GREEN | RAID: GREEN | Requirements: RED | Operations: GREEN

| Severity | Rule | Item | Finding | Suggested action |
|---|---|---|---|---|
| RED | RTM-02 | REQ-002 | No test or evidence proves this requirement before acceptance (G5). | Attach test results, a demo record or a signed document. |

## Sovereign Private Cloud (SPC-AASD): phase 4, overall RED

Weekly health: Outcomes & scope: GREEN | Decisions: RED | Architecture: AMBER | Dependencies: RED | RAID: RED | Requirements: RED | Operations: RED

| Severity | Rule | Item | Finding | Suggested action |
|---|---|---|---|---|
| RED | ADR-01 | ADR-003 | Critical-path decision without owner and due date. | Assign an owner and a decision date at the next Design Authority. |
| RED | DEP-01 | DEP-001 | Dependency on Telco provider (fictitious) on the critical path has no verifiable commitment. | Get a dated, written commitment (PO, email, signed plan) and attach the evidence. |
| RED | OPS-01 | SPC-AASD | Operational readiness at risk: no operations owner, operations not yet involved. | Name the customer operations owner and bring them into design and readiness reviews. |
| RED | RACI-01 | Data residency sign-off | 'Data residency sign-off' has 2 Accountable roles (exactly one required). | Keep a single A for the activity; turn the others into C or R. |
| RED | RAID-01 | RK-004 | Critical risk (score 9) without owner and response. | Name a mitigation owner and an agreed response this week. |
| RED | RAID-04 | RK-001 | Escalation trigger met ('No confirmed grid date 30 days before rack delivery') with no escalation raised. | Raise an Escalation to SteerCo with options and a recommendation. |
| RED | RTM-01 | REQ-007 | Must requirement not traced to outcome/objective or architecture element. | Link it in the RTM, or descope it through Change Control. |
| AMBER | ADR-02 | ADR-004 | 'Under Review' for 30 days (SLA 10 days). | Put it on the next Design Authority agenda or escalate one level. |
| AMBER | ADR-03 | ADR-002 | Approved decision without impacted artifacts identified. | List the artifacts to update (HLD, LLD, RTM, runbooks…) and their owners. |
| AMBER | BASE-01 | REQ-003 | REQ-003 changed since baseline v1 without a Change or ADR. | Raise a Change (or ADR) and link it, or revert to the baselined version. |
| AMBER | DEP-01 | DEP-003 | Dependency on Customer facilities has no verifiable commitment. | Get a dated, written commitment (PO, email, signed plan) and attach the evidence. |
| AMBER | RACI-02 | Capacity planning reviews | 'Capacity planning reviews' has no Responsible role. | Assign who does the work (R or A/R). |
| AMBER | RAID-02 | RK-005 | Risk is missing: cause, consequence, escalation trigger. | Rewrite as 'Due to [cause], there is a risk of [event], which could lead to [impact]'. |
| AMBER | RAID-03 | AC-001 | Action overdue by 3 day(s) and still 'Open'. | Update the status, re-plan the date or close it. |
| AMBER | RAID-03 | RK-003 | Risk overdue by 6 day(s) and still 'Action Required'. | Update the status, re-plan the date or close it. |
| AMBER | RTM-01 | REQ-006 | Should requirement not traced to architecture element. | Link it in the RTM, or descope it through Change Control. |
| AMBER | RTM-03 | NFR-006 | Non-functional requirement without a measurable criterion. | State a metric and target (e.g. availability >= 99.95% monthly, RPO <= 15 min). |

## Edge Data Platform Discovery (EDP-CMM): phase 1, overall AMBER

Weekly health: Outcomes & scope: AMBER | Decisions: GREEN | Architecture: GREEN | Dependencies: GREEN | RAID: GREEN | Requirements: GREEN | Operations: GREEN

| Severity | Rule | Item | Finding | Suggested action |
|---|---|---|---|---|
| AMBER | STK-01 | EDP-CMM | Stakeholder & comms plan has no detractors identified. | Map who decides and who may resist, with a message and channel for each. |

