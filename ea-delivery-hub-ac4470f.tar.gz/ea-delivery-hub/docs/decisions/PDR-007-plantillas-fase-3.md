# PDR-007 — Decisiones del generador de plantillas (Fase 3)

- **Estado:** Aprobada (interpretación más simple, CLAUDE.md §12.3)
- **Fecha:** 2026-10-16

| # | Tema | Decisión |
|---|---|---|
| 1 | Plantillas de la fase | T03, T04, T05, T06, T12 (XLSX + diapositiva) y T16 (una diapositiva por artefacto: RAID, Solution Dependency Map, RTM y RACI). Son 10 entradas en el registro. `make export-all` genera todas en versión vacía y rellena por programa (40 ficheros con el seed). |
| 2 | Listas de validación | Viven en una hoja oculta `Lists` con nombres definidos (`L_Scale`, `L_MonitorStatus`…). Así no se supera el límite de 255 caracteres de las listas en línea y las listas del programa (workstreams) caben enteras. |
| 3 | Fórmulas y crecimiento | Las validaciones, la fórmula del score (P×I), los recuentos de la RACI y los indicadores de trazabilidad se precargan hasta 300 filas, de modo que la plantilla sigue funcionando al añadir filas. El área de impresión se limita a los datos reales. |
| 4 | Score con "punto de color + número" | En Excel es un conjunto de iconos de semáforo con los umbrales del programa (`amber_from` / `red_from`), que muestra el valor junto al icono. |
| 5 | Filas alternas | Son formato condicional (`MOD(ROW(),2)=0`) con la prioridad más baja, para que sobrevivan a ordenar y filtrar y no tapen los colores RAG. |
| 6 | Columnas plegables | Causa, Evento, Consecuencia, Trigger y Foro del RAID se agrupan con esquema (outline) de Excel. |
| 7 | Versión del fichero | Rellena: `{versión de la última baseline}.0` (o 0.1 si no hay baseline). Vacía: 1.0. Nombre: `{Programa}_{Artefacto}_v{versión}_{AAAAMMDD}.{ext}`, con el nombre del programa sin acentos ni espacios. |
| 8 | Idioma | Se traducen etiquetas, hojas y portada (EN por defecto, ES con `?lang=es`). Los valores de las listas cerradas (Monitor Status, MoSCoW…) se mantienen en inglés porque son datos de la app. |
| 9 | Comprobación "abre sin avisos" | Excel no está instalado en este equipo. La verificación se hace de dos formas: con tests que reabren cada fichero con openpyxl y python-pptx, y abriendo los 40 ficheros con **LibreOffice headless** (`make check-office`), que recalcula las fórmulas (coinciden con la app: 14 requisitos, 21 % de extremo a extremo y 2 huérfanos) y los rasteriza a PNG. Queda pendiente confirmarlo en Microsoft Excel real. |
| 10 | Logo | Solo se inserta si existe el fichero indicado en `branding.yaml` (`logo:`). Por defecto no hay ninguno. |
