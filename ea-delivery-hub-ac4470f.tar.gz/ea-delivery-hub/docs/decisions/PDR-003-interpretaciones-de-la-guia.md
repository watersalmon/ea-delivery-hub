# PDR-003 — Interpretaciones de la guía y de CLAUDE.md

- **Estado:** Aprobada (defaults del plan, sin objeción)
- **Fecha:** 2026-10-16

| # | Tema | Decisión |
|---|---|---|
| 1 | Estados ADR | Ciclo de CLAUDE.md `Proposed → Under Review → Approved / Rejected / Deferred → Superseded`. Es superconjunto de la guía §13.2 (+ "diferida" de §5.1). *Under Review* = incluida en la agenda de una Design Authority. |
| 2 | Business Dependency Diagram (§6) | Se cubre con la pantalla *Goals & Solution Dependency Map* (Goals → Objectives → Outcomes + dependencias). |
| 3 | RTM-02 "al llegar a G5" | Se evalúa cuando la fase activa del programa es ≥ 5 (*Validate / Transition*). |
| 4 | OPS-01 "antes de G5" | Se evalúa con fase activa ≥ 3 (*Plan transition*), para avisar con margen (§14: operational readiness desde discovery). |
| 5 | Umbrales RAG de score | 1-3×1-3 (defecto, como la captura): verde 1-2, ámbar 3-6, rojo ≥ 7. 1-5×1-5: verde 1-4, ámbar 5-14, rojo ≥ 15. Configurables en Settings. |
| 6 | Formato de IDs | Correlativo por programa y tipo, 3 dígitos: `RK-001`, `ADR-001`, `REQ-001`, `NFR-001`, `Goal-001`, `Obj-001`. |
| 7 | Gates | G*n* es el gate de salida de la fase *n* de la guía §4 (G0 Qualify … G6 Close/Evolve). |
| 8 | Usuarios | Sin login en v1 (app local en loopback). El usuario actual sale de `EA_USER` y se usa en `created_by/updated_by` y en el AuditLog. |
| 9 | Dependencias de soporte | Además del stack §3: `uvicorn`, `jinja2`, `python-multipart`, `PyYAML`, `httpx` (tests), `psycopg` (solo profile postgres), `types-PyYAML` (mypy). |
| 10 | Material de referencia | `docs/reference/` fuera de git: la guía es interna y las capturas llevan nombres reales (§11). |
| 11 | Playwright | Servicio `e2e` aparte (profile `test`) con la imagen oficial de Playwright; no engorda la imagen `app`. |
