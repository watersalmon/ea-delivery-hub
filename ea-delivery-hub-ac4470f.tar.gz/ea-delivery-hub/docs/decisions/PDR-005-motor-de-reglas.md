# PDR-005 — Decisiones del modelo de datos y del motor de reglas (Fase 1)

- **Estado:** Aprobada (interpretación más simple, CLAUDE.md §12.3)
- **Fecha:** 2026-10-16

| # | Tema | Decisión |
|---|---|---|
| 1 | Reglas puras | Cada regla recibe un `ProgramContext` en memoria (snapshot del programa) y nunca toca la BD ni llama a `date.today()`. Así los tests son deterministas. |
| 2 | Control de salud de RACI-01/02 | La guía §11.1 no tiene un control de RACI. Lo asigno a **Decisions**, porque la RACI define quién es accountable de decidir. STK-01 alimenta **Outcomes & scope**, y BASE-01 alimenta **Architecture** ("Delivery se desvía sin aprobación"). |
| 3 | RAID-04 (trigger cumplido) | La app no puede evaluar textos libres como "No grid date by 1 Nov". El EA marca `trigger_met` en el riesgo, y la regla se dispara si no existe un Escalation cuyo `source_risk_id` sea ese riesgo. |
| 4 | OPS-01 | Se modela con dos campos del programa: `operations_owner` y `operations_engaged`. Se evalúa desde la fase 3 (PDR-003). |
| 5 | BASE-01 | La baseline guarda un hash del contenido de negocio de cada requisito y elemento de arquitectura. Un elemento cambiado queda cubierto si tiene un TraceLink a un ADR o a un Change del RAID **creado después** de aprobarse la baseline. Los enteros y los decimales se normalizan (15 == 15.0) para no dar falsos positivos tras recargar de la BD. |
| 6 | Gates bloqueados | Cada regla declara los gates que bloquea cuando está en rojo. RAID-01, RAID-04 y ADR-01 bloquean todos; RTM-02 y OPS-01 bloquean G5; RTM-01 bloquea G1, G2 y G5; RACI-01 bloquea G1 y G2; DEP-01 en rojo bloquea G3 y G4. Un waiver es un ADR **aprobado** enlazado en `Gate.waiver_adr_id`. |
| 7 | AuditLog | Es append-only: modificar o borrar una entrada lanza un error. Su `program_id` no tiene clave foránea, para que el historial sobreviva cuando el seed recrea la demo. El seed no audita, porque recrear los datos de demo no es un cambio de negocio. |
| 8 | Fechas | Las marcas de tiempo son *aware* en UTC, porque SQLModel ≥ 0.0.4x rechaza datetimes sin zona. Las fechas de negocio son `date`. |
| 9 | Enumerados | Se guardan como texto (portable entre SQLite y Postgres, y sin tipos ENUM en las migraciones). Los vocabularios están en `app/models/enums.py`. |
| 10 | Seed y reglas | El programa principal (fase 4) dispara 14 de las 16 reglas. RTM-02 se demuestra en *Hybrid Backup Modernisation* (fase 5) y STK-01 en *Edge Data Platform Discovery* (fase 1). Las fechas del seed son relativas a hoy. |
