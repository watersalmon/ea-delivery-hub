# PDR-004 — La interfaz de la aplicación en inglés

- **Estado:** Aprobada (Rafael, 2026-10-16: "el idioma de la aplicación tiene que ser el inglés")
- **Fecha:** 2026-10-16
- **Sustituye a:** CLAUDE.md §8, que decía "UI en español"

## Decisión
- Todo lo que ve el usuario va en inglés: navegación, pantallas, mensajes de las reglas de governance, datos de demostración y textos de ayuda.
- Las exportaciones siguen siendo ES/EN seleccionables, con EN por defecto (CLAUDE.md §8).
- La documentación interna del proyecto (CLAUDE.md, `docs/decisions/`, README) y los comentarios de código siguen en español, porque son el contexto de trabajo con Rafael.
- El contenido del Playbook (Fase 5) se redactará en inglés, a partir de la guía en español.
