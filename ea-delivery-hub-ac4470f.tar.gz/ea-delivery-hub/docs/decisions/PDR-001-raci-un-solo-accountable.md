# PDR-001 — RACI de la guía §9 ajustada a un solo Accountable (TOGAF 10)

- **Estado:** Aprobada (Rafael, 2026-10-16: "adapta los valores de configuración de las RACI según indique TOGAF 10")
- **Fecha:** 2026-10-16

## Contexto
La tabla RACI de la guía (§9) tiene dos filas con dos `A`, lo que contradice su propio criterio de calidad (§6: "Un solo A por actividad") y la regla RACI-01 de CLAUDE.md:

| Tema | EA | PM | Tech Lead | Cliente |
|---|---|---|---|---|
| Outcomes y arquitectura end-to-end | **A/R** | C | C | **A/C** |
| Cambios contractuales | C | **A/R** | C | **A/C** |

TOGAF 10 no prescribe esta matriz concreta: usa RACI como técnica (gestión de stakeholders y Architecture Governance) cuya convención es **exactamente un Accountable por actividad**. La aprobación del cliente se canaliza a través de la aceptación formal (Architecture Contract / Architecture Board), no duplicando el `A` en cada fila.

## Decisión
Precarga de la RACI con un solo `A` por fila:

| Tema | EA | PM / Delivery Lead | Tech / Domain Lead | Cliente |
|---|---|---|---|---|
| Outcomes y arquitectura end-to-end | A/R | C | C | **C** |
| Plan, coste, recursos y reporting | C | A/R | C | C |
| Diseño detallado del dominio | A/C | I | R | C |
| Architecture governance | A/R | C | C | C |
| RAID de programa | R (técnico) | A/R | R (dominio) | C |
| Acceptance y prioridades | C | R (coordinación) | C | A |
| Cambios contractuales | C | A/R | C | **C** |

- La aceptación del cliente sobre outcomes y cambios queda cubierta por la fila *Acceptance y prioridades*, donde el Cliente es el único `A`.
- Los cualificadores de la guía ("técnico", "dominio", "coordinación") se guardan en un campo `qualifier` aparte; para las reglas cuentan como `R`.

## Consecuencias
- La RACI precargada pasa RACI-01 y RACI-02. El seed de demo introducirá aparte una fila con doble `A` para poder demostrar la regla.
- Se aparta de la literalidad de la guía en dos celdas. Si el engagement exige que el cliente firme los cambios contractuales como Accountable, la alternativa coherente es Cliente `A` y PM `R` en esa fila (se cambia desde la pantalla RACI, sin tocar código).
