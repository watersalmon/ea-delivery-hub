# PDR-009 — Decisiones de la Fase 5 (ORR, handover, baselines, lessons, biblioteca, playbook, admin)

- **Estado:** Aprobada (interpretación más simple, CLAUDE.md §12.3)
- **Fecha:** 2026-10-16

| # | Tema | Decisión |
|---|---|---|
| 1 | Bloqueo de G5 por el ORR | Lo hace una regla nueva, **ORR-01** (rojo, control *Operations*): cualquier comprobación de readiness en rojo bloquea G5, igual que el resto de reglas rojas (CLAUDE.md §7.13 "Bloquea G5 si hay rojos"). Con ella el motor tiene 17 reglas. |
| 2 | Dimensiones del ORR | Las 7 de la guía §10 más las que el programa necesite (DR/RTO-RPO, patching, observabilidad, seguridad…), con alta libre. |
| 3 | Baselines | El snapshot incluye requisitos, arquitectura, RAID y roadmap, igual en el seed, en el wizard y en la comparación. Los diffs se hacen **por código** (REQ-001, AE-002, RK-003, WP-004): altas, bajas y cambios campo a campo, entre dos baselines o entre una baseline y el estado actual. |
| 4 | Hash por elemento (BASE-01) | Ya no tiene en cuenta las claves foráneas (`*_id`), porque un import reasigna ids y eso no es un cambio de negocio. Contrapartida asumida: mover un requisito de workstream no cuenta como cambio frente a la baseline. |
| 5 | Import/export JSON | `{"format": "ea-delivery-hub/program", "version": 1, …}` con todas las tablas del programa (excepto el AuditLog y los ficheros de diagramas subidos). El import crea siempre un **programa nuevo**: reasigna ids, reescribe las claves foráneas (incluidas las autorreferencias, en una segunda pasada), las referencias polimórficas de TraceLink y las claves de hash de las baselines. Si el código ya existe, añade un sufijo `-2`. El round-trip está verificado: los datos son idénticos y se disparan las mismas reglas. |
| 6 | Lessons learned | Son elementos `LessonLearned` del RAID. "Reuse" copia una lección de otro programa como punto de partida, indicando su origen. |
| 7 | Playbook | Markdown en `app/content/playbook/*.md` (en inglés). Se renderiza con un renderizador propio mínimo y seguro (escapa todo el HTML y solo admite enlaces relativos o http(s)) para no añadir dependencias (§11). |
| 8 | Biblioteca | Catálogo de las 17 plantillas con fase, foro, sección de la guía y estructura, y filtros por fase, foro y formato. La "previsualización" es la estructura del documento; para la revisión visual completa está `make check-office`. |
| 9 | Administración | Alta de programas con valores por defecto (ajustes, gates G0-G6 y la RACI de PDR-001). Al cambiar de escala, los umbrales RAG se reajustan a los valores por defecto de la nueva escala; los umbrales y el SLA se pueden editar. De branding solo se pueden cambiar desde la pantalla el texto de clasificación, la banda de metodología y el idioma de exportación por defecto, que se guardan en `/data/branding.override.yaml`. Colores y logo siguen en `branding.yaml` y `branding/`. |
| 10 | Tests | Cada test arranca con una base de datos en memoria vacía (fixture `_fresh_database`), para que el orden de ejecución no influya. |
