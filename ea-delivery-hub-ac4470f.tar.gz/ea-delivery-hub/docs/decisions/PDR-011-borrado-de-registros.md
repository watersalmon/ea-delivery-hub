# PDR-011 — Borrado de registros y relaciones

- **Estado:** Aprobada (interpretación más simple, CLAUDE.md §12.3)
- **Fecha:** 2026-10-17

| # | Tema | Decisión |
|---|---|---|
| 1 | Flujo | Cada fila tiene un icono de papelera que abre una página de confirmación (`/delete/{tipo}/{id}`). Esa página indica qué se borra con el registro, qué relaciones se quitan y qué impide borrarlo. Al confirmar se vuelve a calcular todo antes de borrar. |
| 2 | Bloqueos | Un registro no se borra si otro registro con entidad propia depende obligatoriamente de él: un goal con objectives, una ADR en la agenda de una sesión de la Design Authority o que justifica el waiver de un gate, y una sesión cerrada (su acta es el registro de lo decidido). La página enlaza cada dependencia para resolverla primero. |
| 3 | Relaciones | Las referencias opcionales se quitan y los registros relacionados se conservan: enlaces de la RTM y de los foros, workstream de riesgos, requisitos, elementos y work packages, riesgo origen de issues y escalations, `supersedes` entre ADR, dependencias entre work packages, y enlaces de las revisiones HLD/LLD. Antes de borrar se listan todas. |
| 4 | Detalle propio | Se borra con el registro: updates de un riesgo, opciones e historial de una ADR, respuestas del checklist de una revisión, celdas de la RACI de un rol o una actividad, la agenda de una sesión sin cerrar y el fichero de un diagrama. |
| 5 | Programa | Se borra desde *Administration* con todos sus registros, escribiendo su código para confirmar. El AuditLog se conserva. |
| 6 | Sin borrado | Gates G0-G6 (son el ciclo de vida de la guía), baselines (snapshots aprobados que usa BASE-01), Architecture Brief, checklists predefinidos y ajustes. |
| 7 | Quitar relaciones sin borrar | RTM → pulsar la celda de enlaces y desmarcar (ahora también para las ADR enlazadas directamente), ficha de ADR → *unlink* del elemento de arquitectura, riesgo origen de issues y escalations editable (o vacío), workstream editable en todas las tablas. |
| 8 | Auditoría | Cada baja y cada referencia que se vacía queda en el AuditLog con el usuario y la fecha. |
| 9 | Edición añadida | Al revisar las pantallas aparecieron más textos que no se podían editar y ahora sí: el nombre del stakeholder, los elementos de arquitectura (nombre, vista, workstream, HLD y LLD) y el texto de los criterios de gate. |
