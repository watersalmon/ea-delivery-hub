# PDR-002 — Repo en D:\ con Docker Desktop (backend WSL2)

- **Estado:** Aprobada (Rafael, 2026-10-16: "vamos a continuar con la webapp en el directorio actual … se ejecutará en un docker dentro de una wsl, instala docker en windows")
- **Fecha:** 2026-10-16

## Contexto
CLAUDE.md §2.1 pide el repo en el ext4 de WSL (`~/projects/ea-delivery-hub`), nunca en `/mnt/c`. El repo vive en `D:\Dev\claude\dea` (`/mnt/d/...` desde WSL), dentro del sistema de ficheros de Windows. En el momento de la decisión el equipo no tenía WSL ni Docker y la virtualización aparecía desactivada en firmware.

## Decisión
- Se desarrolla en `D:\Dev\claude\dea`. Docker Desktop (backend WSL2) ejecuta la app.
- Para no depender de inotify a través de `/mnt/d` (9P), el hot-reload usa **`docker compose watch`**: Docker vigila en el host y **sincroniza** los ficheros dentro del contenedor, donde uvicorn `--reload` y Tailwind `--watch` sí reciben eventos. No hay bind mount del código.
- Tailwind en dev usa `--poll` por robustez.
- Todo el tooling (Makefile, scripts `.sh`, finales de línea LF por `.gitattributes`) sigue siendo válido dentro de WSL, de modo que mover el repo a `~/projects` más adelante no exige cambios.

## Consecuencias
- Rendimiento de build algo menor que en ext4; aceptable para el tamaño del proyecto.
- `make` se ejecuta desde una shell WSL (o Git Bash con `make` instalado) apuntando a la misma carpeta.
