# PDR-010 — Huecos de edición detectados al escribir el manual

- **Estado:** Aprobada (interpretación más simple, CLAUDE.md §12.3)
- **Fecha:** 2026-10-17

| # | Tema | Decisión |
|---|---|---|
| 1 | Workstreams | Se dan de alta y se editan (nombre, lead, alcance) en *Administration → Workstreams*, para el programa activo. No se borran: un workstream suele estar referenciado por riesgos, requisitos y work packages. |
| 2 | Outcomes | Alta y edición en línea en *Goals & Solution Dependency Map → Business outcomes*. Se enlazan a requisitos desde la RTM, como los objectives. |
| 3 | Respuesta del riesgo | Se edita en línea en la columna *Risk Mitigation & Updates*, encima del log de updates. Si falta y RAID-01 la exige, el aviso sale en rojo. |
| 4 | RAID-04 | Botón *Raise escalation* en la fila del riesgo y en la alerta: crea una Escalation enlazada al riesgo, con su owner, workstream y foro de escalación, y vencimiento a 7 días. Si ya existe, lleva a ella. Alternativas: marcar *Trigger Met* como No (columna plegable) o dar de alta la Escalation a mano eligiendo el riesgo origen. |
| 5 | Requisitos | Ficha de edición (`/requirements/{code}/edit`) con todos los campos. Cambiar FR↔NFR asigna un código nuevo REQ-/NFR-; los enlaces de la RTM se conservan porque van por id. |
| 6 | Edición en línea | Al guardar una celda solo se sustituye su contenido: la celda conserva clases y `rowspan`. Los textos obligatorios (títulos, enunciados, nombres) no se pueden dejar vacíos. |
| 7 | Tests | `tests/conftest.py` fuerza `DATABASE_URL=sqlite://`. Antes, dentro del contenedor los tests usaban `/data/ea.db` y vaciaban los datos de la app; era la causa de los fallos masivos de e2e tras `make test`. |
