# PDR-006 — Decisiones de las pantallas de la Fase 2

- **Estado:** Aprobada (interpretación más simple, CLAUDE.md §12.3)
- **Fecha:** 2026-10-16

| # | Tema | Decisión |
|---|---|---|
| 1 | Programa activo | Lo guarda una cookie (`ea_program`) que fija el selector de la top bar. Sin cookie, se usa el primer programa creado. Sin ningún programa, las pantallas muestran un estado vacío en vez de un error. |
| 2 | Edición en línea | Se edita con clic o Enter sobre la celda: htmx pide el editor y el servidor valida contra las listas cerradas (escala P/I del programa, Monitor Status, etc.). En el RAID se re-renderiza la **fila entera**, porque cambiar P o I cambia el score. En el resto de tablas se re-renderiza solo la celda. Escape cancela. |
| 3 | Badges y alertas tras editar | Cada guardado devuelve, además de la fila o celda, los badges de la sidebar y la campana recalculados (`hx-swap-oob`). No hace falta recargar la página para ver el efecto en las reglas. |
| 4 | Filtro y orden por columna | Se hacen en el navegador (embudo y clic en la cabecera) sobre las filas ya cargadas. Es suficiente para el volumen de un programa y no añade dependencias. |
| 5 | Pestañas del RAID | Son las 9 de la captura. Las columnas de *Risks* son exactamente las de la captura; Causa, Evento, Consecuencia, Trigger y Foro se despliegan con un interruptor. Las demás pestañas tienen columnas propias de su tipo. |
| 6 | Dependencias | Van en una vista aparte (`/raid/dependencies`), porque la captura no tiene pestaña para ellas. El grafo es un SVG generado en el servidor: workstreams con caja sólida, terceros y cliente con caja discontinua, y aristas coloreadas por DEP-01. |
| 7 | Cobertura de la RTM | Un requisito está trazado "de extremo a extremo" si tiene outcome u objective, elemento de arquitectura **y** evidencia. Los ADR se heredan de los elementos de arquitectura enlazados. La columna Gate muestra el gate en el que se acepta el requisito (enlace `requirement → gate`). |
| 8 | Radar de NFR | Muestra el % de cumplimiento frente al objetivo (100 = cumplido), con tope en 120. En RTO/RPO y rendimiento (latencia), menos es mejor y el % se invierte. |
| 9 | Checklist §11.2 | Se guarda por programa en la tabla `ChecklistItem` (migración 0002). |
| 10 | Mapa poder/interés | Es una cuadrícula 5×5 (influencia × interés) con los cuadrantes clásicos. El color indica la postura y el tamaño, si la persona es decisora. |
| 11 | Textos Purpose/Process/Additional Information | Son redacción propia en inglés (`app/content/artifacts.py`), inspirada en las capturas pero sin copiarlas. El mismo texto se usará en las diapositivas PPTX de la Fase 3. |
