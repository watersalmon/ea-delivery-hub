# EA Delivery Hub — Especificación para Claude Code

> Este fichero es el contexto permanente del proyecto. Léelo entero antes de cada fase.
> Material de referencia obligatorio en `docs/reference/`:
> - `Guia_Practica_Enterprise_Architect_Dell.docx` → **fuente de verdad metodológica** (fases, gates, foros, artefactos, reglas de calidad).
> - `raid_log_screenshot.png` → estilo y estructura del RAID Log (Dell Global Project Management Methodology).
> - `solution_dependency_map_screenshot.png` → estilo y estructura del Solution Dependency Map / pestaña del RTM.
>
> Si algo de este fichero contradice la guía, **manda la guía** y me lo señalas.

---

## 1. Rol y misión

Actúas como **Lead Enterprise Architect + Senior Full-Stack Engineer** de Dell Technologies Professional Services (EMEA Multicloud Consulting).

Vas a construir **EA Delivery Hub**: una aplicación web interna que funciona como sistema operativo del Delivery/Enterprise Architect. Su valor no es "pintar pantallas", sino:

1. **Mantener la cadena de trazabilidad** outcome → requisito → elemento de arquitectura → decisión (ADR) → prueba/evidencia → gate → aceptación.
2. **Aplicar las reglas de calidad de la guía** de forma automática (un solo A por fila en el RACI, ningún riesgo crítico sin owner, ningún requisito huérfano, ninguna decisión de ruta crítica sin owner y fecha…).
3. **Generar las plantillas de entrega** (Excel, Word, PowerPoint) con el estilo Dell, vacías o rellenas con los datos del programa.

Mantra que guía las decisiones de producto (guía §15): *Outcome antes que producto. Decisión antes que documento. Evidencia antes que opinión. Governance antes que improvisación. Operabilidad antes que cierre.*

---

## 2. Entorno de ejecución: Docker dentro de WSL2

### 2.1 Prerrequisitos (verifícalos tú al empezar la Fase 0 y repórtame lo que falte)
- `wsl.exe -l -v` no aplica desde dentro; comprueba que estás en Linux (`uname -a`) y en una distro WSL2 (`grep -i microsoft /proc/version`).
- `docker version` y `docker compose version` funcionan **dentro de WSL** (Docker Engine nativo en la distro, o Docker Desktop con integración WSL activada).
- El repo vive en el sistema de ficheros Linux (`~/projects/ea-delivery-hub`), **nunca en `/mnt/c/...`** (rendimiento de I/O y file watching).
- Si hay proxy corporativo: variables `HTTP_PROXY`, `HTTPS_PROXY`, `NO_PROXY` presentes y, si existe, el certificado CA corporativo en `docker/certs/` (no lo subas a git).

### 2.2 Requisitos del contenedor
- `docker-compose.yml` con un único servicio `app` (y un servicio opcional `db` Postgres detrás de un profile `postgres`).
- **Dockerfile multi-stage**: stage 1 compila Tailwind con el *standalone CLI*; stage 2 imagen `python:3.12-slim`, usuario no-root, `HEALTHCHECK` contra `/health`.
- Proxy corporativo: pasar `HTTP_PROXY/HTTPS_PROXY/NO_PROXY` como `build args` y, si existe `docker/certs/*.crt`, instalarlos con `update-ca-certificates`.
- Puerto publicado **solo en loopback**: `127.0.0.1:8080:8000` (WSL2 lo reenvía al `localhost` de Windows; no queda expuesto a la red).
- Volúmenes nombrados: `ea_data` (SQLite / ficheros subidos) y `ea_exports` (plantillas generadas). Bind mount de `./exports` opcional para abrir los ficheros desde el Explorador de Windows (`\\wsl$\...`).
- `.gitattributes` con `* text=auto eol=lf` y `*.sh text eol=lf` (evita errores CRLF desde Windows).
- `Makefile` con: `make up`, `make down`, `make logs`, `make seed`, `make test`, `make lint`, `make export-all`, `make shell`.
- Hot-reload en desarrollo (`docker compose watch` o `uvicorn --reload` con bind mount del código).
- Nada de dependencias en tiempo de ejecución desde CDN: htmx, Alpine.js, iconos Lucide y fuentes **vendorizados** en `app/static/vendor/` (la red corporativa puede bloquear CDNs y la app debe funcionar offline).

---

## 3. Stack técnico (no lo cambies sin preguntarme)

| Capa | Elección | Motivo |
|---|---|---|
| Backend | Python 3.12 + FastAPI + SQLModel | Python tiene las mejores librerías para generar Office |
| BD | SQLite por defecto (fichero en volumen); Postgres opcional | Cero fricción en local |
| Migraciones | Alembic | Evolución del modelo sin perder datos |
| Frontend | Jinja2 + htmx + Alpine.js + Tailwind CSS (compilado) | HTML semántico y JS mínimo, sin build de SPA |
| Tablas densas | Componentes propios con htmx (sort, filtro, edición inline) | Estilo hoja de cálculo como en las capturas |
| Gráficos | Chart.js vendorizado o SVG generado en servidor | Matriz de riesgo, radar NFR, avance de gates |
| Export Excel | openpyxl | Pestañas, validaciones, formato condicional, fórmulas |
| Export Word | python-docx | Brief, ADR, Charter, actas, handover |
| Export PowerPoint | python-pptx | Diapositiva de estado con el patrón de las capturas |
| Tests | pytest + Playwright (smoke de pantallas) | Verificación automática por fase |
| Calidad | ruff + mypy (modo básico) | |

---

## 4. Sistema de diseño "Dell Delivery"

Inspírate en las dos capturas de referencia. Todo color va en tokens (`app/static/css/tokens.css` + `tailwind.config.js`) y en `branding.yaml` para las exportaciones; **nada hardcodeado** en plantillas.

### 4.1 Tokens
- `--dell-blue`: `#0076CE` (primario, cabeceras de tabla, botones). Hover `#005A9E`. *Valida el valor exacto con el brand portal interno; si cambia, se cambia solo en tokens.*
- `--navy-900`: `#0A1F44` / `--navy-700`: `#0B3D91` → degradado de cabecera de diapositiva/hero, como el fondo de las capturas.
- `--title-on-dark`: `#4FA9F0` (títulos azul claro sobre fondo navy, como "Risks, Actions, Issues & Dependencies (RAID)").
- `--row-alt`: `#DDEBF7` (filas alternas azul claro, como el RAID Log). `--row-base`: `#FFFFFF`.
- `--header-sub`: `#8EA9DB` (segundo nivel de cabecera, como "Goals and Objectives" en el Solution Dependency Map); `--header-dark`: `#1F3864` (cabecera "Requirements Completion").
- `--banner-black`: `#000000` con texto blanco cursiva (banda "Dell Technologies' Global Project Management Methodology").
- Fondo de app: `#F5F7FA`; superficies: `#FFFFFF` con borde `#D9DEE5`.
- **RAG** (único esquema semántico en toda la app y en los exports):
  - Verde `#2E8540` · Ámbar `#F0B323` · Rojo `#D0021B` · Azul informativo = `--dell-blue` · Gris "no evaluado" `#8C8C8C`.
- Tipografía: la del template corporativo si está disponible; fallback web `Inter, "Segoe UI", Arial, sans-serif`; en Office, `Arial`.
- Radios: `rounded-md` (6px) en inputs/botones, `rounded-lg` (8px) en tarjetas. Iconos Lucide, stroke 1.75.

### 4.2 Patrones visuales obligatorios (extraídos de las capturas)
1. **Cabecera de artefacto "Purpose / Process / Additional Information"**: cada pantalla de artefacto (RAID, RTM, RACI, Dependency Map, ADR, ORR…) arranca con tres cajas en fila con esos tres títulos subrayados, igual que en las capturas. El texto viene de la definición del artefacto (§7). Ese mismo bloque encabeza la diapositiva PPTX exportada.
2. **Tablas tipo hoja de cálculo**: cabecera azul Dell con texto blanco centrado y filtro por columna (icono de embudo), filas alternas azul claro, celdas de texto largo con wrap, columnas de ID estrechas, puntuación de riesgo con **punto de color + número**.
3. **Pestañas tipo libro Excel** para el RAID: `Cover · Risks · Actions · Issues · Decisions · Escalation · Changes · Comms · Lessons Learned`, con la activa en verde/negrita como en la captura.
4. **Cabeceras agrupadas a dos niveles** (p. ej. "Goals and Objectives" | "Requirements Completion") y celdas combinadas por Goal.
5. **Pie de clasificación** configurable en pantalla y en todos los exports: `Internal Use - Confidential` (por defecto).

### 4.3 Shell de la aplicación
- **Top bar** (h-14, blanca, borde inferior): nombre "EA Delivery Hub" + subtítulo "Architecture & Delivery Governance"; selector de programa activo; buscador global (`Ctrl+K`) sobre IDs y títulos (RK-, AC-, IS-, ADR-, REQ-…); botón `+ Registrar` (Riesgo, Acción, Issue, Decisión/ADR, Cambio, Dependencia); notificaciones = alertas de reglas (§6); avatar.
- **Sidebar** (w-64) agrupado **según el ciclo de vida de la guía**:
  - **Principal**: Inicio (portfolio) · Dashboard del programa · Primeros 10 días
  - **Definir**: Architecture Brief · Goals & Solution Dependency Map · Requisitos y RTM · Arquitectura (HLD/LLD)
  - **Gobernar**: Gates y Roadmap · Decisiones (ADR) · Design Authority · RAID y dependencias · Stakeholders, RACI y Comms
  - **Entregar y cerrar**: Operational Readiness · As-built y handover · Lessons learned
  - **Habilitación**: Biblioteca de plantillas · Playbook del EA · (Copilot, si está activado) · Administración
  - Los badges de la sidebar son **calculados** (nº de ADR pendientes, riesgos críticos sin owner, gate activo), nunca texto fijo.
- **Área de trabajo**: breadcrumbs, H1, chips de contexto (fase activa, gate activo, RAG global), fila de 4-5 KPIs, contenido en 2-3 columnas.
- Responsive hasta 1280px como mínimo cómodo; usable a 1024px. Accesibilidad: contraste AA, foco visible, navegación por teclado en tablas.

---

## 5. Modelo de dominio

Cada entidad lleva `program_id`, `created_at/by`, `updated_at/by`. Toda modificación queda en `AuditLog` (append-only: entidad, id, campo, valor anterior/nuevo, usuario, fecha).

- **Program**: cliente, nombre, sponsor, PM, EA, fase activa (0-6), clasificación, idioma de exports.
- **Workstream**: nombre, Tech/Domain Lead, alcance.
- **Stakeholder**: nombre, organización (Cliente / Dell / Partner), rol, influencia (1-5), interés (1-5), postura (sponsor / neutral / detractor), canal, cadencia, mensaje clave.
- **Goal** (`Goal-###`) → **Objective** (`Obj-###`): objetivo, criterio de aceptación, estado de completitud, aprobador. *(Solution Dependency Map, captura 2.)*
- **Outcome**: descripción, métrica, valor base, valor objetivo, fecha.
- **Requirement** (`REQ-###` funcional / `NFR-###`): enunciado, tipo, prioridad (MoSCoW), **criterio medible obligatorio para NFR** (disponibilidad, RTO/RPO, rendimiento, capacidad, seguridad), origen (SOW, workshop, presales…), estado, links a Outcome/Objective.
- **ArchitectureElement**: nombre, vista (contexto, aplicación, datos, tecnología, seguridad, operaciones), workstream, HLD/LLD ref.
- **ADR** (`ADR-###`): título, estado (`Proposed → Under Review → Approved | Rejected | Deferred → Superseded`), contexto, opciones (lista con pros/contras/coste/riesgo), decisión, condiciones, rationale, consecuencias, impactos (artefactos, workstreams, coste, plazo, operaciones), **nivel de escalación** (Workstream / Architecture / Program / Executive, guía §7.3), ruta crítica (bool), owner, fecha límite, aprobadores, fecha de aprobación, `supersedes`.
- **RAIDItem**: tipo (`Risk | Action | Issue | Decision | Escalation | Change | Comm | LessonLearned`), ID con prefijo por tipo (`RK-, AC-, IS-, DC-, ES-, CH-, CM-, LL-`), organización, fecha alta, reportado por, título, workstream, owner, fecha objetivo, monitor status, y campos por tipo:
  - Risk: **causa, evento, consecuencia** (guía §8), probabilidad, impacto, score = P×I, respuesta/mitigación, contingency plan, trigger de escalación, foro de escalación, log de updates fechados (`2/21: …` como en la captura).
  - Issue: impacto, severidad, resolución, riesgo origen.
  - Change: descripción, impacto en alcance/coste/plazo, decisión de Change Control.
  - Lesson learned: contexto, decisión, resultado, recomendación (guía §10).
- **Dependency**: origen → destino (workstream, tercero, cliente), tipo, compromiso verificable (sí/no + evidencia), fecha necesaria, estado.
- **TestEvidence**: tipo (test automatizado, prueba manual, demo, documento), resultado, fecha, link.
- **TraceLink**: tabla genérica de enlaces para la RTM (Outcome/Objective ↔ Requirement ↔ ArchitectureElement ↔ ADR ↔ TestEvidence ↔ Gate).
- **Gate** (G0-G6) + **GateCriterion**: criterio, evidencia requerida, estado, aprobador.
- **RACIActivity** × **Role** → valor `R | A | C | I | A/R | A/C` (permite los valores compuestos de la guía §9).
- **Meeting** (foro de §5.1): tipo, fecha, quórum, asistentes, agenda, decisiones tomadas (links a ADR), acciones generadas (links a RAID).
- **ORRCheck**: dimensión, criterio, evidencia, estado, owner.
- **HandoverItem / TechDebt**: deuda, impacto, coste estimado, owner receptor, fecha de revisión.
- **Baseline**: snapshot versionado (v1, v2…) de requisitos + arquitectura + RAID + roadmap, con fecha, aprobador y hash SHA-256 del contenido serializado (solo para detectar cambios entre versiones, sin más pretensión).
- **Settings**: escala de riesgo (por defecto **1-3 × 1-3**, igual que el RAID Log Dell de la captura; seleccionable **1-5 × 1-5**), umbrales RAG del score, SLA de decisiones (días), textos de branding.

---

## 6. Motor de reglas de governance (`app/rules/`)

Reglas puras, testeadas con pytest, que alimentan alertas, badges, salud semanal y bloqueos de gate. Cada regla devuelve `{id, severidad, entidad, mensaje, acción sugerida}`.

| ID | Regla (origen en la guía) | Severidad |
|---|---|---|
| RACI-01 | Cada actividad tiene **exactamente un A** (§6, §9) | Rojo |
| RACI-02 | Cada actividad tiene al menos un R | Ámbar |
| RAID-01 | Riesgo con score en umbral rojo **sin owner** o sin respuesta (§6, §11.1) | Rojo |
| RAID-02 | Riesgo sin causa/evento/consecuencia, fecha o trigger (§8) | Ámbar |
| RAID-03 | Elemento RAID con fecha vencida y status distinto de cerrado | Ámbar |
| RAID-04 | Riesgo que cumple su trigger de escalación → propone Escalation al foro indicado | Rojo |
| DEP-01 | Dependencia externa sin compromiso verificable (§8.1) | Ámbar → Rojo si está en ruta crítica |
| ADR-01 | Decisión de **ruta crítica sin owner o sin fecha** (§5.2, §8.1) | Rojo |
| ADR-02 | ADR en Proposed/Under Review que supera el SLA configurado | Ámbar |
| ADR-03 | ADR Approved sin artefactos impactados identificados | Ámbar |
| RTM-01 | **Requisito huérfano**: sin outcome/objective o sin elemento de arquitectura (§6) | Rojo si Must, Ámbar resto |
| RTM-02 | Requisito sin prueba/evidencia al llegar al gate G5 | Rojo |
| RTM-03 | NFR sin criterio medible (§7.1, §14) | Ámbar |
| STK-01 | Plan de comunicación sin decisores o sin detractores identificados (§6) | Ámbar |
| OPS-01 | Operaciones sin owner o sin participación antes de G5 (§11.1, §14) | Rojo |
| BASE-01 | Cambios en elementos baselined sin Change/ADR asociado (§14 "No actualizar baseline") | Ámbar |

**Salud semanal (guía §11.1)**: el dashboard calcula el RAG de los 7 controles —Outcomes y alcance, Decisiones, Arquitectura, Dependencias, RAID, Requisitos, Operaciones— a partir de las reglas anteriores, mostrando qué regla provoca cada ámbar/rojo y con enlace directo al elemento.

**Gates**: un gate no puede marcarse como superado si tiene reglas rojas asociadas abiertas, salvo *waiver* explícito registrado como ADR.

---

## 7. Catálogo de pantallas

Datos de demo en todas (ver §9). Cada pantalla de artefacto: cabecera Purpose/Process/Additional Information + tabla/vista + botón **Exportar** (formato(s) indicados en §8).

1. **Portfolio (Inicio)** — tarjetas por programa: RAG global, fase/gate activo, top riesgos, ADR pendientes, próximos foros. Tabla comparativa ordenable.
2. **Dashboard del programa** — salud semanal (7 controles §11.1), avance de gates, matriz de riesgo, radar de NFR (cumplido vs objetivo), últimas ADR, issues bloqueantes, checklist "¿Estoy realmente al mando?" (§11.2) editable.
3. **Primeros 10 días / Setup de engagement** — wizard alineado con la guía §3: *Antes del kick-off → Días 1-2 → Días 3-5 → Días 6-7 → Días 8-10*, con las 8 preguntas de §3.1 como checklist y la evidencia de salida de cada tramo. Resultado: Architecture Brief + Governance Charter + Baseline v1.
4. **Architecture Brief** — documento de 1-2 páginas con las secciones de §13.1; criterio "se entiende en 10 minutos": aviso si supera ~2 páginas en export.
5. **Goals & Solution Dependency Map** — réplica funcional de la captura 2: Goal ID, Goal, Obj ID, Objective, Acceptance Criteria, Completion Status, Approver, con celdas combinadas por Goal y cabecera a dos niveles.
6. **Requisitos y RTM** — matriz continua: Outcome/Objective → Requirement → Architecture Element → ADR → Test/Evidence → Gate → Status. Filtros por huérfanos, por gate y por workstream. Vista de cobertura (% de requisitos trazados extremo a extremo).
7. **Arquitectura (HLD/LLD review)** — checklists de §7.1 (HLD) y §7.2 (LLD) por documento revisado, con estado, comentarios y desviaciones → crear ADR/Change desde una desviación. Subida de diagramas (PNG/SVG/draw.io export) por vista.
8. **Gates y Roadmap** — pipeline G0-G6 mapeado a las fases de la guía §4 (0 Qualify, 1 Discover, 2 Define target, 3 Plan transition, 4 Govern delivery, 5 Validate/Transition, 6 Close/Evolve) con la pregunta clave, actividades y gate de salida de cada fase como criterios. Roadmap por work packages y transition states.
9. **Decisiones (ADR)** — catálogo con filtros por estado/nivel/ruta crítica; ficha con la estructura de §13.2; matriz de trade-offs de opciones contra los criterios de la Design Authority (alineación, seguridad, operabilidad, coste, plazo, reversibilidad, compliance — §5.2); historial de estado.
10. **Design Authority** — preparación de sesión y *meeting mode*: agenda con la plantilla de §13.3 (5-10-30-10-5 min) y temporizador por bloque, quórum (participantes de §5.2), deliberación ADR por ADR con resultado aprobada/rechazada/diferida + condiciones, owner y fecha; al cerrar genera acta (DOCX) y crea acciones en el RAID.
11. **RAID y dependencias** — libro con las pestañas de la captura 1. Pestaña Risks con exactamente estas columnas: ID · Organization · Date Added · Reported By · Risk Title · Workstream · Risk Mitigation Owner · Probability · Impact · Risk Score (punto + número) · Due Date · Monitor Status · Contingency Plan · Risk Mitigation & Updates; más (plegables) Causa, Evento, Consecuencia, Trigger y Foro de escalación. Matriz P×I interactiva (clic en celda = filtro). Formulario con el formato de la guía: *"Debido a [causa], existe el riesgo de [evento], lo que podría provocar [impacto]…"*. Vista de dependencias como grafo simple workstream ↔ workstream/tercero.
12. **Stakeholders, RACI y Comms** — directorio; mapa poder/interés; matriz RACI editable (actividades × roles) con validación en vivo de RACI-01/02, precargada con la tabla de la guía §9; plan de comunicación (influencia, interés, mensaje, canal, cadencia, owner).
13. **Operational Readiness** — checklist de la guía §10 (monitoring, backup, support, access, capacity, runbooks, skills) + dimensiones adicionales configurables (DR/RTO-RPO, patching, observabilidad, seguridad). Bloquea G5 si hay rojos.
14. **As-built y handover** — conciliación baseline vs implantado (diff entre Baselines), deviations, deuda técnica cuantificada, transferencia de decisiones/riesgos abiertos, Definition of Done del EA (Anexo A) como checklist de cierre.
15. **Lessons learned** — formato contexto/decisión/resultado/recomendación; exportable y reutilizable entre programas.
16. **Biblioteca de plantillas** — catálogo de §8 con filtros por fase, foro y formato; cada plantilla: previsualización, "Descargar vacía", "Generar con datos del programa".
17. **Playbook del EA** — la guía navegable por fase (qué hacer, qué preguntar, qué producir, cómo saber si está bajo control), plan 30-60-90 (§12) y errores frecuentes (§14). Contenido en Markdown en `app/content/playbook/`, editable sin tocar código.
18. **Administración** — programas, roles, escalas de riesgo, SLA, branding (`branding.yaml`), import/export de datos (JSON completo del programa).
19. *(Opcional, Fase 6)* **EA Copilot** — ver §10.

---

## 8. Generador de plantillas (`app/services/exports/`)

Requisitos comunes a **todas** las plantillas:
- Dos modos: **vacía** (con 2-3 filas de ejemplo en gris cursiva que se pueden borrar) y **rellena** con los datos del programa.
- Hoja/página **Cover** con programa, cliente, versión, fecha, owner, estado, clasificación y control de versiones.
- Estilo de §4: cabecera azul Dell, filas alternas, banda negra de metodología (texto configurable en `branding.yaml`), pie de clasificación, logo solo si existe en `branding/` (no lo inventes ni lo descargues).
- Excel: paneles inmovilizados, autofiltro, anchos de columna ajustados, wrap, **listas de validación** en campos con valores cerrados, **fórmulas vivas** (score = P×I, % de cobertura) y **formato condicional** con los colores RAG.
- Idioma de exportación ES/EN seleccionable (por defecto EN, como las plantillas Dell de las capturas); UI en español.
- Nombre de fichero: `{Programa}_{Artefacto}_v{versión}_{AAAAMMDD}.{ext}`.

| # | Plantilla | Formato | Contenido mínimo (guía) | Validaciones integradas |
|---|---|---|---|---|
| T01 | Architecture Brief | DOCX | §13.1 | Aviso si > 2 páginas |
| T02 | Architecture Governance Charter | DOCX | Foros §5.1, Design Authority §5.2, niveles de escalación §7.3, calendario | — |
| T03 | Goals & Solution Dependency Map | XLSX (también pestaña del T05) | Captura 2 | Lista de Completion Status |
| T04 | RAID Log | XLSX | Pestañas Cover/Risks/Actions/Issues/Decisions/Escalation/Changes/Comms/Lessons Learned (captura 1) + causa/evento/consecuencia | P e I con lista, score con fórmula y semáforo, Monitor Status con lista, resaltado de riesgo rojo sin owner |
| T05 | Requirements Traceability Matrix | XLSX | Pestañas Cover · Outcomes · Requirements · Trace (cadena de la pantalla 6 de §7) · Solution Dependency · Coverage | Formato condicional en huérfanos; % cobertura con fórmula |
| T06 | RACI Matrix | XLSX | Actividades × roles, precargada con §9 | Fórmula por fila que cuenta "A" y pinta en rojo si ≠ 1 |
| T07 | Stakeholder Map & Comms Plan | XLSX | §6 Stakeholder & Comms Plan | Aviso si no hay decisores/detractores |
| T08 | ADR | DOCX (una por decisión) + Decision Log XLSX | §13.2 | — |
| T09 | Design Authority — agenda y acta | DOCX | §13.3 + decisiones, owners, fechas | — |
| T10 | HLD / LLD Review Checklist | XLSX | §7.1 y §7.2 | Lista Sí/No/Parcial/N.A. |
| T11 | Architecture Roadmap | XLSX | Work packages, milestones, dependencias, transition states | — |
| T12 | Weekly Health Check | XLSX + PPTX (1 slide) | §11.1, 7 controles con RAG y motivo | — |
| T13 | Operational Readiness Review | XLSX | §10 + dimensiones configuradas | — |
| T14 | As-built & Handover + EA Definition of Done | DOCX | §10, Anexo A | — |
| T15 | Primeros 10 días / Onboarding del EA | XLSX | §3 y §3.1 | — |
| T16 | Diapositiva de artefacto para status meeting | PPTX | Fondo navy, título azul claro, bloque Purpose/Process/Additional Information y tabla resumen (patrón de las capturas) | — |
| T17 | Lessons Learned | XLSX | §10 formato contexto/decisión/resultado/recomendación | — |

`make export-all` genera las 17 plantillas vacías y rellenas en `exports/` para revisión.

---

## 9. Datos de demostración (seed)

- **Ficticios y sin ningún nombre de cliente real** (ni de las capturas ni de proyectos reales). Programa demo: *"Sovereign Private Cloud — Agencia Atlántica de Servicios Digitales (ficticia)"*, engagement de Dell Professional Services en EMEA.
- Workstreams: Compute & Storage, Data Protection & Cyber Recovery, Networking, Security & Sovereignty, Operations & Capacity Planning, Migration.
- Goals/Objectives inspirados en la captura 2 (IaaS, STaaS, FaaS, BaaS, CRaaS, VDIaaS, capacity planning, modelo de consumo predecible), con criterios de aceptación tipo "Go-live for XaaS service".
- RAID realista: disponibilidad eléctrica del CPD, plazo de entrega de hardware, permisos de acceso al CPD, residencia de datos, dependencia de un tercero de red, skills del equipo de operaciones del cliente. Mezcla de scores verde/ámbar/rojo y al menos **un caso que dispare cada regla de §6** para poder demostrar las alertas.
- NFR medibles (disponibilidad, RTO/RPO, rendimiento, capacidad, retención inmutable de backups).
- Un segundo y tercer programa más ligeros para el portfolio.
- Seed idempotente: `make seed` borra y recrea solo los programas demo.

---

## 10. EA Copilot (opcional, desactivado por defecto)

- Solo se activa con `COPILOT_ENABLED=true` y un endpoint configurado (`COPILOT_PROVIDER=anthropic|openai_compatible`, `COPILOT_BASE_URL`, `COPILOT_API_KEY` en `.env`, nunca en git).
- Banner permanente: los datos del programa salen del contenedor hacia el endpoint configurado; usar solo con herramientas aprobadas por la organización y respetando la clasificación del cliente.
- Funciones: responder sobre los artefactos del programa (búsqueda sobre los datos de la BD, sin vector DB en la v1), proponer redacción de riesgos en formato causa-evento-consecuencia, sugerir ADR a partir de una desviación, preparar la agenda de la Design Authority. Siempre como **borrador** que el usuario acepta.
- Si está desactivado, la app funciona al 100% y la entrada de menú no aparece.

---

## 11. Lo que NO debes hacer
- No mostrar badges de certificación ni de conformidad ("TOGAF 10 Certified", "ISO compliant", etc.). La app *usa* TOGAF 10 ADM como disciplina de pensamiento (guía §4), no certifica nada.
- No introducir marcos normativos sectoriales (PCI-DSS, DORA…) como datos fijos; los marcos aplicables son un campo configurable por programa.
- No inventar logos ni descargar material de marca; solo usar lo que yo ponga en `branding/`.
- No usar nombres reales de clientes, personas o proyectos en datos de ejemplo.
- No añadir dependencias fuera del stack de §3 sin preguntarme.
- No cargar nada desde CDN en tiempo de ejecución.

---

## 12. Forma de trabajar

1. **Empieza en modo plan.** Lee este fichero y `docs/reference/`, y devuélveme: dudas/contradicciones detectadas, estructura de carpetas propuesta y plan de la Fase 0-1. No escribas código hasta que lo apruebe.
2. Trabaja **fase a fase**. Al terminar cada una: `make lint && make test`, `docker compose up -d --build`, comprueba `/health`, haz capturas con Playwright de las pantallas nuevas y genera las plantillas afectadas. Resúmeme qué hay, qué falta y qué decisiones has tomado. Commit por fase.
3. Si una regla de la guía es ambigua, elige la interpretación más simple, déjala anotada en `docs/decisions/` (mini-ADR del propio proyecto) y sigue.

### Fases
| Fase | Alcance | Criterio de aceptación |
|---|---|---|
| 0 | Repo, Docker/WSL, Makefile, CI local (ruff, mypy, pytest), shell vacío con sidebar y tokens | `make up` levanta la app en `http://localhost:8080` desde el navegador de Windows; healthcheck OK |
| 1 | Modelo de datos, Alembic, seed, motor de reglas con tests | Cada regla de §6 tiene un test que pasa y otro que falla; seed dispara todas las reglas |
| 2 | RAID (con pestañas), RACI, RTM + Solution Dependency Map, Dashboard con salud semanal | Edición inline funciona; alertas y badges calculados; capturas parecidas a las de referencia |
| 3 | Generador de plantillas T03-T06, T12, T16 | Los XLSX abren sin avisos en Excel; validaciones, fórmulas y formato condicional funcionan; tests que reabren el fichero con openpyxl y verifican estructura |
| 4 | Brief, Wizard 10 días, ADR, Design Authority (meeting mode), Gates, HLD/LLD review + T01, T02, T08-T11, T15 | Un gate se bloquea con reglas rojas; cerrar una DA genera acta y acciones |
| 5 | ORR, As-built/handover, Baselines y diff, Lessons learned, Biblioteca, Playbook, Admin, import/export JSON + T07, T13, T14, T17 | `make export-all` genera las 17 plantillas; el round-trip export→import JSON conserva el programa |
| 6 | (Opcional) EA Copilot | Desactivado por defecto; con él activo, todas las respuestas son borradores aceptables |
