/** @type {import('tailwindcss').Config} */
// Los colores apuntan a las variables CSS de app/static/css/tokens.css: nada hardcodeado en plantillas.
const v = (name) => `rgb(var(--${name}) / <alpha-value>)`;

module.exports = {
  content: ["./app/templates/**/*.html", "./app/static/js/**/*.js", "./app/**/*.py"],
  // Clases calculadas en servidor (badges/RAG) que Tailwind no ve literalmente
  safelist: [{ pattern: /^(bg|text|border|fill|stroke)-rag-(green|amber|red|blue|grey)$/ }, "bg-dell-blue"],
  theme: {
    extend: {
      colors: {
        dell: { blue: v("dell-blue"), "blue-hover": v("dell-blue-hover") },
        navy: { 900: v("navy-900"), 700: v("navy-700") },
        "title-on-dark": v("title-on-dark"),
        row: { alt: v("row-alt"), base: v("row-base") },
        header: { sub: v("header-sub"), dark: v("header-dark") },
        banner: v("banner-black"),
        app: v("app-bg"),
        surface: v("surface"),
        line: v("border"),
        ink: { DEFAULT: v("ink"), muted: v("ink-muted") },
        rag: {
          green: v("rag-green"),
          amber: v("rag-amber"),
          red: v("rag-red"),
          blue: v("dell-blue"),
          grey: v("rag-grey"),
        },
      },
      fontFamily: {
        sans: ["Inter", '"Segoe UI"', "Arial", "sans-serif"],
      },
      borderRadius: { md: "6px", lg: "8px" },
    },
  },
  plugins: [],
};
