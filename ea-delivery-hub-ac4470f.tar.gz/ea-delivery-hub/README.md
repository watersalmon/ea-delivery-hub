# EA Delivery Hub

Aplicación web interna que funciona como sistema operativo del Delivery/Enterprise Architect: trazabilidad outcome → requisito → arquitectura → ADR → evidencia → gate, reglas de calidad de governance y generación de plantillas de entrega con estilo Dell.

La especificación completa está en [CLAUDE.md](CLAUDE.md). Las decisiones del propio proyecto, en [docs/decisions/](docs/decisions/).

Para instalar la app en otro equipo (Docker dentro de WSL2), sigue [docs/INSTALL.md](docs/INSTALL.md).

## Requisitos (desarrollo)

- Windows 11 con la virtualización activada en BIOS/UEFI.
- WSL2 y Docker Desktop (backend WSL2). Instalación, desde una PowerShell de administrador:

  ```powershell
  wsl --install --no-distribution
  winget install -e --id Docker.DockerDesktop
  ```

  Después, reinicia, abre Docker Desktop y acepta sus términos.
- `make`, disponible desde una shell WSL. Ver [PDR-002](docs/decisions/PDR-002-entorno-repo-en-windows.md) para la ubicación del repo.
- Material de referencia en `docs/reference/`, que no se versiona.

## Arranque

```bash
cp .env.example .env       # opcional
make up                    # http://localhost:8080
make health                # {"status":"ok",...}
make watch                 # hot-reload (docker compose watch)
```

| Comando | Qué hace |
|---|---|
| `make up` / `make down` | Levanta o para la app (puerto `127.0.0.1:8080`) |
| `make watch` | Hot-reload: sincroniza `app/` en el contenedor |
| `make logs` / `make shell` | Logs / shell dentro del contenedor |
| `make lint` | ruff + mypy |
| `make test` | pytest + smoke Playwright (capturas en `docs/screenshots/`) |
| `make seed` | Recrea los programas demo (Fase 1) |
| `make export-all` | Genera las plantillas (vacías y rellenas por programa) en `./exports` |
| `make check-office` | Abre todas las plantillas con LibreOffice headless: fórmulas recalculadas, PDF y PNG en `exports/_check` |

`make up EXPORTS_BIND=1` monta `./exports` para abrir las plantillas desde el Explorador de Windows. Desde la app, cada pantalla de artefacto tiene un botón **Export** (rellena, rellena en ES o vacía).

## Proxy corporativo

Define `HTTP_PROXY`, `HTTPS_PROXY` y `NO_PROXY` en `.env`. Coloca el certificado CA corporativo (`*.crt`) en `docker/certs/`; no se sube a git. Se instala en la imagen con `update-ca-certificates`.

## Desarrollo sin Docker

Solo sirve para lint y tests rápidos:

```bash
uv venv --python 3.12 .venv
python docker/deps.py dev > /tmp/req.txt && uv pip install --python .venv -r /tmp/req.txt
.venv/Scripts/python -m pytest      # Windows (en Linux: .venv/bin/python)
```

## Librerías front

htmx, Alpine.js, Lucide, Inter y Chart.js están vendorizadas en `app/static/vendor/` (ver `VERSIONS.md`). La app no carga nada de CDN en tiempo de ejecución.
